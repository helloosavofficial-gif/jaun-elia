# Reference research and design strategy — Jaun Elia website

Internal working document (private; not served by the website). 21–22 Oct 2026.

## 1. How the research was done

Live sites were opened in a real browser (desktop 1440×900 and phone 375×812), inspected visually
(screenshots while scrolling) and with in-page checks of the DOM: page height, video attributes,
image loading attributes, font families, navigation structure, sticky/fixed elements.
Observations below are marked **[seen]** (directly observed) or **[inferred]** (a reasonable reading of
what was seen, not verified). No source code was copied; nothing private was accessed. Cookie banners
were declined or left untouched; region pop-ups were closed.

## 2. Sites inspected

| Site | URL | What was inspected |
|---|---|---|
| Aimé Leon Dore | https://www.aimeleondore.com/ | Home, collection (sweatshirts), product page — desktop and phone |
| Fear of God | https://fearofgod.com/ | Home (desktop) |
| Acne Studios | https://www.acnestudios.com/us/en/home | Home (behind a cookie dialog) |
| The Row | https://www.therow.com/ | Home (behind a shipping-country dialog — does not ship to Pakistan) |
| Jacquemus | https://www.jacquemus.com/ | Home, scrolled (optional cookies refused) |
| Represent | https://representclo.com/ | Home (behind a region dialog) |
| A-COLD-WALL* | https://www.a-cold-wall.com/ | Home |
| Rastah (Lahore) | https://pk.rastah.co/ | Home, collection, product page on phone |
| Wales Bonner | https://walesbonner.com/ | Home |
| Lemaire | https://www.lemaire.fr/ | Home (behind region and cookie dialogs) |
| Kith | https://kith.com/ | Home |
| Bode | https://bode.com/ | Home |
| SSENSE | https://www.ssense.com/ | **Not inspected** — Cloudflare bot verification; not bypassed |

Searches for award listings (Awwwards e-commerce/luxury), agency case studies and 360° viewer practice were
also run; they produced few primary sources (mostly vendor marketing), so they informed little.

## 3. Observations

**Aimé Leon Dore** — Home is one full-viewport film with a centred wordmark and a small live dateline
under it (place, weekday, date and local time) [seen]; the page is exactly one screen tall [seen]. Commerce
lives one click away. Collection: white page, four-column packshot grid, name and price in one line under each
image, no quick add [seen]. Product page (desktop): three columns — name, price and accordions (details, sizing,
delivery) left; one large image centre; colour and size choice with Add to bag right [seen]. **Phone: a fixed
bottom bar holds name, price, colour, size and Add to bag at all times** [seen]. The header wordmark collapses
to a monogram on scroll [seen].

**Fear of God** — Magazine-cover hero: the subject's name set full-width in a thin display serif over a
monochrome photograph, with "Written by…" and "Photography by…" credits in the bottom corners and one
"Discover" button [seen]. Heavy page (≈15 MB transferred on load) [seen].

**Acne Studios** — Full-bleed video hero, large centred title, credits in a slim bar at the bottom [seen].

**The Row** — Monochrome portrait, very small navigation, almost no copy [seen].

**Jacquemus** — Rhythm of *story, then product*: a full-bleed editorial diptych (two portrait images side by
side), then a row of four packshots, then another diptych, then packshots [seen]. Videos autoplay muted and
loop [seen]. Product cards carry a tiny "NEW" label and colour swatches [seen].

**Represent / Kith / A-COLD-WALL*** — Stacked full-width campaign banners, each with a title, a sentence and a
button [seen]. Effective for frequent drops, but every block has the same shape; it reads as a template.

**Rastah** — Night city hero, a script "Live now" above a caps collection title [seen]. Collections are named
like chapters ("The Morning Shift", "After Hours") [seen]. Horizontal product carousel with a "+" quick add
[seen]. Product page on phone: full-bleed gallery with "1/8" counter and progress line, segmented size row,
a "Size & Fit" link beside the sizes, an "All details +" fold-out [seen]. Urdu script appears on its own
garments in real photography [seen].

**Wales Bonner** — Home is a single image captioned like a museum label: title, photographer, place, year
[seen]. Navigation includes an Archive [seen].

**Lemaire** — Serif and sans pairing (EB Garamond with a grotesque) [seen]. Home leads with a single garment by
name ("The Wrap Coat — Discover") [seen].

**Bode** — The print artwork itself is the full-bleed hero, with one small button [seen].

**Technical, across the sample** — Most stores lazy-load the majority of images (e.g. Rastah 111 of 117,
Kith 334 of 368 had `loading="lazy"`) and serve responsive `srcset`s [seen]. Hero videos are muted, inline,
mostly with posters, and loop indefinitely [seen]. Region and cookie dialogs cover the first viewport on most
sites [seen] — a cost to first impressions we do not have.

## 4. Transferable principles (and what we reject)

| Principle | Source | Use for Jaun Elia | Not for us |
|---|---|---|---|
| One confident subject per screen | ALD, The Row, Wales Bonner | The cover shows one hoodie and one line of type | Busy multi-tile heroes |
| Magazine-cover credits in the corners | Fear of God, Acne | Edition, finish and price set as cover credits; an honest "concept render" credit | Inventing photographer or writer credits |
| Captions as labels, not decoration | Wales Bonner | Plate captions ("Plate I — The back · design mockup") carry the honesty notes the brief requires, in a voice that suits a diwan | — |
| Live dateline | ALD | A small Pakistan-time clock on the cover: *After Dark* becomes literal | A city we have not been given |
| Story, then product | Jacquemus | Home alternates ink (story) and paper (product) | Endless banner stacks (Kith, Represent) |
| Chapters, not banners | Rastah | Home is a short book: I · II · III · Colophon, with a contents list | — |
| Commerce on light, story on dark | ALD, Jacquemus, Lemaire, Rastah | Shop grid, product page, bag and checkout lead with paper; home, campaign and story moments use ink | Making the shopping pages as dark as the film |
| Sticky phone buy bar | ALD (phone) | Product page: a bar with price, size state and Add to bag when the panel scrolls away | — |
| Size guide beside the sizes | Rastah | Already added in Phase 1 | — |
| Artwork as hero | Bode | Considered, **rejected for now**: the only high-resolution artwork files are unverified cut-outs (ARTWORK-VERIFICATION.md). The client mockups are used instead | Enlarging unverified artwork |
| Looping hero video | Most sites | Rejected — the approved behaviour is play once, then rest | Indefinite loops |

## 5. Assessment of our site before this pass

- `/` was a one-screen pre-launch teaser with an unconnected sign-up; the full experience lived at `/campaign`.
- `/campaign` used the shape of a storefront landing page (banners, product row) — closest to the Kith/Represent
  pattern, i.e. the least distinctive of the references.
- `/shop` (after Phase 1) was dark throughout, with one card left-aligned in a wide empty grid.
- The product page and bag were dark; the product page did not keep the purchase action in reach on phones.
- `/about` was a list of facts with a draft note; there is no Story page.

## 6. Decisions

1. **Home `/` becomes "the cover and three chapters":**
   - *Cover* (ink, one screen): "Words, / made wearable." set large; the hoodie turning once and coming to rest;
     cover credits (finish, edition, price), a Pakistan-time dateline, a contents list, "Shop the hoodie" and
     "Watch the film".
   - *I. The words* (paper): the back of the hoodie as an annotated plate, with the Reading Column explained
     in margin notes.
   - *II. The piece* (ink): front and back mockups as a diptych, the facts, a size-first route to the product
     page and a direct link to the 360° view.
   - *III. After dark* (full bleed): one night image (labelled placeholder) and the way into the film.
   - *Colophon*: the edition counted, the closing call to action.
2. **Header and footer appear on the home page** (the teaser hid them); the header is transparent over the cover.
3. **Campaign keeps the cinema**: intro under four seconds; hero videos play once and rest; concept labels stay.
4. **Shop**: dark editorial intro, then the collection on paper. The first product is presented as a *lead*
   card (front and back side by side); later products fall into a regular grid.
5. **Product page**: paper surface, the viewer in an ink well, a sticky buy bar on phones, `?view=360` deep link.
6. **Story `/about`**: About and Story merged into one manuscript page of confirmed facts, with margin notes;
   the brand's own story stays marked as pending.
7. **Bag and checkout**: paper surface for consistency with shopping pages; behaviour unchanged; Place order
   stays disabled.

## 7. Constraints carried through

No invented product facts, history, credits, reviews or availability. No AI Urdu. Concept and placeholder
imagery labelled; no concept imagery on listings. Checkout frontend-only. Nothing committed, pushed or deployed.

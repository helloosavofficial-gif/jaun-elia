# Jaun Elia — Asset Workflow

How an asset moves from source to the website, and how source artwork, concepts, composite drafts
and approved exports are kept apart. Updated 21 Oct 2026.

## 1. Separation — one place per state

```
asset-production/jaun-elia/            PRIVATE — not served by the website
├── docs/                              planning documents (this file, index, prompts, checklists, reports)
├── 00-source-artwork/                 client master artwork ONLY (vector, production files) — read-only
├── 01-artwork-awaiting-verification/  artwork files not yet checked against the master
├── 02-reference/                      client mockups, mood references, stock
├── 03-concepts/                       generated images (plain garments, scenes)
│   ├── base-garments/  campaign-male/  campaign-female/  cinematic-scenes/
├── 04-composite-drafts/               verified artwork on base images, layered, awaiting sign-off
├── 05-approved-masters/               client-approved full-resolution masters
└── verification/                      inspection evidence (overlays, crops, measurements)

public/assets/jaun-elia/               PUBLIC — web exports of APPROVED masters only
├── 01-product/ 02-campaign/ 03-model-shoots/ 04-motion/ 05-source-artwork/ 06-social/ 07-reference/
```

- Nothing goes into `public/assets/jaun-elia/` except optimised exports of `APPROVED` masters.
- `public/assets/jaun-elia/05-source-artwork/` and `07-reference/` stay **empty** (kept only because the folder
  structure was requested). Source artwork and references live in the private area.
- Existing files in `public/media/`, `public/frames/`, `public/art/`, `public/brand/` are used by the current site and
  stay where they are. Copy, never move.
- Large masters (PSD, TIFF, RAW, video masters) may be better kept in cloud storage than in git; if they stay
  in `asset-production/`, consider adding those folders to `.gitignore` (not done — your call).

## 2. States

| State | File tag | Folder | Can appear on the site? |
|---|---|---|---|
| Source | `SRC` | `00-source-artwork/` | Never directly |
| Awaiting artwork verification | `AWAITING-VERIFICATION` | `01-artwork-awaiting-verification/` | No |
| Reference | `REF` | `02-reference/` | No (existing placeholders on the site stay labelled) |
| Concept | `CONCEPT` | `03-concepts/` | Only clearly labelled as a concept; never as the product |
| Composite draft | `COMPOSITE` | `04-composite-drafts/` | No |
| Approved | `APPROVED` | `05-approved-masters/` | Via exports |
| Export | `APPROVED` + `@{width}` | `public/assets/jaun-elia/…` | Yes |

Promotion is one-way and recorded: `AWAITING-VERIFICATION → SRC` (after the master check) and
`CONCEPT → COMPOSITE → APPROVED` (after `COMPOSITING-CHECKLIST.md` and written sign-off).

## 3. Naming

```
je_{category}_{subject}_{STATE}_v{NN}[@{width}].{ext}

je_back-art_AWAITING-VERIFICATION_v00.png    artwork not yet verified
je_back-art_SRC_v01.ai                        client master
je_base_front_CONCEPT_v01.png                 generated plain base plate
je_front_full_COMPOSITE_v01.psd               composite draft (layered)
je_front_full_APPROVED_v02.tif                approved master
je_front_full_APPROVED_v02@1600.avif          web export
```

Versions only go up; earlier versions are never overwritten.

## 4. Artwork rules

- The client's Urdu calligraphy is authoritative. Never redraw, regenerate, retype, translate, trace, "clean up" or approximate it.
- Generated garments are always plain and unbranded. The artwork enters an image only by compositing the verified master.
- See `ARTWORK-VERIFICATION.md` for the current state of the artwork files and `COMPOSITING-CHECKLIST.md` for every check.

## 5. Export specification

| Use | Formats | Widths | Target size |
|---|---|---|---|
| Hero stills | AVIF + WebP (+ JPEG fallback) | 1080 (9:16), 1920, 2560 | ≤ 350 KB at 1920 |
| Product gallery | AVIF + WebP | 800, 1200, 1600, 2400 | ≤ 250 KB at 1600 |
| Cards | AVIF + WebP | 400, 800 | ≤ 80 KB at 800 |
| Social | JPEG | 1080×1350, 1080×1920, 1080×1080 | per platform |
| Hero video | MP4 (H.264) + WebM, no audio | 1920×1080 / 1080×1920 | ≤ 4 MB / ≤ 3 MB |
| Rotation | frame sequence, WebP | 720 and 450 wide | ≤ 20 KB per frame |

sRGB, metadata stripped, consistent white balance across a set, a poster still for every video.

## 6. Asset log

Every file added gets a row (a table in `ASSET-INDEX.md` or a shared sheet):

| File | State | Source (client / tool + model + seed / photographer) | Prompt or shot ref | Date | Checked by | Approved by |
|---|---|---|---|---|---|---|

## 7. Licensing

- Stock placeholders (`public/media/lifestyle/`): Unsplash License; they show other garments — replace before launch.
- Generated images: follow the tool's commercial-use terms; record tool and model version.
- Photography (when a sample exists): model releases and photographer licence for web, social and ads.
- Artwork and verse: confirm the client holds the rights to use the verse commercially.

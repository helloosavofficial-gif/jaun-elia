# Artwork Verification Report — Jaun Elia hoodie

Inspection of the artwork files currently in the project, 21 Oct 2026.
**Verdict: `AWAITING ARTWORK VERIFICATION`.** Nothing here is approved. The client's original artwork
files have not been supplied, so no file in the project can be confirmed as the approved design.

## 1. Files inspected

| File | Dimensions | Type | Where it came from |
|---|---|---|---|
| `public/art/front-mark.png` | 1392×1328 | Transparent PNG, raster | Arrived with the initial project import. No record of who made it or from what. |
| `public/art/back-art.png` | 1376×2456 | Transparent PNG, raster | Same. |
| `public/media/front.webp` | 830×1254 | Design mockup (rendered hoodie) | Client-supplied mockup imagery. |
| `public/media/back.webp` | 577×1024 | Design mockup (rendered hoodie) | Client-supplied mockup imagery. |
| `public/media/front-chest.webp` | 530×662 | Crop of the front mockup | Derived. |

Working copies (unchanged pixels, renamed with their status) are in
`asset-production/jaun-elia/01-artwork-awaiting-verification/` and `02-reference/client-mockups/`.
Comparison images are in `asset-production/jaun-elia/verification/`.

## 2. Method

1. Visual side-by-side of each cut-out against the artwork region of its mockup (`*-side-by-side.jpg`).
2. Ink masks: dark pixels in the mockup, opaque pixels in the cut-out.
3. The cut-out was scaled down to the mockup's resolution and aligned by a best-fit search over
   scale (90–110%) and offset (±8 px), then the two masks were compared pixel by pixel
   (`*-registered-diff.png`: **black** = both agree, **red** = only in the cut-out, **blue** = only in the mockup).
4. The cut-outs were viewed at 100% to judge edge quality (`*-cutout-100pct*.png`).

No lettering was redrawn, edited, retyped or "corrected" at any point.

## 3. Results

| Measure | Back (`back-art.png` vs `back.webp`) | Front (`front-mark.png` vs `front.webp`) |
|---|---|---|
| Artwork size in the mockup | 282×547 px | 178×154 px |
| Artwork size in the cut-out | 1152×2190 px | 1204×1117 px |
| Cut-out resolution vs mockup | 4.1× wider | 6.8× wider |
| Proportion (width ÷ height) | mockup 0.516 · cut-out 0.526 (≈2% apart) | mockup 1.156 · cut-out 1.078 (≈7% apart) |
| Best-fit scale / offset | 100% / 2 px | 100% / 3 px |
| Ink overlap at mockup resolution (IoU) | **0.74** | **0.58** |
| Visual verdict | Same artwork. Every element lines up: the name, the "JAUN ELIA" line with side rules, both dot columns, the four verse lines, the line and the small mark at the base. Differences are 1–2 px edge fringes from anti-aliasing. | Same letterforms and layout. The "JAUN ELIA" line sits slightly higher relative to the calligraphy than in the mockup, and the cut-out is ≈7% taller for its width. |
| Ink colour | RGB 20,20,20 (dark grey, not pure black) | RGB 20,20,20 |
| Edges at 100% | Soft, slightly blurred; verse strokes slightly fuzzy | Soft with slightly wobbly outlines |

*IoU is limited by the mockups' low resolution — at ~280 px wide, a 1-pixel edge difference is a large share of each stroke. The visual overlays are the better guide.*

## 4. What can be verified

- The cut-outs show **the same artwork as the client's mockups**, in the same layout. For the back, the match is close across every element.
- Both cut-outs are clean transparent images with no background, at 1376–1392 px wide.
- They are **raster**, not vector, and their ink is dark grey (20,20,20).

## 5. What cannot be verified

- **That either the mockups or the cut-outs match the client's approved master artwork.** No master file has been supplied.
- **Where the cut-outs came from.** They hold 4–7× more pixels than the mockups, so that detail did not come from these mockups. It may come from a higher-resolution original, or from upscaling or auto-tracing (the soft, slightly wobbly edges are consistent with either). This cannot be told from the files.
- **The Urdu itself** — spelling, letterforms, the wording of the verse, and the small mark at the base of the column. These must be confirmed by the client and a native Urdu reader. Nothing has been corrected or interpreted from memory.
- **The front proportion difference** (~7%). It is consistent with the mockup's chest print being drawn on curved fabric, but a slightly different artwork version cannot be ruled out.
- **Physical specifications** — embroidery size and placement on the garment, thread colour, stitch type, and how the artwork actually looks when embroidered. The mockups show print-like flat ink, not embroidery.
- **The garment itself** — construction details visible in the mockups (pocket, drawcords, eyelets, cuffs) are taken from mockups, not from a manufactured sample.

## 6. Fitness for use (pending verification)

| Use | `front-mark.png` / `back-art.png` today |
|---|---|
| Internal compositing tests | Yes — labelled `AWAITING ARTWORK VERIFICATION` |
| Website imagery at moderate sizes | Only after the client confirms the artwork matches the approved design |
| Large hero images or print | Not recommended — soft edges; a vector master is needed |
| Embroidery reference | No — production files must come from the client/manufacturer |

## 7. What closes this report

1. The client supplies the **original artwork files** — vector (AI, SVG, PDF or EPS) for the chest mark and the back artwork, plus the embroidery/production file and the placement spec (size and position on the garment) if available.
2. Each master is overlaid on these cut-outs and the mockups (same method as above).
3. The client and a native Urdu reader confirm the name, the verse and the mark in writing.
4. Only then do the files move to `00-source-artwork/` (masters) and their status change from `AWAITING ARTWORK VERIFICATION`.

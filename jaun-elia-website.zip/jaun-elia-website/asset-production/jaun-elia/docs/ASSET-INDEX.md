# Jaun Elia — Asset Index (campaign: AFTER DARK)

Inventory of every asset the website needs, what exists, and what to do next.
Updated 21 Oct 2026. Nothing in the asset library is wired into the website yet.
No physical hoodie sample is available; the client's design mockups are the only product imagery.

## Where things live

| Area | Path | Public after deploy? | Holds |
|---|---|---|---|
| Production (private) | `asset-production/jaun-elia/` | **No** | Planning docs, source artwork, files awaiting verification, references, concepts, composite drafts, approved masters |
| Website exports | `public/assets/jaun-elia/` | Yes | Web-optimised exports of `APPROVED` assets only (currently empty) |
| Existing website media | `public/media/`, `public/frames/`, `public/art/`, `public/brand/` | Yes | Files the current site already uses — untouched |

## Status key

| Status | Meaning |
|---|---|
| `MISSING` | Nothing usable exists yet. |
| `REFERENCE ONLY` | A guide only (mockup, stock photo, crop). Never ships as product imagery. |
| `CLIENT ARTWORK REQUIRED` | Cannot be made until the client supplies original artwork or confirmed information. |
| `AWAITING ARTWORK VERIFICATION` | Shows or contains the artwork, but has not been checked against the client's master. |
| `CONCEPT` | Generated or rendered concept. Plain garment, or unverified artwork. Never presented as the product. |
| `COMPOSITE DRAFT` | Verified artwork composited onto a base image; awaiting full-resolution Urdu inspection and client sign-off. |
| `APPROVED` | Signed off by the client in writing after verification. **Nothing is approved yet.** |

An image is never marked `APPROVED` without: the client's master on file, the overlay and count checks in
`COMPOSITING-CHECKLIST.md` §7, a native Urdu reader's confirmation, and written client sign-off.

---

## 1. Existing files

Originals are untouched. Paths relative to the project root.

### Artwork

| File | Size | What it is | Status |
|---|---|---|---|
| `public/art/front-mark.png` → copy: `asset-production/jaun-elia/01-artwork-awaiting-verification/je_front-mark_AWAITING-VERIFICATION_v00.png` | 1392×1328, transparent | Chest calligraphy cut-out, raster, unknown provenance. Matches the front mockup's letterforms; ≈7% proportion difference (see `ARTWORK-VERIFICATION.md`). | `AWAITING ARTWORK VERIFICATION` |
| `public/art/back-art.png` → copy: `…/je_back-art_AWAITING-VERIFICATION_v00.png` | 1376×2456, transparent | Back artwork cut-out (name, "JAUN ELIA", verse, dot columns, mark). Closely matches the back mockup. | `AWAITING ARTWORK VERIFICATION` |
| Client master artwork (vector + production file) | — | Not supplied. | `CLIENT ARTWORK REQUIRED` |
| `public/brand/*.svg` | vector | OSAV's proposed ن mark and devices; not client-approved. | `CONCEPT` |
| `public/art/*-normal.png`, `knit-normal.png` | various | 3D-draft textures (technical). | Not a campaign asset |

### Client design mockups

| File | Size | Status |
|---|---|---|
| `public/media/front.webp` → copy: `asset-production/jaun-elia/02-reference/client-mockups/je_mockup-front_REF.webp` | 830×1254 | `REFERENCE ONLY` · artwork shown is `AWAITING ARTWORK VERIFICATION` |
| `public/media/back.webp` → copy: `…/je_mockup-back_REF.webp` | 577×1024 | `REFERENCE ONLY` · artwork `AWAITING ARTWORK VERIFICATION` |
| `public/media/front-chest.webp` → copy: `…/je_mockup-front-chest_REF.webp` | 530×662 | `REFERENCE ONLY` |
| `public/media/detail-drawcord.webp`, `detail-cuff.webp` | 415×394, 415×347 | `REFERENCE ONLY` |
| `public/media/edit/back-name.webp`, `back-verse.webp`, `front-pocket.webp` | 440×330, 390×200, 590×470 | `REFERENCE ONLY` (crops of mockups) |

### Concept renders and footage

| File | Size | Status |
|---|---|---|
| `public/media/rotation-scrub.mp4`, `rotation-poster.jpg`, `public/frames/rotation-hd/` (192 frames ×2 sizes), `public/media/edit/angle-*.webp` (4) | 720×1280 etc. | `CONCEPT` — artwork in the render unverified |
| `public/media/emergence.mp4`, `emergence-start.jpg`, `emergence-end.jpg` | 1280×720 | `CONCEPT` — **artwork rendered incorrectly; do not use** |
| `public/frames/details/` (64 frames ×2), `public/media/details-poster.jpg`, `public/media/edit/detail-{eyelet,cuff,cord}.webp` | 960×540 etc. | `CONCEPT` — colour may differ from the garment |

### Stock placeholders

| File | Status |
|---|---|
| `public/media/lifestyle/hero-night`, `night-hood`, `night-green` (+`-sm`) — Unsplash, women in plain off-white hoodies at night | `REFERENCE ONLY` — mood match for After Dark; not the product |
| `public/media/lifestyle/day-wall`, `day-steps`, `day-lean` (+`-sm`) — Unsplash, man in plain off-white hoodie, daylight | `REFERENCE ONLY` — off-direction for After Dark |

Campaign reference images from the client/AD: **none supplied yet** → `asset-production/jaun-elia/02-reference/`.

---

## 2. Product imagery

No physical sample, so product images can only be **composites** (verified artwork on plain base plates)
until a manufactured hoodie is photographed. Composites are presented as design visuals, not photographs.

| Asset | Use | Ratio / master | Status | Source today | Next action |
|---|---|---|---|---|---|
| Front, full garment | Product gallery #1, shop card | 4:5 · 3000×3750 | `CLIENT ARTWORK REQUIRED` | Mockup `front.webp` (ref) | Get master artwork → generate base plate 4a → composite → `COMPOSITE DRAFT` |
| Back, full garment | Gallery #2, card hover | 4:5 · 3000×3750 | `CLIENT ARTWORK REQUIRED` | Mockup `back.webp` (ref) | Master artwork → base plate 4b → composite |
| Front three-quarter | Gallery | 4:5 | `CLIENT ARTWORK REQUIRED` | `angle-three-quarter.webp` (concept) | Base plate 4c → composite |
| Side profile | Gallery | 4:5 | `MISSING` | `angle-profile.webp` (concept) | Base plate 4d (artwork not visible in profile → may need no composite; still `CONCEPT` until a sample is shot) |
| Chest calligraphy detail | Gallery detail | 4:5 / 1:1 | `CLIENT ARTWORK REQUIRED` | `front-chest.webp` (ref) | Composite on a fabric close-up; true embroidery detail needs a physical sample |
| Back artwork detail (name; verse; column) | Gallery detail, story | 4:5 / 3:2 | `CLIENT ARTWORK REQUIRED` | `back-name.webp`, `back-verse.webp` (ref) | As above |
| Hood, cuffs, hem, drawcords, eyelets | Gallery detail | 4:5 | `MISSING` | Mockup crops (ref), detail footage (concept) | Generic `CONCEPT` details possible; accurate details need a sample |
| Seams, stitching, embroidery texture | Quality story | 1:1 | `MISSING` | — | **Physical sample required — never generated or simulated** |
| Shopping-card pair (front + back, matched) | Shop card + hover | 4:5 · export 800×1000 | `MISSING` | — | Export from approved front/back |
| Size and fit reference | Size guide | 4:5 | `CLIENT ARTWORK REQUIRED` | — | Confirmed sizes and measurements from the client |

## 3. Campaign imagery (After Dark)

| Asset | Use | Ratio / master | Desktop/mobile | Status | Next action |
|---|---|---|---|---|---|
| Male desktop hero | Homepage hero | 16:9 · 3840×2160 | Desktop — subject right third, text left 40% | `MISSING` | Generate 4 × prompt 5a → choose → `CONCEPT`; artwork composite later |
| Female desktop hero (matches male) | Homepage hero | 16:9 · 3840×2160 | Desktop — mirrored | `MISSING` | Prompt 5b, same recipe |
| Male mobile hero | Homepage on phones | 9:16 · 2160×3840 | Mobile — subject lower 60%, text top 35% | `MISSING` | Prompt 5c (vertical, not a crop) |
| Female mobile hero | Homepage on phones | 9:16 · 2160×3840 | Mobile | `MISSING` | Prompt 5d |
| Male / female editorial (front) | Story, lookbook | 4:5 | Both | `MISSING` | Variants of 5a/5b |
| Male / female back-view frames | Back-artwork story | 4:5 | Both | `MISSING` | Prompt 5e → back composite |
| Duo | Story / closing banner | 3:2 (+4:5 mobile crop) | Both | `MISSING` | Prompt 5f |
| Cinematic scenes, no people | Backgrounds, transitions | 21:9, 16:9, 9:16 | Both | `MISSING` | §6 prompts |
| Night product still | Editorial block | 4:5 | Both | `MISSING` | Base plate 4e → composite |

Campaign frames carry the artwork only via composite; until composited and approved they are `CONCEPT`
(plain garment) and must not be presented as the Jaun Elia hoodie.

## 4. Motion

| Asset | Format | Status | Next action |
|---|---|---|---|
| Hero loop, desktop | 16:9 · 1920×1080, 6–10 s, MP4 + WebM, ≤ 4 MB, no audio | `MISSING` | Image-to-video from an approved hero still (§7) |
| Hero loop, mobile | 9:16 · 1080×1920, ≤ 3 MB | `MISSING` | As above |
| Poster stills | First frame of each loop | `MISSING` | Export with each video |
| Product rotation / 360° | Turntable → 192-frame sequence | `CONCEPT` (existing render) | Needs a physical sample; keep the concept labelled until then |
| Fabric/stitch detail clips | 4–8 s loops | `CONCEPT` (existing footage) | Accurate clips need a sample |
| Making-of / production footage | 16:9 + 9:16 | `MISSING` | From the manufacturer, if available |

## 5. Supporting

| Asset | Status | Next action |
|---|---|---|
| Front artwork master (vector + production file + placement spec) | `CLIENT ARTWORK REQUIRED` | Request from client → `00-source-artwork/` |
| Back artwork master (vector + production file + placement spec) | `CLIENT ARTWORK REQUIRED` | Request from client |
| Verse wording, source and the mark at the base of the column | `CLIENT ARTWORK REQUIRED` | Client + native Urdu reader confirm in writing |
| Brand logo / wordmark | `CLIENT ARTWORK REQUIRED` | Client approves or supplies (OSAV proposal is `CONCEPT`) |
| Social crops 4:5, 9:16, 1:1 | `MISSING` | From approved masters → `public/assets/jaun-elia/06-social/` |
| Share image 1200×630 | `CONCEPT` (generated in code from the rotation poster) | Replace with an approved hero |
| Website-ready exports | `MISSING` | From `APPROVED` masters only |

## 6. Summary

- **Approved:** none.
- **Awaiting artwork verification:** both artwork cut-outs (and the artwork shown in the mockups).
- **Concept:** rotation render and frames, detail footage, angle crops, proposed brand mark, emergence video (unusable).
- **Reference only:** mockups and their crops, stock photos.
- **Blocking:** the client's master artwork files (front and back) with placement spec; verse confirmation.
- **Generation:** no tool connected; prompts ready in `GENERATION-PROMPTS.md`.

# AFTER DARK — Generation Prompts (v2)

Prompts for **concept** images made in an external tool. Revised 21 Oct 2026 for plain,
compositing-ready hoodie bases and matching male/female After Dark campaign frames.

> **No image or video generation tool is connected to this workspace** (re-checked 21 Oct 2026).
> Nothing below has been generated. Use these prompts in a tool of your choice (e.g. Midjourney,
> Adobe Firefly, Google Imagen/Veo, Flux, Runway, Sora) and check its licence for commercial use.

## 0. Ground rules

1. **Every generated hoodie is plain and unbranded.** No logos, text, letters, script, labels, tags,
   patches, prints or invented artwork — anywhere (chest, back, sleeves, neck, hem, pocket, drawcord tips).
2. The client's artwork is added **only** by compositing the verified master (`COMPOSITING-CHECKLIST.md`).
3. Generated files are concepts: save to `asset-production/jaun-elia/03-concepts/…` (never `public/`,
   never anything product-labelled) as `je_{subject}_CONCEPT_v{NN}.png`.
4. **Small batches:** 4 candidates per brief → pick 1–2 → refine. Log tool, model version, seed and prompt ID.
5. When refining, edit backgrounds, light or pose only. Never inpaint or "fix" the chest or back panel —
   regenerate instead, so no artefact can masquerade as artwork.

## 1. Garment spec (paste into every prompt)

Taken **only** from what the client mockups show; the manufactured garment is not available to confirm it.

```
GARMENT: a heavy off-white ivory cotton-fleece pullover hoodie, completely plain and unbranded,
relaxed fit with dropped shoulders, full double-layer hood, front kangaroo pocket, ribbed cuffs and
ribbed hem, flat white drawcords with plain matte black tips through plain matte black eyelets.
No print, no text, no logo, no labels, no tags, no patches, no embroidery, no graphics of any kind.
Natural heavy-fabric drape with real folds; colour a neutral warm ivory (not yellow, not grey, not bright white).
```

## 2. Shared negative prompt

```
text, letters, words, numbers, typography, writing, script, Arabic, Urdu, calligraphy, signature,
logo, brand, emblem, monogram, label, neck label, woven label, care label, size tag, hang tag,
patch, badge, print, graphic, pattern on garment, embroidery, stitched design, branded drawcord tips,
zipper, buttons, watermark, frame, border, neon light, pink and blue lighting, cyberpunk, oversaturated,
HDR look, plastic skin, airbrushed skin, extra fingers, deformed hands, distorted face, warped fabric,
stiff CG cloth, melted folds, cluttered background, crowd, legible shop signs, daylight, flat lighting,
yellowed fabric, blown-out whites
```

## 3. Inspection after generation (every candidate)

- [ ] At 100%: no text-like marks, labels or tags anywhere on the garment (neck and hem included).
- [ ] Construction matches the spec (pocket, cuffs, hem, drawcords, eyelets); nothing extra (zips, buttons, seams in odd places).
- [ ] Fabric reads as heavy cotton fleece with believable folds; proportions realistic.
- [ ] Hands, face and skin natural.
- [ ] The artwork area (left chest / full back) is unobstructed and evenly lit (for compositing).
- [ ] Composition leaves the planned typography zone (§5).
Reject anything that fails; do not retouch the garment to pass.

---

## 4. Base garment plates — for compositing (`03-concepts/base-garments/`)

Studio images of the plain hoodie, built so the verified artwork can be composited cleanly.
Requirements: artwork panel facing camera, smooth (no deep fold across it), evenly lit, nothing covering it,
≥ 3000 px on the long side after upscale.

**4a. Front — ghost mannequin** · 4:5 · `je_base_front_CONCEPT_v01`
```
Professional e-commerce studio photograph, 4:5 vertical. [GARMENT] shown front-on on an invisible
ghost mannequin, centred, hood standing naturally behind the neck, drawcords hanging straight and
symmetrical, sleeves relaxed at the sides. The left-chest area is smooth, flat and evenly lit with no
folds or shadows across it. Seamless warm paper-coloured background (#F2EEE6), large soft overhead
light with gentle fill, subtle natural shadow beneath the hem. Colour-accurate, high resolution,
sharp focus throughout, no props.
```

**4b. Back — ghost mannequin** · 4:5 · `je_base_back_CONCEPT_v01`
```
Professional e-commerce studio photograph, 4:5 vertical. [GARMENT] shown from directly behind on an
invisible ghost mannequin, centred, the hood laid flat and smooth down the upper back. The full back
panel from below the hood to the hem is smooth, flat and evenly lit, with no folds or shadows across
it. Seamless warm paper-coloured background (#F2EEE6), large soft overhead light with gentle fill.
Colour-accurate, high resolution, sharp focus throughout, no props.
```

**4c. Front three-quarter** · 4:5 · `je_base_front-34_CONCEPT_v01`
```
Professional e-commerce studio photograph, 4:5 vertical. [GARMENT] on an invisible ghost mannequin
turned 30 degrees to the left of camera, left chest towards the lens, smooth and evenly lit. Seamless
warm paper-coloured background (#F2EEE6), soft overhead light, colour-accurate, high resolution.
```

**4d. Side profile** · 4:5 · `je_base_side_CONCEPT_v01`
```
Professional e-commerce studio photograph, 4:5 vertical. [GARMENT] on an invisible ghost mannequin in
exact side profile, hood silhouette and sleeve visible, seamless warm paper-coloured background
(#F2EEE6), soft overhead light, colour-accurate, high resolution.
```

**4e. Night product still (campaign base)** · 4:5 · `je_base_night-chair_CONCEPT_v01`
```
Cinematic still life at night, 4:5. [GARMENT] folded neatly over the back of a dark wooden chair in
an otherwise dark room, front facing camera with the left chest flat and visible, one warm lamp from
the left, deep black shadows, faint amber bokeh through a window behind. 50mm, f/2, subtle grain.
```

---

## 5. After Dark campaign frames — male and female, matching

### Scene recipe (identical in both prompts — this is what keeps the pair consistent)

```
SCENE: a quiet old-city lane at night after light rain; damp stone ground with soft reflections;
one warm sodium streetlamp (about 2800K) high on the [LEFT|RIGHT]; distant lit windows and lamps
rendered as soft round amber bokeh; deep true-black shadows filling most of the frame; a faint cool
rim of ambient light separating the figure from the dark. Camera: 50mm lens, f/1.4, eye level,
shallow depth of field, subtle fine film grain. Grade: restrained, warm amber highlights, neutral
ivory garment holding detail, true blacks. Mood: quiet, intimate, a film still.
```

Compositing note for all model frames: hands and hair stay **clear of the left chest** (front frames)
or **the full back panel** (back frames); the hood may be up but must not cover the chest.

### 5a. Male desktop hero · 16:9 · `03-concepts/campaign-male/je_hero-desktop_male_CONCEPT_v01`
```
Cinematic night fashion editorial photograph, 16:9. A young South Asian man, mid-twenties, short
dark hair, calm expression, stands in the right third of the frame, three-quarter length, body
turned slightly towards camera, hands relaxed at his sides, wearing [GARMENT] with the hood down
and dark plain trousers. [SCENE] with the streetlamp on the LEFT, its light falling across him;
the hoodie is the brightest surface in the frame. The left 40% of the frame is dark and calm, empty
apart from soft bokeh, reserved for headline text.
```

### 5b. Female desktop hero (mirror of 5a) · 16:9 · `03-concepts/campaign-female/je_hero-desktop_female_CONCEPT_v01`
```
Cinematic night fashion editorial photograph, 16:9. A young South Asian woman, mid-twenties, dark
hair, calm expression, stands in the left third of the frame, three-quarter length, body turned
slightly towards camera, wearing [GARMENT] with the hood up softly framing her face, hands relaxed
below the chest, dark plain trousers. [SCENE] with the streetlamp on the RIGHT, its light falling
across her; the hoodie is the brightest surface in the frame. The right 40% of the frame is dark and
calm, empty apart from soft bokeh, reserved for headline text. Same scene, light and grade as its
companion male frame.
```

### 5c. Male mobile hero · 9:16 · `je_hero-mobile_male_CONCEPT_v01`
```
Vertical 9:16 cinematic night fashion photograph. A young South Asian man wearing [GARMENT], hood
down, framed from mid-thigh up in the lower 60% of the frame, slightly off-centre, looking past the
camera, hands at his sides. [SCENE] with the streetlamp above-left. The top 35% of the frame is dark
night and building edge with a few soft amber bokeh lights, otherwise empty, reserved for text; the
bottom 15% calm and dark. Shot as a vertical frame, not a crop.
```

### 5d. Female mobile hero · 9:16 · `je_hero-mobile_female_CONCEPT_v01`
```
Vertical 9:16 cinematic night fashion photograph. A young South Asian woman wearing [GARMENT], hood
up, framed from the waist up in the lower 60% of the frame, slightly off-centre, eyes lowered, hands
below the chest. [SCENE] with the streetlamp above-right. The top 35% of the frame is dark and empty
apart from a few soft amber bokeh lights, reserved for text; the bottom 15% calm and dark. Shot as a
vertical frame, not a crop. Same light and grade as the male mobile frame.
```

### 5e. Back-view frames (for the back artwork) · 4:5 · `je_editorial_{male,female}-back_CONCEPT_v01`
```
Cinematic night fashion photograph, 4:5. A young South Asian [man | woman] seen from behind, walking
slowly away down the lane, wearing [GARMENT] with the hood down, arms relaxed and away from the back,
the full back panel of the hoodie smooth, evenly lit by the streetlamp and unobstructed. [SCENE]
```

### 5f. Duo · 3:2 · `je_duo_CONCEPT_v01`
```
Cinematic night fashion photograph, 3:2. A young South Asian man and woman, both wearing [GARMENT],
standing a step apart on an empty rooftop at night, city lights as soft amber bokeh behind, one warm
practical light from the left, quiet confident body language, chests unobstructed. Camera 35mm f/2,
subtle grain, warm amber and true-black grade.
```

---

## 6. Cinematic scenes, no people (`03-concepts/cinematic-scenes/`)

**Empty lane** · 21:9 and 9:16 · `je_scene_lane_CONCEPT_v01`
```
Cinematic night photograph of an empty narrow old-city lane after light rain, no people, one warm
sodium streetlamp pooling light on damp stone, distant lit windows as soft amber bokeh, deep black
shadows filling most of the frame, large calm dark areas, subtle film grain. No legible signs.
```

**Lit window** · 16:9 · `je_scene_window_CONCEPT_v01`
```
A single warmly lit window in a dark old building at night, seen across an empty street, no people,
deep surrounding darkness, soft amber glow, faint reflection on wet ground, cinematic, still.
```

**Bokeh transition plate** · 16:9 and 9:16 · `je_scene_bokeh_CONCEPT_v01`
```
Out-of-focus night city lights, large soft amber bokeh circles on a near-black background, no
recognisable objects, no text, cinematic, subtle grain.
```

**Fabric texture (generic, no artwork)** · 1:1 · `je_scene_fabric_CONCEPT_v01`
```
Extreme macro of heavy ivory cotton-fleece fabric, warm raking light from one side revealing the knit,
falling to black at one edge, shallow depth of field, no text, no print.
```

---

## 7. Motion (image-to-video, from an approved still only)

**Hero loop** · 16:9 and 9:16, 6–10 s · `je_hero_{desktop,mobile}_CONCEPT_v01`
```
From the provided still: very slow camera push-in (2–3%), the subject breathes and shifts weight
slightly, fabric moves naturally, background bokeh drifts gently, the streetlamp glow flickers almost
imperceptibly. No cuts, no shake, seamless loop. The garment stays plain — no text or marks appear.
```

**Not generated, ever:** embroidery or calligraphy close-ups, stitching details, and the 360° product
rotation. Those must come from the manufactured garment.

# AFTER DARK — Art Direction

Campaign art direction for the Jaun Elia hoodie (The First Release).
Applies to photography, film, generated concepts and every export in this library.

## The idea

Urdu poetry has always belonged to the night — mushairas that run past midnight, verses read
under a single lamp, the city still awake around them. **After Dark** puts the hoodie in that
hour: one person, one warm light, a quiet street, and the words carried on their back.

The garment is the subject. Everything else is darkness, warmth and space.

## Mood

- Cinematic, intimate, unhurried. A film still, not an advert.
- Confident and quiet — no shouting poses, no props for the sake of props.
- Premium fashion editorial: considered framing, real texture, nothing glossy or plastic.

## Light

- **Deep blacks, controlled shadows.** Let most of the frame fall to near-black; detail survives in the mids.
- **One motivated key** — a street lamp, shop window, doorway, or car light — warm, around 2700–3200 K.
- **Amber city light** in the background as soft bokeh: sodium streetlamps, lit windows, distant traffic.
- A faint cool fill or rim (moonlight / signage spill) is allowed to separate the subject — never neon colour.
- The ivory hoodie should be the brightest surface in frame, holding detail — never blown out.

## Palette

| Role | Colour | Notes |
|---|---|---|
| Night | `#050505` – `#0B0B0A` | Deep, true blacks (matches the site's `--ink-deep`) |
| Shadow detail | `#1A1916` – `#2A2723` | Warm, not blue |
| Amber light | `#C9A46A` – `#E0A458` | Lamps, windows, bokeh (the site's `--lamp`) |
| Garment | `#F2EEE6` | Ivory/off-white — keep it neutral, not yellow, not grey |
| Skin | natural | No heavy smoothing or orange grading |

## Camera

- Lenses: 35 mm (environmental), 50 mm (hero), 85 mm (portrait/detail).
- Wide apertures (f/1.4–f/2) for shallow depth and round bokeh.
- Eye-level or slightly low; no extreme angles.
- Subtle natural grain is welcome; no heavy filters, no vignettes added in post beyond the light itself.

## Composition — space for typography

The website sets large type beside the image, so every hero is shot with a planned text zone.

| Frame | Subject placement | Clear zone for type |
|---|---|---|
| Desktop hero 16:9 (male) | Right third, waist-up to three-quarter length | Left 40%, kept dark and simple |
| Desktop hero 16:9 (female) | Left third (mirrors the male frame) | Right 40% |
| Mobile hero 9:16 | Lower 60% of frame, centred or slightly off-centre | Top 35% (and a calm bottom 15% for buttons) |
| Editorial 4:5 | Free, but uncluttered | — |
| Cinematic scenes | No people; one point of light | Large calm areas of darkness |

Shoot the mobile frames **separately in vertical** — do not rely on cropping the 16:9 frames.

## Styling

- **The ivory hoodie is the hero.** Hood up in some frames, down in others; the chest calligraphy or back artwork readable in key frames.
- Dark, plain trousers; minimal or no jewellery; no visible third-party logos.
- Natural fabric behaviour: real folds, real drape, the weight of a heavy hoodie — no stiff, CG-looking garments.
- Grooming natural; hair and skin real.

## Casting

- One male and one female model, photographed in **separate frames** (plus an optional duo frame).
- *Recommendation (for the client to decide):* cast to reflect the brand's audience in Pakistan and the South Asian diaspora.

## Locations (suggestions for the client to confirm)

Quiet old-city lanes, a closed shopfront with one lit window, a stairwell with a single bulb,
an empty road under sodium lamps, a rooftop with the city's lights behind. Minimal signage in frame.

## Product accuracy — non-negotiable

- The client's Urdu calligraphy is authoritative. It is **never redrawn, regenerated, retyped, translated or approximated.**
- AI-generated Urdu or Arabic script is never presented as the design. Generated frames show a **plain** hoodie (no text, no marks) or keep the artwork out of view.
- No invented back artwork, verses, logos, labels, stitching, construction or specifications.
- Generated images are named and labelled as concepts. A mockup is never described as a photograph of the manufactured product.
- No physical sample is available yet, so product images are composites of the verified artwork on plain
  base images (`COMPOSITING-CHECKLIST.md`), presented as design visuals. Photographing a manufactured
  hoodie remains the most accurate route once a sample exists.

## Do / Don't

| Do | Don't |
|---|---|
| One warm practical light, deep shadows | Flat, evenly lit frames |
| Amber bokeh, wet-street reflections | Neon pink/blue cyberpunk colour |
| Real fabric folds and stitch texture | Plastic, over-smoothed garments |
| Calm negative space for type | Busy backgrounds, crowds, signage |
| Ivory garment holding detail | Blown-out whites or yellowed fabric |
| Separate vertical mobile frames | Cropping desktop frames into mobile |

## Frame list (priority order)

1. Male desktop hero (16:9)
2. Female desktop hero matching the male frame (16:9)
3. Male and female mobile heroes (9:16, shot vertically)
4. Front and back product imagery of the real hoodie
5. Product details (chest embroidery, back artwork, cuffs, cords, fabric, stitching)
6. Editorial portraits, duo frame, cinematic scenes
7. Motion: hero loops (16:9 + 9:16), turntable 360°, detail clips, making-of

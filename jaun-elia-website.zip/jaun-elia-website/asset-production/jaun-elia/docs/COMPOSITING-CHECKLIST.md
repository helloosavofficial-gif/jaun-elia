# Compositing Checklist — verified artwork onto plain hoodie bases

For placing the client's artwork onto plain, unbranded hoodie images (generated base plates or
photographs). A composite is a **mockup**: it may never be described as a photograph of the
manufactured product. Work through every section; a single failed check sends the image back.

## 0. Before starting — gate checks

- [ ] The artwork is the **client's verified master** (status no longer `AWAITING ARTWORK VERIFICATION`).
      Internal tests with `01-artwork-awaiting-verification/` files must keep that tag in their file name.
- [ ] Placement spec known: artwork **size** (cm) and **position** on the garment (from the client's tech pack;
      until then, measured from the client mockups and recorded as provisional).
- [ ] Base image is **plain** — no text, logo, label, tag, print or fake script anywhere (zoom to 100% and check
      the chest, back, neck, cuffs, hem, drawcord tips).
- [ ] Base image is high enough resolution that the artwork area is at least as many pixels as the final export needs
      (e.g. chest mark ≥ 600 px wide for a 1600 px product image).
- [ ] Base image angle matches the intended view (front/back/three-quarter) and is in `03-concepts/base-garments/`
      or is a photograph with a known source.

Never: redraw, retype, trace, regenerate, translate, "clean up" or approximate any letter, dot or line.
Never move individual letters or change spacing to fit a fold.

## 1. Scale

- [ ] Garment reference measured in the image (e.g. shoulder width or chest width) and converted to px/cm.
- [ ] Artwork scaled **uniformly** (locked aspect ratio) to the specified size.
- [ ] Front mark sits on the wearer's left chest as in the mockup; back artwork centred, top of the column
      starting below the hood seam as in the mockup.
- [ ] Scale cross-checked against the mockup by overlaying the mockup at matching garment size.

## 2. Perspective

- [ ] Garment angle estimated (front-on, 3/4, profile, camera height).
- [ ] Artwork transformed with **perspective/distort as a whole object**, matching the plane of the chest or back.
- [ ] No non-uniform stretching beyond what the perspective requires; the artwork's proportions still match
      the master when viewed head-on (check with a reverse transform if unsure).

## 3. Fabric curvature and folds

- [ ] Displacement map made from the base image (desaturated, slightly blurred, contrast tuned) and applied so
      the artwork follows the body's curvature and the folds.
- [ ] Warp strength is modest: lettering bends with the fabric but stays readable; dots stay round(ish), lines stay
      continuous where the fabric is continuous.
- [ ] Where a fold hides part of the fabric, the artwork is **occluded** by the fold (masked), not compressed.
- [ ] No warping across seams that would be physically impossible for an embroidered panel.

## 4. Lighting and tone

- [ ] Artwork takes on the fabric's shading: multiply / linear-burn blend, or a luminosity-matched layer,
      so shadows on the garment darken the artwork equally.
- [ ] Highlights and shadow direction match the scene's key light (After Dark: warm practical from one side).
- [ ] Ink/thread value plausible for the scene — the darkest artwork tone is not darker than the image's blacks,
      and not grey-washed in bright areas.
- [ ] Colour temperature matched (warm amber cast in night scenes; neutral in studio product images).
- [ ] Fabric texture re-applied over the artwork at low opacity so the knit shows through.

## 5. Edge quality

- [ ] Edges examined at **100% and 200%**: no halos, white fringes, jagged steps or blur unlike the surrounding fabric.
- [ ] Edge softness matches the image's focus at that depth (sharp where the fabric is sharp, softer where it falls off).
- [ ] No resampling artefacts from the warp (stair-stepping on curves, broken thin strokes, lost dots).
- [ ] The master was used at or above the final size — no upscaling of the artwork.

## 6. Embroidery honesty

- [ ] No simulated stitch texture, thread sheen, puckering or relief **beyond what the client has confirmed** for
      the real garment. If the finish is unknown, the artwork reads as flat ink and the image is labelled a mockup.
- [ ] No invented labels, tags, stitching lines or construction details added during retouching.

## 7. Full-resolution Urdu inspection

Do all of this at 100% or more, on the final flattened file, before any export.

- [ ] **Overlay test:** the client master laid over the composite (difference blend, perspective-matched) —
      every letterform, dot (nuqta), diacritic and stroke join is present and in place.
- [ ] **Count check:** number of letters, dots and diamonds in the name, the "JAUN ELIA" line and rules, the dot
      columns, each verse line and the mark at the base all match the master.
- [ ] **Nothing extra:** no stray marks, fragments or AI artefacts anywhere on the garment.
- [ ] **Line order and direction:** verse lines in the master's order; right-to-left reading preserved
      (never mirrored — check especially on back views and reflections).
- [ ] **Legibility under warp:** a native Urdu reader confirms the name and every verse line read correctly
      on the composite at the size it will be displayed.
- [ ] **Latin line:** "JAUN ELIA" spelling and letter spacing match the master.

## 8. Sign-off and filing

- [ ] Saved as `je_{view}_{subject}_COMPOSITE_v{NN}.psd/.tif` in `04-composite-drafts/` with layers intact
      (base, artwork, displacement, masks, adjustments).
- [ ] Log entry: base image source (photo or tool + model + prompt ID), artwork master file name, checker, date.
- [ ] Client reviews the composite at full resolution and approves in writing.
- [ ] Only then: flattened master to `05-approved-masters/` as `APPROVED`, web exports to
      `public/assets/jaun-elia/…` per `ASSET-WORKFLOW.md`.
- [ ] Wherever shown publicly, a composite is presented as a design visual/mockup — never as a product photograph.

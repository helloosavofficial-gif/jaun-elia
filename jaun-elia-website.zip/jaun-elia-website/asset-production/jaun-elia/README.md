# Jaun Elia — asset production (private)

Working area for the After Dark campaign assets. **Not served by the website** (it is outside `public/`).

Start here:

- `docs/ASSET-INDEX.md` — every asset needed, its status and next action
- `docs/ARTWORK-VERIFICATION.md` — what is and isn't verified about the artwork files
- `docs/COMPOSITING-CHECKLIST.md` — every check before artwork goes onto a garment image
- `docs/GENERATION-PROMPTS.md` — prompts for plain hoodie bases and campaign frames
- `docs/ART-DIRECTION.md` — the After Dark direction
- `docs/ASSET-WORKFLOW.md` — folders, states, naming, exports

Only web exports of `APPROVED` masters go to `public/assets/jaun-elia/`.

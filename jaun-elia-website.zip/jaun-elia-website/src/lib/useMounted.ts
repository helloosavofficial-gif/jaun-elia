"use client";

import { useSyncExternalStore } from "react";

const noop = () => () => {};

/** False during the server render and hydration, true once running in the browser. */
export function useMounted() {
  return useSyncExternalStore(noop, () => true, () => false);
}

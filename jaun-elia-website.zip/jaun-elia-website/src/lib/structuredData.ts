import type { Product } from "@/content/products";
import { site } from "@/content/site";
import { store } from "@/content/store";
import { SITE_URL } from "./siteConfig";

/**
 * schema.org JSON-LD for search engines (rendered by components/JsonLd).
 * Built only from confirmed facts in content/*; anything still pending is left
 * out rather than guessed.
 */

const abs = (path: string) => `${SITE_URL}${path}`;

export function organizationLd() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": abs("/#organization"),
    name: store.businessName ?? site.wordmark,
    url: abs("/"),
    logo: abs("/icon"),
    ...(store.contact.email || store.contact.phone
      ? {
          contactPoint: {
            "@type": "ContactPoint",
            contactType: "customer support",
            ...(store.contact.email ? { email: store.contact.email } : {}),
            ...(store.contact.phone ? { telephone: store.contact.phone } : {}),
            availableLanguage: ["en", "ur"],
          },
        }
      : {}),
  };
}

export function websiteLd() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": abs("/#website"),
    name: site.meta.title,
    url: abs("/"),
    inLanguage: "en",
    publisher: { "@id": abs("/#organization") },
  };
}

/** Product + offer. `remaining` is the live edition count (null when unknown). */
export function productLd(p: Product, remaining: number | null) {
  const url = abs(`/shop/${p.slug}`);
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    "@id": `${url}#product`,
    name: p.name,
    description: p.description,
    sku: p.id,
    color: p.colour,
    image: [abs(p.images.front.src), abs(p.images.back.src)],
    brand: { "@type": "Brand", name: site.wordmark },
    ...(p.details.fabric ? { material: p.details.fabric } : {}),
    offers: {
      "@type": "Offer",
      url,
      price: p.price,
      priceCurrency: p.currency,
      itemCondition: "https://schema.org/NewCondition",
      availability: remaining === 0 ? "https://schema.org/SoldOut" : "https://schema.org/InStock",
      ...(remaining !== null ? { inventoryLevel: { "@type": "QuantitativeValue", value: remaining } } : {}),
      seller: { "@id": abs("/#organization") },
      acceptedPaymentMethod: "https://schema.org/COD",
      ...(store.shipping.regions === null ? {} : { areaServed: store.shipping.regions }),
    },
  };
}

export function breadcrumbLd(trail: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: trail.map((t, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: t.name,
      item: abs(t.path),
    })),
  };
}

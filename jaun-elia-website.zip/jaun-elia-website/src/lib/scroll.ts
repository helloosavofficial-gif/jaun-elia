"use client";

import type Lenis from "lenis";

/**
 * A handle on the site's smooth scroller (SmoothScroll registers it), so
 * overlays such as the bag drawer can pause page scrolling while open.
 */
let lenis: Lenis | null = null;

export const registerLenis = (instance: Lenis | null) => {
  lenis = instance;
};

/** Pauses page scrolling (smooth or native) — for modal overlays. */
export function lockScroll() {
  lenis?.stop();
  document.documentElement.style.overflow = "hidden";
}

export function unlockScroll() {
  document.documentElement.style.overflow = "";
  lenis?.start();
}

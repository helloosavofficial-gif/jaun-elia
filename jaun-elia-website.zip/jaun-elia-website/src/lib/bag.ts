"use client";

import { useSyncExternalStore } from "react";
import { findProduct, MAX_QTY_PER_LINE } from "@/content/products";

/**
 * The shopping bag — frontend only. Lines are saved in this browser
 * (localStorage) so the bag survives page changes and refreshes, and stays in
 * step across open tabs. It is sent to the server only when an order is placed
 * (components/checkout → /api/orders), which re-prices it from the catalogue.
 *
 * Only product id, size and quantity are stored. Name and price are always
 * read from content/products.ts, so a stale or edited saved bag can never
 * change what a line costs.
 */

export type BagLine = { productId: string; size: string; qty: number };

const KEY = "jaun-bag-v1";
const EMPTY: BagLine[] = [];

let lines: BagLine[] = EMPTY;
let loaded = false;
const listeners = new Set<() => void>();

const clampQty = (n: number) => Math.min(MAX_QTY_PER_LINE, Math.max(1, Math.floor(n)));

/** Keeps only lines that still match a real product and size. */
function sanitize(raw: unknown): BagLine[] {
  if (!Array.isArray(raw)) return EMPTY;
  const out: BagLine[] = [];
  for (const l of raw) {
    if (!l || typeof l !== "object") continue;
    const { productId, size, qty } = l as Partial<BagLine>;
    const product = typeof productId === "string" ? findProduct(productId) : undefined;
    if (!product || typeof size !== "string" || !product.sizes.includes(size)) continue;
    if (typeof qty !== "number" || !Number.isFinite(qty)) continue;
    const existing = out.find((o) => o.productId === productId && o.size === size);
    if (existing) existing.qty = clampQty(existing.qty + qty);
    else out.push({ productId: product.id, size, qty: clampQty(qty) });
  }
  return out;
}

function read(): BagLine[] {
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? sanitize(JSON.parse(raw)) : EMPTY;
  } catch {
    return EMPTY; // storage blocked (private mode, etc.) — the bag still works for this visit
  }
}

function commit(next: BagLine[]) {
  lines = next;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    // storage blocked or full: keep the in-memory bag
  }
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  if (!loaded) {
    loaded = true;
    lines = read();
  }
  listeners.add(listener);
  const onStorage = (e: StorageEvent) => {
    if (e.key !== KEY) return;
    lines = read();
    listeners.forEach((l) => l());
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", onStorage);
  };
}

export const bag = {
  add(productId: string, size: string, qty = 1) {
    const i = lines.findIndex((l) => l.productId === productId && l.size === size);
    if (i === -1) commit(sanitize([...lines, { productId, size, qty }]));
    else commit(lines.map((l, j) => (j === i ? { ...l, qty: clampQty(l.qty + qty) } : l)));
  },
  setQty(productId: string, size: string, qty: number) {
    if (qty < 1) return bag.remove(productId, size);
    commit(lines.map((l) => (l.productId === productId && l.size === size ? { ...l, qty: clampQty(qty) } : l)));
  },
  remove(productId: string, size: string) {
    commit(lines.filter((l) => !(l.productId === productId && l.size === size)));
  },
  clear() {
    commit(EMPTY);
  },
};

/** Bag lines with product details and line totals, plus count and subtotal. */
export function useBag() {
  const current = useSyncExternalStore(
    subscribe,
    () => lines,
    () => EMPTY, // server render and first paint: empty, filled in after hydration
  );
  const items = current.flatMap((l) => {
    const product = findProduct(l.productId);
    return product ? [{ ...l, product, lineTotal: product.price * l.qty }] : [];
  });
  return {
    items,
    count: items.reduce((n, i) => n + i.qty, 0),
    subtotal: items.reduce((n, i) => n + i.lineTotal, 0),
    currency: items[0]?.product.currency ?? "PKR",
  };
}

/* ── Drawer open state (the slide-out bag, components/bag/BagDrawer) ── */

let drawerOpen = false;
const drawerListeners = new Set<() => void>();
const setDrawer = (open: boolean) => {
  if (open === drawerOpen) return;
  drawerOpen = open;
  drawerListeners.forEach((l) => l());
};

export const bagDrawer = {
  open: () => setDrawer(true),
  close: () => setDrawer(false),
};

export function useBagDrawer() {
  return useSyncExternalStore(
    (l) => {
      drawerListeners.add(l);
      return () => drawerListeners.delete(l);
    },
    () => drawerOpen,
    () => false,
  );
}

export const formatPrice = (amount: number, currency = "PKR") =>
  `${currency} ${new Intl.NumberFormat("en-PK", { maximumFractionDigits: 0 }).format(amount)}`;

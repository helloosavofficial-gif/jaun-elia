/**
 * Static mode switch.
 *
 * The OS "reduce motion" setting is deliberately NOT used to switch the
 * experience off: the client brief requires the hero video to play and the
 * rotation to follow scroll for every visitor (and Windows reports reduced
 * motion whenever "Animation effects" is off, which hid the whole experience).
 * Both are user-paced or brief; nothing loops or flashes.
 *
 * Append ?motion=off to get the static, resolved layout instead.
 */
export function prefersReduced(): boolean {
  if (typeof window === "undefined") return false;
  return new URLSearchParams(window.location.search).get("motion") === "off";
}

/**
 * OS "reduce motion" preference — used ONLY for the decorative image parallax
 * and the 360° viewer's automatic turn (the viewer itself stays usable).
 * Smooth scrolling, the hero video and the scroll scrubs stay on for everyone,
 * per the brief.
 */
export function prefersCalmerMotion(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

/** Maps p from [from, to] to [0, 1], clamped. */
export const range = (p: number, from: number, to: number) => clamp01((p - from) / (to - from));

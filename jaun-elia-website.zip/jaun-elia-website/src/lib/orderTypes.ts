/**
 * Shapes shared by the order API and the pages that call it. No server code
 * here, so client components can import it.
 */

export const ORDER_STATUSES = ["pending", "confirmed", "shipped", "delivered", "cancelled"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const PAYMENT_STATUSES = ["unpaid", "paid", "refunded"] as const;
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];

/** Payment routes the backend can take. Only cash on delivery is built; online gateways need merchant keys. */
export type PaymentMethod = "cod";

export const STATUS_LABEL: Record<OrderStatus, string> = {
  pending: "Received",
  confirmed: "Confirmed",
  shipped: "Shipped",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

export const PAYMENT_LABEL: Record<PaymentMethod, string> = {
  cod: "Cash on delivery",
};

export type OrderItem = { productId: string; name: string; size: string; qty: number; unitPrice: number; lineTotal: number };

/** What the customer sees on their order page. */
export type PublicOrder = {
  code: string;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  currency: string;
  subtotal: number;
  /** null = not yet set by the team. */
  shipping: number | null;
  total: number;
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  postcode: string | null;
  notes: string | null;
  items: OrderItem[];
  createdAt: string;
};

/** Everything, for /admin. */
export type AdminOrder = PublicOrder & {
  id: number;
  adminNote: string | null;
  updatedAt: string;
  events: { type: string; detail: string | null; createdAt: string }[];
};

/** GET /api/checkout */
export type CheckoutInfo = {
  enabled: boolean;
  methods: PaymentMethod[];
  shippingFee: number | null;
  stock: { total: number; remaining: number };
  maxQtyPerLine: number;
};

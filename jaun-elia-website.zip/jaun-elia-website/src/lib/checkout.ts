/**
 * The browser's side of checkout: small typed wrappers around the order API
 * (src/app/api). The server prices every line, checks stock and stores the
 * order; the page only sends what is in the bag and the delivery details.
 */
import type { CheckoutInfo, PublicOrder } from "./orderTypes";

export type CheckoutLine = { productId: string; size: string; qty: number };

export type Customer = {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  postcode: string;
  notes: string;
};

/** A failed call: a sentence for the visitor, plus per-field messages when the server sent them. */
export type ApiFailure = { message: string; fields: Record<string, string>; status: number };

async function call<T>(url: string, init?: RequestInit): Promise<{ ok: true; data: T } | ({ ok: false } & ApiFailure)> {
  try {
    const res = await fetch(url, {
      ...init,
      headers: { "Content-Type": "application/json", ...init?.headers },
      cache: "no-store",
    });
    const data = await res.json().catch(() => ({}));
    if (res.ok) return { ok: true, data: data as T };
    return {
      ok: false,
      status: res.status,
      message: typeof data.error === "string" ? data.error : "Something went wrong. Please try again.",
      fields: data.fields && typeof data.fields === "object" ? data.fields : {},
    };
  } catch {
    return {
      ok: false,
      status: 0,
      message: "We couldn't reach the shop. Check your connection and try again.",
      fields: {},
    };
  }
}

export const getCheckoutInfo = () => call<CheckoutInfo>("/api/checkout");

export const placeOrder = (body: {
  lines: CheckoutLine[];
  customer: Customer;
  paymentMethod: "cod";
  idempotencyKey: string;
}) => call<{ code: string; token: string; url: string }>("/api/orders", { method: "POST", body: JSON.stringify(body) });

export const getOrder = (code: string, token: string) =>
  call<PublicOrder>(`/api/orders/${encodeURIComponent(code)}?t=${encodeURIComponent(token)}`);

export const sendMessage = (body: Record<string, string>) =>
  call<{ ok: true }>("/api/contact", { method: "POST", body: JSON.stringify(body) });

export const joinReleaseList = (email: string, source: string) =>
  call<{ ok: true }>("/api/subscribe", { method: "POST", body: JSON.stringify({ email, source }) });

/** A key that makes a double-clicked "Place order" create one order, not two. */
export function newIdempotencyKey() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
}

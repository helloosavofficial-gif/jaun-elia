/**
 * Launch switches, read from environment variables so nothing in the code has
 * to change on launch day:
 *
 *   NEXT_PUBLIC_SITE_URL        the real domain, e.g. https://example.com
 *   NEXT_PUBLIC_SITE_INDEXABLE  "true" to let search engines index the site
 *
 * Until both are set the site stays out of search results (noindex + a
 * robots.txt that disallows everything).
 */
export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, "");

export const INDEXABLE = process.env.NEXT_PUBLIC_SITE_INDEXABLE === "true";

/** Public routes, for the sitemap. */
export const PUBLIC_ROUTES = [
  "/",
  "/campaign",
  "/shop",
  "/shop/jaun-elia-hoodie",
  "/about",
  "/contact",
  "/size-guide",
  "/shipping-returns",
  "/privacy",
  "/terms",
] as const;

/**
 * Lifestyle photography — people wearing the hoodie.
 *
 * PLACEHOLDERS: these are licensed stock photos (Unsplash License, free for
 * commercial use) of people in plain off-white hoodies, NOT the Jaun Elia
 * hoodie. They hold the layout until the campaign shoot of the real pieces.
 * To swap: put the shoot photos in public/media/lifestyle/, update `src`
 * (and sizes) below, and set `placeholder: false` — the "placeholder" labels
 * then disappear everywhere.
 */
export const lifestyle = {
  placeholder: true,
  note: "Placeholder photography · campaign shoot of the real pieces to come",
  /** For photos with the artwork composited on (`mockup: true`). */
  mockupNote: "Mockup: the artwork placed on stock photography · campaign shoot of the real pieces to come",
  photos: {
    hero: {
      /**
       * The stock photo with the Jaun Elia chest mark rendered onto the hoodie as
       * embroidery (from public/art/front-mark.png: displaced along the fabric's
       * folds, lit by the scene, raised with its own highlight and shadow, matched
       * to the photo's grain). Untouched original: hero-night.webp.
       * Not a photograph of the real garment.
       */
      src: "/media/lifestyle/hero-night-je2.webp",
      width: 1600,
      height: 2400,
      alt: "A woman in an off-white hoodie with Jaun Elia's name in Urdu calligraphy on the chest, hood up, on a city street at night (mockup)",
      mockup: true,
      /** Original (Unsplash License). */
      source: "https://images.unsplash.com/photo-1737139183708-8a071c15337c",
    },
    nightHood: {
      src: "/media/lifestyle/night-hood.webp",
      width: 1600,
      height: 2400,
      alt: "A woman holding up the hood of an off-white hoodie at night",
      source: "https://images.unsplash.com/photo-1737139158756-302cd6f3d02f",
    },
    nightGreen: {
      src: "/media/lifestyle/night-green.webp",
      width: 1600,
      height: 2400,
      alt: "A woman in an off-white hoodie against city lights",
      source: "https://images.unsplash.com/photo-1737139355588-b5656b8c7379",
    },
    dayWall: {
      src: "/media/lifestyle/day-wall.webp",
      width: 1600,
      height: 1067,
      alt: "A man in an off-white hoodie leaning on a stone wall in sunlight",
      source: "https://images.unsplash.com/photo-1738486260587-e4f1027fcaa3",
    },
    daySteps: {
      src: "/media/lifestyle/day-steps.webp",
      width: 1600,
      height: 2399,
      alt: "A man in an off-white hoodie standing on stone steps",
      source: "https://images.unsplash.com/photo-1738486260184-5b091fd0e90b",
    },
    dayLean: {
      src: "/media/lifestyle/day-lean.webp",
      width: 1600,
      height: 2399,
      alt: "A man in an off-white hoodie leaning against a pillar",
      source: "https://images.unsplash.com/photo-1738486260120-983c44c7703a",
    },
  },
};

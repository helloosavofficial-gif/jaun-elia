/**
 * Every piece of copy, every asset path and every on/off switch for the page.
 * Brand name, logo, price and release details are not final — nothing below
 * invents them. All display copy is provisional art direction, safe to replace.
 */

export const flags = {
  /** ن (noon) symbol from OSAV's brand-identity PROPOSAL (14 Oct 2026). Not client-approved. */
  showProposedMark: true,
  /** Edition (2,500) and price (PKR 20,000) — confirmed in conversation, hidden per the brief. */
  showCommercials: false,
  /** Temporary closing line; switch off once real release details exist. */
  showReleaseComingSoon: false,
};

const pad = (i: number) => String(i + 1).padStart(3, "0");

/** Image sequences extracted from the supplied videos, for scroll scrubbing. */
export const sequences = {
  rotation: {
    // 192 frames (24 per second) taken from the rotation footage
    count: 192,
    lg: (i: number) => `/frames/rotation-hd/lg/${pad(i)}.webp`, // 720×1280
    sm: (i: number) => `/frames/rotation-hd/sm/${pad(i)}.webp`, // 450×800
    width: 720,
    height: 1280,
    poster: "/media/rotation-poster.jpg",
    durationSeconds: 8,
  },
  details: {
    count: 64,
    lg: (i: number) => `/frames/details/lg/${pad(i)}.webp`, // 960×540
    sm: (i: number) => `/frames/details/sm/${pad(i)}.webp`, // 640×360
    width: 960,
    height: 540,
    poster: "/media/details-poster.jpg",
    durationSeconds: 7.9,
  },
};

export const site = {
  meta: {
    title: "The First Release — Jaun Elia Hoodie",
    description: "An off-white hoodie carrying the Urdu calligraphy of Jaun Elia's name, embroidered front and back. PKR 9,000.",
    shareImage: "/media/rotation-poster.jpg",
    shareAlt: "The off-white Jaun Elia hoodie in a dark studio",
  },

  label: "The First Release",

  /** Header wordmark — provisional; the brand name is not final. */
  wordmark: "Jaun Elia",

  /** Rotating announcement bar above the header. */
  announcements: ["The First Release — Jaun Elia", "Embroidered front and back", "Off-white · PKR 9,000"],

  nav: [
    { label: "Story", href: "#story" },
    { label: "In motion", href: "#motion" },
    { label: "Worn", href: "#worn" },
    { label: "Edition", href: "#edition" },
  ],

  // Shop calls to action across the landing page (price comes from content/products.ts).
  cta: {
    header: "Shop",
    hero: "Shop the hoodie",
    final: "Shop now",
    finalNote: "Off-white · Embroidered front and back",
  },

  media: {
    emergence: {
      src: "/media/emergence.mp4", // Desktop/JAun hoodir 2.mp4, audio stripped · 1280×720 · 8 s
      loadingPoster: "/media/emergence-start.jpg",
      fallback: "/media/emergence-end.jpg",
    },
    rotation: {
      src: "/media/rotation-scrub.mp4", // Desktop/Jaun elia hoodie rotation.mp4 · 720×1280 · 8 s · keyframe every 4 frames
      poster: "/media/rotation-poster.jpg",
    },
    frontChest: { src: "/media/front-chest.webp", width: 530, height: 662 },
    back: { src: "/media/back.webp", width: 577, height: 1024 },
    drawcord: { src: "/media/detail-drawcord.webp", width: 415, height: 394 },
    cuff: { src: "/media/detail-cuff.webp", width: 415, height: 347 },
    final: { src: "/media/rotation-poster.jpg", width: 720, height: 1280 },
  },

  // ── Home (app/page.tsx): the cover and three chapters ───────────────
  home: {
    cover: {
      eyebrow: "The First Release · After Dark",
      cta: "Shop the hoodie",
      film: "Watch the film",
      /** Shown as cover credits, alongside the price from content/products.ts. */
      credits: ["Off-white", "Embroidered front and back", "Edition of 2,500"],
      dateline: "Pakistan",
      note: "Concept render · not a photograph of the final garment",
    },
    contents: [
      { n: "I", label: "The words", href: "#words" },
      { n: "II", label: "The piece", href: "#piece" },
      { n: "III", label: "After dark", href: "#after-dark" },
      { n: "", label: "Colophon", href: "#colophon" },
    ],
    words: {
      index: "I",
      eyebrow: "The words",
      title: ["Words", "that stay."],
      /** What each mark on the back plate points to (heights from back.marks). */
      marks: [
        "Jaun Elia's name in Urdu calligraphy, set large.",
        "The name again in capitals, between two rules.",
        "Four lines of Urdu verse, shown as supplied — wording awaiting verification.",
        "Dots and a hairline lead the eye down through the verse.",
      ],
      caption: "Plate I · The back · Design mockup, not a photograph of the final garment",
    },
    piece: {
      index: "II",
      eyebrow: "The piece",
      title: ["The hoodie,", "front and back."],
      plates: [
        { label: "Plate II · The front", note: "Design mockup" },
        { label: "Plate III · The back", note: "Design mockup" },
      ],
      cta: "Choose your size",
      turn: "Turn it in 360°",
    },
    afterDark: {
      index: "III",
      eyebrow: "After dark",
      title: ["Worn", "after dark."],
      body: "Urdu poetry has long belonged to the night — mushairas that run past midnight, verses read under a single lamp. The campaign puts the hoodie in that hour.",
      cta: "Watch the film",
    },
    colophon: {
      eyebrow: "Colophon",
      title: "One edition, counted.",
      body: "The first release is a single run of 2,500 pieces. The count below is what remains of it.",
      cta: "Shop the hoodie",
    },
  },

  // ── Pre-launch teaser (components/teaser, no longer routed) ──────────
  launch: {
    /** Launch moment, ISO with timezone, e.g. "2026-12-01T20:00:00+05:00". null = "Launching soon", no countdown. */
    date: null as string | null,
    /**
     * Where "Notify me" sign-ups are POSTed as JSON { email }. null = not
     * connected yet (the form says so instead of pretending). For the backend team.
     */
    signupEndpoint: "/api/subscribe" as string | null,
  },
  teaser: {
    eyebrow: "The First Release",
    title: "Jaun Elia",
    line: "Urdu calligraphy, embroidered front and back on an off-white hoodie.",
    soon: "Launching soon",
    edition: "Edition of 2,500",
    notifyLabel: "Be first to know",
    notifyCta: "Notify me",
    renderNote: "Concept render",
  },

  // ── Opening film (components/scenes/Intro) ───────────────────────────
  intro: {
    /** Real making-of footage (e.g. "/media/making-of.mp4"). When set, it replaces the three chapters. */
    film: null as string | null,
    filmNote: "",
    chapters: ["Thread.", "Letter.", "Wear."],
    note: "Concept footage and design mockups · not photographs of the final garment",
  },

  // ── Scene copy (provisional) ─────────────────────────────────────────
  hero: {
    kicker: "The First Release",
    headline: "Jaun Elia",
    cta: "Discover the hoodie",
    renderNote: "Concept render",
    title: ["Words,", "made", "wearable."],
  },

  banner: { script: "Worn", title: "After dark", cta: "See it worn" },

  callig: {
    eyebrow: "The calligraphy",
    title: ["Words", "that stay."],
    lead: "Jaun Elia's name in Urdu calligraphy, embroidered on an off-white hoodie — small on the chest, large across the back above four lines of verse.",
    facts: [
      ["Front", "Urdu calligraphy on the left chest, “Jaun Elia” set beneath."],
      ["Back", "The name, “Jaun Elia”, four lines of verse and a reading column of dots."],
      ["Finish", "Embroidered front and back"],
      ["Colour", "Off-white"],
    ] as [string, string][],
  },

  closing: { script: "The First Release", title: "Wear the words", cta: "Shop the hoodie" },

  ticker: ["Jaun Elia", "Embroidered front and back", "Off-white", "Words that stay", "The First Release"],

  look: {
    index: "Worn",
    title: ["Worn in", "the city"],
  },

  editionCopy: {
    index: "The edition",
    title: "One edition, counted.",
    sub: "The first release is a single run. The figure below is what remains of it.",
  },

  reveal: {
    index: "01 — The reveal",
    lines: ["Words", "Made", "Wearable"],
    sub: "Wear the words that remain.",
    // the emergence footage is AI concept video; its artwork is not accurate
    footageNote: "Concept footage · not the final garment or artwork",
  },

  words: {
    index: "02 — The words",
    lines: ["Words", "That", "Stay"],
    sub: "A garment shaped around words, identity, and expression.",
  },

  motion: {
    index: "03 — In motion",
    headline: ["Seen from", "every side."],
    hint: "Scroll to turn",
    note: "Concept render, scrubbed by scroll — not a real-time 3D model or a photograph of the final garment.",
    // When each view faces the camera in the 8-second rotation (seconds).
    views: [
      { label: "Front", from: 0, to: 1.5 },
      { label: "Profile", from: 1.5, to: 3.4 },
      { label: "Back", from: 3.4, to: 5.6 },
      { label: "Profile", from: 5.6, to: 7.1 },
      { label: "Front", from: 7.1, to: 8.01 },
    ],
  },

  details: {
    index: "05 — The details",
    headline: ["Held", "close."],
    notes: [
      { n: "01", title: "The name", body: "Urdu calligraphy on the left chest, “Jaun Elia” set beneath." },
      { n: "02", title: "In hand", body: "Drawcords, eyelets and ribbing.", caption: "Detail footage — colour on screen may differ from the finished garment." },
      { n: "03", title: "Drawcords", body: "Dark tips, dark eyelets." },
      { n: "04", title: "Cuffs", body: "Ribbed at the wrist." },
    ],
  },

  back: {
    index: "06 — The back",
    lines: ["The", "Back"],
    body: "The name, “Jaun Elia”, four lines of verse and a reading column of dots.",
    verseNote: "Verse shown as supplied — awaiting verification.",
    // Leader lines point to these heights on the back image (fraction of its height).
    marks: [
      { label: "The name", at: 0.42 },
      { label: "Jaun Elia", at: 0.533 },
      { label: "The verse", at: 0.655 },
      { label: "Reading column", at: 0.79 },
    ],
  },

  final: {
    lines: ["The story", "starts", "here."],
    comingSoon: "Release information coming soon.",
    imageNote: "Image: concept render, not a photograph of the final garment",
    commercials: "Edition of 2,500 · PKR 9,000",
  },

  footer: "Concept prototype by OSAV — not for public release.",

  // ── Used by the image/3D viewer (src/components/viewer) for a future GLB. Not on the page. ──
  garment: {
    modelUrl: "/models/hoodie.glb",
    front: { src: "/media/front.webp", width: 830, height: 1254 },
    back: { src: "/media/back.webp", width: 577, height: 1024 },
    /** The same mockups with the studio backdrop removed (transparent), for staging on ink. */
    frontCutout: { src: "/media/front-3d.webp", width: 816, height: 1105 },
    backCutout: { src: "/media/back-3d.webp", width: 569, height: 843 },
  },
  viewer: {
    imageMode: { value: "Images from the design mockup — 3D model in production" },
    modelMode: { value: "Interactive 3D model" },
    hint: { value: "Drag or use arrow keys to turn" },
  },
};

/**
 * The edition: 2,500 pieces, all made and in the warehouse (confirmed by the
 * client). These figures seed the inventory table on first run and are what
 * the page shows before the live count arrives (and if the API can't be reached).
 *
 * Live count: GET /api/stock → { total, remaining, live } (src/app/api/stock).
 * Placing an order takes pieces off it; cancelling one in /admin puts them back.
 */
export const edition = {
  total: 2500,
  /** Pieces left before any sale. */
  remaining: 2500,
  /** False for the static fallback; the API answers live: true. */
  live: false,
};

export type Stock = { total: number; remaining: number; live: boolean };

const fallback = (): Stock => ({ total: edition.total, remaining: edition.remaining, live: edition.live });

/** Current stock from the inventory API; the static figures if it can't be reached. */
export async function fetchStock(): Promise<Stock> {
  if (typeof window === "undefined") return fallback();
  try {
    const res = await fetch("/api/stock", { cache: "no-store" });
    if (!res.ok) return fallback();
    const s = (await res.json()) as Partial<Stock>;
    if (typeof s.total !== "number" || typeof s.remaining !== "number") return fallback();
    return { total: s.total, remaining: s.remaining, live: s.live === true };
  } catch {
    return fallback();
  }
}

export const formatCount = (n: number) => new Intl.NumberFormat("en-PK").format(n);

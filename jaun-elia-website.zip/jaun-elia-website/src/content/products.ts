/**
 * Product data for the shop, kept separate from campaign copy.
 *
 * Rule for this file: only facts the client has confirmed get a value.
 * Anything unconfirmed is `null` and shows on the site as "To be confirmed"
 * (see PENDING) — fill it in here when the client supplies it.
 */

/** What the site shows wherever a value is still `null`. */
export const PENDING = "To be confirmed";

/**
 * Most of one size a visitor can put in the bag. A UI limit for the
 * prototype, not a confirmed business rule — change it freely.
 */
export const MAX_QTY_PER_LINE = 10;

export const hoodieProduct = {
  id: "jaun-elia-hoodie",
  slug: "jaun-elia-hoodie",
  name: "Jaun Elia Hoodie",
  // Confirmed by the client in chat (supersedes the earlier 20,000 working figure).
  price: 9000,
  currency: "PKR",
  priceLabel: "PKR 9,000",
  // Placeholder size run — not yet confirmed by the client.
  sizes: ["S", "M", "L", "XL"] as string[],
  sizesConfirmed: false,
  colour: "Off-white",
  finish: "Embroidered front and back",

  /**
   * Listing images: the client's design mockups (the real artwork on a
   * rendered hoodie) — not photographs, and labelled as mockups wherever shown.
   * No AI concept imagery on product listings.
   */
  images: {
    front: { src: "/media/front.webp", width: 830, height: 1254, alt: "The Jaun Elia hoodie from the front — design mockup" },
    back: { src: "/media/back.webp", width: 577, height: 1024, alt: "The Jaun Elia hoodie from the back — design mockup" },
    label: "Design mockup",
  },

  /** Confirmed: what the garment is. Written only from facts above. */
  description:
    "An off-white hoodie carrying the Urdu calligraphy of Jaun Elia's name, embroidered front and back.",

  /** Unconfirmed product details — null until the client supplies them. */
  details: {
    fabric: null as string | null, // composition, e.g. "100% cotton"
    weight: null as string | null, // e.g. "400 GSM"
    fit: null as string | null, // e.g. "Relaxed"
    madeIn: null as string | null,
  },
  care: null as string[] | null,
  /** Garment measurements per size, e.g. { S: { chest: "56 cm", length: "70 cm" } }. */
  measurements: null as Record<string, Record<string, string>> | null,
  /** Stock per size. null = unknown, so the site never claims "in stock" or "sold out". */
  stock: null as Record<string, number> | null,
};

export type Product = typeof hoodieProduct;
export type HoodieProduct = Product;

/** Every product on sale. A single-product launch for now. */
export const products: Product[] = [hoodieProduct];

export const findProduct = (id: string) => products.find((p) => p.id === id);

/** "In stock" / "Sold out" only when stock is known; otherwise PENDING. */
export function availability(p: Product, size: string): { label: string; canBuy: boolean } {
  const n = p.stock?.[size];
  if (n === undefined) return { label: `Availability: ${PENDING.toLowerCase()}`, canBuy: true };
  return n > 0 ? { label: "In stock", canBuy: true } : { label: "Sold out", canBuy: false };
}

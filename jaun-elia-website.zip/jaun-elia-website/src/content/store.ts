/**
 * Business details for the shop and the supporting pages.
 * Every value is null until the client confirms it; the site shows PENDING
 * (content/products.ts) in its place and never fills the gap with a guess.
 */
export const store = {
  /** Legal or trading name for the Terms page. */
  businessName: null as string | null,
  contact: {
    email: null as string | null,
    phone: null as string | null,
    whatsapp: null as string | null,
    hours: null as string | null,
  },
  shipping: {
    regions: null as string | null, // e.g. "Pakistan only"
    cost: null as string | null,
    deliveryTime: null as string | null,
  },
  returns: {
    policy: null as string | null,
  },
  /** Payment methods actually connected. Empty until checkout is integrated. */
  paymentMethods: [] as string[],
};

import type { Metadata } from "next";
import Link from "next/link";
import { InfoPage, InfoRows, InfoSection } from "@/components/info/InfoPage";
import { store } from "@/content/store";

export const metadata: Metadata = {
  title: "Shipping & returns",
  description: "Delivery, cash on delivery and returns for Jaun Elia orders.",
  alternates: { canonical: "/shipping-returns" },
};

const s = store.shipping;
const ready = Boolean(s.regions && s.cost && s.deliveryTime && store.returns.policy);

export default function ShippingReturnsPage() {
  return (
    <InfoPage
      kicker="Help"
      title="Shipping & returns"
      draftNote={ready ? undefined : "Shipping and returns terms have not been confirmed yet."}
    >
      <InfoSection title="Shipping">
        <InfoRows
          rows={[
            ["Delivers to", s.regions],
            ["Cost", s.cost],
            ["Delivery time", s.deliveryTime],
          ]}
        />
      </InfoSection>
      <InfoSection title="Returns">
        <InfoRows rows={[["Policy", store.returns.policy]]} />
      </InfoSection>
      <InfoSection title="Orders">
        <p>
          Orders are paid in cash on delivery. Where shipping isn&rsquo;t yet confirmed above, we confirm the cost with
          you before your order ships.
        </p>
        <p>
          Questions: <Link href="/contact">contact</Link>.
        </p>
      </InfoSection>
    </InfoPage>
  );
}

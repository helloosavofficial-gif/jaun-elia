import type { Metadata } from "next";
import Link from "next/link";
import { ORDER_STATUSES, PAYMENT_LABEL, STATUS_LABEL, type OrderStatus } from "@/lib/orderTypes";
import { formatMoney } from "@/server/money";
import { getOrderForCustomer } from "@/server/orders";
import styles from "./order.module.css";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Your order",
  robots: { index: false, follow: false },
  // the link carries a private token: never pass it on to other sites
  referrer: "no-referrer",
};

type Props = { params: Promise<{ code: string }>; searchParams: Promise<{ t?: string }> };

const HEADLINE: Record<OrderStatus, [title: string, line: string]> = {
  pending: ["Thank you.", "We have your order. We'll contact you to confirm it before it ships."],
  confirmed: ["Confirmed.", "Your order is confirmed and being prepared."],
  shipped: ["On its way.", "Your order has left us and is with the courier."],
  delivered: ["Delivered.", "Your order has arrived. We hope it stays with you."],
  cancelled: ["Cancelled.", "This order has been cancelled. If you didn't expect this, contact us."],
};

const STEPS = ORDER_STATUSES.filter((s) => s !== "cancelled");

const dateFmt = new Intl.DateTimeFormat("en-PK", { dateStyle: "long", timeStyle: "short", timeZone: "Asia/Karachi" });

/** The customer's order, reached from the private link after checkout and in their email. */
export default async function OrderPage({ params, searchParams }: Props) {
  const { code } = await params;
  const { t } = await searchParams;
  const order = getOrderForCustomer(code, t ?? "");

  if (!order) {
    return (
      <main id="main" tabIndex={-1} className={styles.page}>
        <header className={styles.head}>
          <p className={styles.kicker}>Order</p>
          <h1 className={styles.title}>Not found.</h1>
          <p className={styles.lede}>
            This link doesn&rsquo;t match an order. Use the link from your confirmation email, or{" "}
            <Link href="/contact">contact us</Link> with your order number.
          </p>
        </header>
      </main>
    );
  }

  const [title, line] = HEADLINE[order.status];
  const reached = STEPS.indexOf(order.status as (typeof STEPS)[number]);
  const pieces = order.items.reduce((n, i) => n + i.qty, 0);

  return (
    <main id="main" tabIndex={-1} className={styles.page}>
      <header className={styles.head}>
        <p className={styles.kicker}>
          Order <span className={styles.code}>{order.code}</span>
        </p>
        <h1 className={styles.title}>{title}</h1>
        <p className={styles.lede}>{line}</p>
      </header>

      {order.status !== "cancelled" && (
        <ol className={styles.progress} aria-label="Order progress">
          {STEPS.map((s, i) => (
            <li key={s} data-done={i <= reached} aria-current={i === reached ? "step" : undefined}>
              <span className={styles.dot} aria-hidden />
              {STATUS_LABEL[s]}
            </li>
          ))}
        </ol>
      )}

      <div className={styles.grid}>
        <section className={styles.block} aria-labelledby="items-h">
          <h2 id="items-h">
            {pieces} {pieces === 1 ? "piece" : "pieces"}
          </h2>
          <ul className={styles.items}>
            {order.items.map((i) => (
              <li key={`${i.productId}-${i.size}`}>
                <span>
                  {i.name}
                  <small>
                    Size {i.size} · {i.qty} × {formatMoney(i.unitPrice, order.currency)}
                  </small>
                </span>
                <span>{formatMoney(i.lineTotal, order.currency)}</span>
              </li>
            ))}
          </ul>
          <dl className={styles.totals}>
            <div>
              <dt>Subtotal</dt>
              <dd>{formatMoney(order.subtotal, order.currency)}</dd>
            </div>
            <div>
              <dt>Shipping</dt>
              <dd>
                {order.shipping === null
                  ? "To be confirmed"
                  : order.shipping === 0
                    ? "Free"
                    : formatMoney(order.shipping, order.currency)}
              </dd>
            </div>
            <div className={styles.total}>
              <dt>Total</dt>
              <dd>
                {formatMoney(order.total, order.currency)}
                {order.shipping === null && <small> + shipping</small>}
              </dd>
            </div>
          </dl>
        </section>

        <section className={styles.block} aria-labelledby="deliver-h">
          <h2 id="deliver-h">Delivery</h2>
          <address className={styles.address}>
            {order.name}
            <br />
            {order.address}
            <br />
            {order.city}
            {order.postcode ? ` ${order.postcode}` : ""}
            <br />
            {order.phone}
          </address>
          {order.notes && <p className={styles.note}>&ldquo;{order.notes}&rdquo;</p>}

          <h2>Payment</h2>
          <p className={styles.plain}>
            {PAYMENT_LABEL[order.paymentMethod]}
            {order.paymentStatus === "paid" ? " · Paid" : order.paymentStatus === "refunded" ? " · Refunded" : ""}
          </p>

          <h2>Placed</h2>
          <p className={styles.plain}>{dateFmt.format(new Date(order.createdAt))}</p>
        </section>
      </div>

      <footer className={styles.foot}>
        <p>
          Keep this page: its link is private to you and always shows the latest status. A copy was sent to{" "}
          <strong>{order.email}</strong>.
        </p>
        <p>
          Questions? <Link href="/contact">Contact us</Link> with your order number.
        </p>
        <Link href="/shop" className={styles.secondary}>
          Back to the shop
        </Link>
      </footer>
    </main>
  );
}

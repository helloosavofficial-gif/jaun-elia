import type { Metadata } from "next";
import { InfoPage, InfoRows, InfoSection } from "@/components/info/InfoPage";
import { store } from "@/content/store";

export const metadata: Metadata = {
  title: "Privacy",
  description: "What the Jaun Elia site keeps about you when you order or write to us, and what it does not.",
  alternates: { canonical: "/privacy" },
};

/**
 * Privacy notice describing what this site actually does (checked in code):
 * a localStorage key for the bag, sessionStorage for an unfinished checkout,
 * orders / messages / release-list emails stored on our server, emails sent
 * through the configured provider, no cookies for visitors (only the team's
 * admin sign-in), no analytics. Must be reviewed before launch.
 */
export default function PrivacyPage() {
  return (
    <InfoPage
      kicker="Legal"
      title="Privacy"
      intro={<p>What this site keeps about you, and what it does not.</p>}
      draftNote="This notice describes how the site works and is awaiting legal review before launch."
    >
      <InfoSection title="Who we are">
        <InfoRows
          rows={[
            ["Business", store.businessName],
            ["Privacy contact", store.contact.email],
          ]}
        />
      </InfoSection>
      <InfoSection title="When you order">
        <p>
          To deliver your order we keep your name, email, phone number, delivery address and any delivery notes, with
          what you ordered and its status. We use them to confirm, deliver and support your order, and to email you
          about it. We don&rsquo;t sell them or use them for advertising.
        </p>
        <p>Orders are paid in cash on delivery, so no card or bank details are entered on this site.</p>
      </InfoSection>
      <InfoSection title="When you write to us">
        <p>
          Messages sent through the contact form are kept with the name, email and (if given) phone number and order
          number you include, so we can reply.
        </p>
      </InfoSection>
      <InfoSection title="Release list">
        <p>
          If you ask to hear about releases, we keep your email address for that alone. You can ask to be removed at
          any time through the contact page.
        </p>
      </InfoSection>
      <InfoSection title="In your browser">
        <p>
          Your bag (product, size and quantity) is saved in your browser&rsquo;s local storage so it&rsquo;s still there
          when you come back. Details typed at checkout are kept in your browser for the visit, so going back to your
          bag doesn&rsquo;t lose them, and are cleared once the order is placed.
        </p>
      </InfoSection>
      <InfoSection title="Cookies and tracking">
        <p>
          This site sets no cookies for visitors and runs no analytics, advertising or tracking scripts. Its fonts,
          images and video are served from this site itself. The only cookie is a sign-in cookie used by our own team
          on the order-management pages.
        </p>
      </InfoSection>
      <InfoSection title="Email and hosting">
        <p>
          Order and message emails are sent through an email delivery provider. Like any website, the host may keep
          standard technical logs, such as IP address, browser type and the pages requested, to run and protect the
          service.
        </p>
        <InfoRows
          rows={[
            ["Hosting provider", null],
            ["Email provider", null],
            ["How long we keep order details", null],
          ]}
        />
      </InfoSection>
      <InfoSection title="Your choices">
        <p>
          You can ask to see, correct or delete the details we hold about you through the contact page. We may need to
          keep some order records where the law requires it.
        </p>
      </InfoSection>
    </InfoPage>
  );
}

import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Button, Couplet, Eyebrow, MarginNote, ReadingColumn, Reveal, Section, TextLink } from "@/components/diwan";
import { BackPlate } from "@/components/home/BackPlate";
import { Garment3D } from "@/components/home/Garment3D";
import { CoverClock } from "@/components/home/CoverClock";
import { FilmOnce } from "@/components/scenes/FilmOnce";
import { StockCounter } from "@/components/StockCounter";
import { lifestyle } from "@/content/lifestyle";
import { hoodieProduct } from "@/content/products";
import { site } from "@/content/site";
import styles from "./home.module.css";

export const metadata: Metadata = {
  title: { absolute: site.meta.title },
  alternates: { canonical: "/" },
};

const product = hoodieProduct;
const productHref = `/shop/${product.slug}`;

/**
 * Home: a cover and three short chapters, read like a slim diwan.
 * Cover (ink) — the hoodie and the line, with cover credits and contents.
 * I. The words (paper) — the back as an annotated plate.
 * II. The piece (ink) — the front, the facts and the way to buy.
 * III. After dark (bleed) — the night, and the way into the film.
 * Colophon — the edition counted.
 */
export default function Home() {
  const { cover, contents, words, piece, afterDark, colophon } = site.home;
  const [first, ...rest] = site.hero.title; // "Words," / "made wearable."
  const night = lifestyle.photos.hero;

  return (
    <main id="main" tabIndex={-1} className={styles.home}>
      {/* ── COVER ─────────────────────────────────────────────────────── */}
      <section className={styles.cover} aria-labelledby="cover-title">
        <div className={styles.coverFilm}>
          <FilmOnce
            src={site.media.rotation.src}
            poster={site.media.rotation.poster}
            label="The Jaun Elia hoodie turning once in a dark studio (concept render)"
            className={styles.coverVideo}
          />
        </div>

        <div className={styles.coverText}>
          <Eyebrow marker>{cover.eyebrow}</Eyebrow>
          <Couplet as="h1" id="cover-title" size="display" first={first} second={rest.join(" ")} className={styles.coverTitle} />
          <p className={styles.coverLede}>{product.description}</p>
          <div className={styles.coverActions}>
            <Button href={productHref} size="lg" arrow>
              {cover.cta}
            </Button>
            <TextLink href="/campaign" arrow>
              {cover.film}
            </TextLink>
          </div>
        </div>

        <CoverClock label={cover.dateline} className={styles.dateline} />

        <nav className={styles.contents} aria-label="On this page">
          <p className={styles.contentsTitle}>Contents</p>
          <ol>
            {contents.map((c) => (
              <li key={c.href}>
                <a href={c.href}>
                  <span className={styles.contentsNo}>{c.n}</span>
                  <span>{c.label}</span>
                </a>
              </li>
            ))}
          </ol>
        </nav>

        <dl className={styles.credits}>
          {[...cover.credits, product.priceLabel].map((c, i) => (
            <div key={c}>
              <dt className={styles.srOnly}>{["Colour", "Finish", "Edition", "Price"][i]}</dt>
              <dd>{c}</dd>
            </div>
          ))}
        </dl>

        <p className={styles.coverNote}>{cover.note}</p>
      </section>

      {/* ── I. THE WORDS ──────────────────────────────────────────────── */}
      <Section id="words" tone="paper" layout="bleed" pad="none" className={styles.words} aria-labelledby="words-title">
        <div className={styles.wordsPlate}>
          <Reveal variant="fade">
            <BackPlate
              image={{
                src: site.media.back.src,
                width: site.media.back.width,
                height: site.media.back.height,
                alt: "Back of the hoodie: Jaun Elia's name in large Urdu calligraphy, JAUN ELIA in capitals, four lines of Urdu verse and a column of dots",
              }}
              marks={site.back.marks.map((m, i) => ({ ...m, body: words.marks[i] }))}
              caption={words.caption}
            />
          </Reveal>
        </div>
        <div className={styles.wordsText}>
          <div className={styles.chapter}>
            <span className={styles.chapterNo}>{words.index}</span>
            <Eyebrow>{words.eyebrow}</Eyebrow>
          </div>
          <Couplet id="words-title" size="title" first={words.title[0]} second={words.title[1]} />
          <p className={styles.lead}>{site.callig.lead}</p>
          <ReadingColumn variant="divider" orientation="horizontal" length="96px" className={styles.rule} />
          <MarginNote label="Front">{site.callig.facts[0][1]}</MarginNote>
        </div>
      </Section>

      {/* ── II. THE PIECE ─────────────────────────────────────────────── */}
      <Section id="piece" tone="ink" layout="bleed" pad="none" className={styles.piece} aria-labelledby="piece-title">
        <div className={styles.plates}>
          {[
            { img: site.garment.frontCutout, alt: "The Jaun Elia hoodie from the front: off-white, the Urdu name on the left chest", ...piece.plates[0] },
            {
              img: site.garment.backCutout,
              alt: "The Jaun Elia hoodie from the back: the name in large Urdu calligraphy, JAUN ELIA, four lines of verse and a column of dots",
              ...piece.plates[1],
            },
          ].map((p, i) => (
            <figure key={p.label} className={styles.plateFig}>
              <Reveal variant="ink" delay={i * 120} className={styles.plateImage}>
                <Garment3D
                  src={p.img.src}
                  width={p.img.width}
                  height={p.img.height}
                  alt={p.alt}
                  sizes="(max-width: 899px) 92vw, 34vw"
                  phase={i * 2.4}
                />
              </Reveal>
              <figcaption className={styles.plateCaption}>
                <span>{p.label}</span>
                <span>{p.note}</span>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className={styles.pieceHead}>
          <div className={styles.chapter}>
            <span className={styles.chapterNo}>{piece.index}</span>
            <Eyebrow>{piece.eyebrow}</Eyebrow>
          </div>
          <Couplet id="piece-title" size="heading" first={piece.title[0]} second={piece.title[1]} />
        </div>

        <div className={styles.pieceText}>
          <div className={styles.priceRow}>
            <p className={styles.productName}>{product.name}</p>
            <p className={styles.price}>{product.priceLabel}</p>
          </div>
          <dl className={styles.facts}>
            <div>
              <dt>Colour</dt>
              <dd>{product.colour}</dd>
            </div>
            <div>
              <dt>Finish</dt>
              <dd>{product.finish}</dd>
            </div>
            <div>
              <dt>Edition</dt>
              <dd>2,500 pieces</dd>
            </div>
            <div>
              <dt>Sizes</dt>
              <dd>
                {product.sizes.join(" · ")}
                {!product.sizesConfirmed && <span className={styles.factNote}>Size run to be confirmed</span>}
              </dd>
            </div>
          </dl>
          <div className={styles.pieceActions}>
            <Button href={productHref} block arrow>
              {piece.cta}
            </Button>
            <TextLink href={`${productHref}?view=360`} arrow>
              {piece.turn}
            </TextLink>
          </div>
        </div>
      </Section>

      {/* ── III. AFTER DARK ───────────────────────────────────────────── */}
      <Section id="after-dark" tone="ink" layout="bleed" pad="none" className={styles.night} aria-labelledby="night-title">
        <div className={styles.nightText}>
          <div className={styles.chapter}>
            <span className={styles.chapterNo}>{afterDark.index}</span>
            <Eyebrow>{afterDark.eyebrow}</Eyebrow>
          </div>
          <Couplet id="night-title" size="display" first={afterDark.title[0]} second={afterDark.title[1]} />
          <p className={styles.nightBody}>{afterDark.body}</p>
          <TextLink href="/campaign" arrow>
            {afterDark.cta}
          </TextLink>
        </div>
        <figure className={styles.nightFig}>
          <Image src={night.src} width={night.width} height={night.height} alt={night.alt} sizes="(max-width: 899px) 100vw, 50vw" className={styles.nightImg} />
          {lifestyle.placeholder && (
            <figcaption className={styles.nightNote}>{night.mockup ? lifestyle.mockupNote : lifestyle.note}</figcaption>
          )}
        </figure>
      </Section>

      {/* ── COLOPHON ──────────────────────────────────────────────────── */}
      <Section id="colophon" tone="ink" layout="wide" pad="lg" className={styles.colophon} aria-labelledby="colophon-title">
        <ReadingColumn variant="divider" length="64px" className={styles.colophonMark} />
        <Eyebrow>{colophon.eyebrow}</Eyebrow>
        <h2 id="colophon-title" className={styles.colophonTitle}>
          {colophon.title}
        </h2>
        <p className={styles.colophonBody}>{colophon.body}</p>
        <StockCounter variant="large" face="serif" className={styles.counter} />
        <div className={styles.colophonActions}>
          <Button href={productHref} size="lg" arrow>
            {colophon.cta}
          </Button>
          <Link href="/about" className={styles.storyLink}>
            Read the story
          </Link>
        </div>
      </Section>
    </main>
  );
}

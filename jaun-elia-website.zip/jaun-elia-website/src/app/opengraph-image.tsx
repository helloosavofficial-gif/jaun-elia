import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { ImageResponse } from "next/og";
import { site } from "@/content/site";
import { hoodieProduct } from "@/content/products";

export const alt = site.meta.shareAlt;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/**
 * Landscape share card (1200×630) composed from the existing rotation poster —
 * no new artwork, just the poster beside the page title.
 */
export default async function OpengraphImage() {
  const poster = await readFile(join(process.cwd(), "public", "media", "rotation-poster.jpg"));
  const src = `data:image/jpeg;base64,${poster.toString("base64")}`;

  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", background: "#080808", color: "#f2eee6" }}>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "72px 80px" }}>
          <div style={{ fontSize: 22, letterSpacing: 6, textTransform: "uppercase", color: "rgba(242,238,230,0.6)" }}>
            {site.label}
          </div>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <div style={{ fontSize: 76, lineHeight: 1.05, letterSpacing: -1 }}>{hoodieProduct.name}</div>
            <div style={{ fontSize: 26, marginTop: 24, color: "rgba(242,238,230,0.6)" }}>
              {`${hoodieProduct.finish} · ${hoodieProduct.priceLabel}`}
            </div>
          </div>
        </div>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={src} width={354} height={630} alt="" style={{ objectFit: "cover" }} />
      </div>
    ),
    size,
  );
}

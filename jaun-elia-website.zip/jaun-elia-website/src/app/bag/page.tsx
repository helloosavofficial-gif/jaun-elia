import type { Metadata } from "next";
import { BagView } from "@/components/bag/BagView";
import styles from "./bag.module.css";

export const metadata: Metadata = {
  title: "Bag",
  robots: { index: false, follow: false },
};

export default function BagPage() {
  return (
    <main id="main" tabIndex={-1} className={styles.page}>
      <h1 className={styles.title}>Bag</h1>
      <BagView />
    </main>
  );
}

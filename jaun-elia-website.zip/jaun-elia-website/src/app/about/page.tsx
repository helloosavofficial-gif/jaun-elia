import type { Metadata } from "next";
import Image from "next/image";
import { Couplet, Eyebrow, MarginNote, ReadingColumn, Reveal, Section, TextLink } from "@/components/diwan";
import { edition, formatCount } from "@/content/edition";
import { hoodieProduct } from "@/content/products";
import { site } from "@/content/site";
import styles from "./about.module.css";

export const metadata: Metadata = {
  title: "Story",
  description: hoodieProduct.description,
  alternates: { canonical: "/about" },
};

/**
 * The story (About and Story, merged): one manuscript page of confirmed facts
 * about the garment and public facts about the poet, with notes in the
 * margins. The brand's own name and story are not final, so they are marked
 * as pending rather than written.
 */
export default function StoryPage() {
  return (
    <main id="main" tabIndex={-1} className={styles.page}>
      <Section tone="paper" layout="manuscript" pad="none" className={styles.head}>
        <Eyebrow marker>The story</Eyebrow>
        <Couplet as="h1" size="title" first="A garment" second="shaped around words." className={styles.title} />
        <p className={styles.lede}>{hoodieProduct.description}</p>
      </Section>

      <Section tone="paper" layout="manuscript" pad="none" className={styles.body} aria-label="The story">
        <MarginNote side="start" label="Pending">
          The brand&apos;s name and story are still being finalised; this page carries only confirmed details.
        </MarginNote>

        <section className={styles.part} aria-labelledby="poet">
          <h2 id="poet" className={styles.partTitle}>
            The poet
          </h2>
          <p>Jaun Elia (1931–2002) was an Urdu poet, born in Amroha and later based in Karachi. The hoodie carries his name.</p>
        </section>
        <MarginNote side="end" label="Jaun Elia">
          1931–2002 · Amroha, later Karachi
        </MarginNote>

        <section className={styles.part} aria-labelledby="words">
          <h2 id="words" className={styles.partTitle}>
            The words on the garment
          </h2>
          <p>{site.callig.facts[0][1]} On the back: {site.back.body.charAt(0).toLowerCase() + site.back.body.slice(1)}</p>
          <Reveal variant="ink" className={styles.figure}>
            <Image
              src="/media/edit/back-name-hd.webp"
              width={1440}
              height={1080}
              alt="The name in Urdu calligraphy across the back, with JAUN ELIA beneath and the reading column of dots (the back artwork)"
              sizes="(max-width: 767px) 90vw, 440px"
            />
          </Reveal>
          <p className={styles.caption}>The name across the back · the artwork, not a photograph of the final garment</p>
        </section>
        <MarginNote side="end" label="The verse">
          {site.back.verseNote}
        </MarginNote>

        <section className={styles.part} aria-labelledby="column">
          <h2 id="column" className={styles.partTitle}>
            The reading column
          </h2>
          <p>
            Down the back, dots and a hairline run from the name through the verse. The site borrows them as its signature — they
            mark sections, notes and progress wherever you see them.
          </p>
          <ReadingColumn variant="divider" orientation="horizontal" length="120px" className={styles.column} />
        </section>

        <section className={styles.part} aria-labelledby="edition">
          <h2 id="edition" className={styles.partTitle}>
            One edition
          </h2>
          <p>
            The first release is a single run of {formatCount(edition.total)} pieces: {hoodieProduct.colour.toLowerCase()},{" "}
            {hoodieProduct.finish.toLowerCase()}, {hoodieProduct.priceLabel}.
          </p>
        </section>
        <MarginNote side="start" label="Edition">
          {formatCount(edition.total)} pieces
        </MarginNote>

        <section className={styles.part} aria-labelledby="night">
          <h2 id="night" className={styles.partTitle}>
            After dark
          </h2>
          <p>{site.home.afterDark.body}</p>
        </section>

        <div className={styles.links}>
          <TextLink href={`/shop/${hoodieProduct.slug}`} arrow>
            See the hoodie
          </TextLink>
          <TextLink href="/campaign" arrow>
            Watch the film
          </TextLink>
        </div>
      </Section>
    </main>
  );
}

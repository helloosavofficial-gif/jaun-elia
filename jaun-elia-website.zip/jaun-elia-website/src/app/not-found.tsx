import type { Metadata } from "next";
import Link from "next/link";
import { Couplet, Eyebrow, ReadingColumn, TextLink } from "@/components/diwan";
import styles from "./not-found.module.css";

export const metadata: Metadata = {
  title: "Page not found",
  robots: { index: false, follow: false },
};

/** Any unknown address: a blank page of the diwan, and the way back. */
export default function NotFound() {
  return (
    <main id="main" tabIndex={-1} className={styles.page}>
      <ReadingColumn variant="divider" length="72px" className={styles.mark} />
      <Eyebrow>Page not found</Eyebrow>
      <Couplet as="h1" size="title" first="A page" second="left blank." align="center" reveal={false} />
      <p className={styles.body}>The address may be mistyped, or the page has moved.</p>
      <div className={styles.links}>
        <Link href="/" className={styles.primary}>
          Back to the cover
        </Link>
        <TextLink href="/shop" arrow>
          Shop
        </TextLink>
      </div>
    </main>
  );
}

import type { Metadata } from "next";
import { notFound } from "next/navigation";

export const metadata: Metadata = {
  title: "Draft studio (internal)",
  robots: { index: false, follow: false },
};

/**
 * /studio is an internal draft (a hand-built approximation of the hoodie, not
 * the real garment). Available while developing; a 404 in production builds.
 */
export default function StudioLayout({ children }: { children: React.ReactNode }) {
  if (process.env.NODE_ENV === "production") notFound();
  return children;
}

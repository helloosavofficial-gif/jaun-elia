"use client";

import dynamic from "next/dynamic";
import { useMemo, useRef, useState } from "react";
import { presets, type ViewState } from "@/components/studio-draft/store";
import { useDragRotate } from "@/components/studio-draft/useDragRotate";
import styles from "./studio.module.css";

const HoodieScene = dynamic(
  () => import("@/components/studio-draft/HoodieScene").then((m) => m.HoodieScene),
  { ssr: false },
);

const backgrounds = {
  Charcoal: "#12100e",
  Stone: "#8f877b",
  Ivory: "#efe9df",
  Black: "#000000",
} as const;

type PresetName = keyof typeof presets;

const labels: Record<PresetName, string> = {
  hero: "Hero",
  front: "Front",
  frontDetail: "Chest detail",
  back: "Back",
  backDetail: "Back detail",
  threeQuarter: "Three-quarter",
};

/**
 * INTERNAL DRAFT — not client-facing.
 * Studio for the hand-built procedural hoodie (an approximation, not the real
 * garment). Kept only as an internal reference; the landing page uses the
 * product images until a real GLB model is supplied.
 */
export default function Studio() {
  const view = useMemo<ViewState>(() => ({ ...presets.hero, spin: 0, drag: 0 }), []);
  const [preset, setPreset] = useState<PresetName>("hero");
  const [bg, setBg] = useState<keyof typeof backgrounds>("Charcoal");
  const [spin, setSpin] = useState(false);
  const stage = useRef<HTMLDivElement>(null);
  useDragRotate(stage, view);

  const apply = (name: PresetName) => {
    Object.assign(view, presets[name], { drag: 0 });
    setPreset(name);
  };

  const toggleSpin = () => {
    view.spin = spin ? 0 : 1;
    setSpin(!spin);
  };

  const download = () => {
    const canvas = stage.current?.querySelector("canvas");
    if (!canvas) return;
    const a = document.createElement("a");
    a.href = canvas.toDataURL("image/png");
    a.download = `hoodie-concept-${preset}-${bg.toLowerCase()}.png`;
    a.click();
  };

  return (
    <div className={styles.studio} style={{ background: backgrounds[bg] }}>
      <div ref={stage} className={styles.stage}>
        <HoodieScene key={bg} view={view} background={backgrounds[bg]} preserveDrawingBuffer dpr={2} />
      </div>

      <aside className={styles.panel} data-light={bg === "Ivory"}>
        <p className={styles.badge}>Internal draft — not for client use</p>
        <p className={styles.title}>Draft studio</p>
        <p className={styles.note}>
          Hand-built approximation of the hoodie, made before a real 3D model was available. Shape is
          approximate and the embroidery is simulated. Do not present renders from here as the
          actual product.
        </p>

        <p className={styles.label}>Angle</p>
        <div className={styles.row}>
          {(Object.keys(presets) as PresetName[]).map((p) => (
            <button key={p} className={styles.btn} data-on={p === preset} onClick={() => apply(p)}>
              {labels[p]}
            </button>
          ))}
        </div>

        <p className={styles.label}>Backdrop</p>
        <div className={styles.row}>
          {(Object.keys(backgrounds) as (keyof typeof backgrounds)[]).map((b) => (
            <button key={b} className={styles.btn} data-on={b === bg} onClick={() => setBg(b)}>
              {b}
            </button>
          ))}
        </div>

        <div className={styles.row}>
          <button className={styles.btn} data-on={spin} onClick={toggleSpin}>
            {spin ? "Stop spin" : "Spin"}
          </button>
          <button className={styles.primary} onClick={download}>
            Download PNG
          </button>
        </div>
        <p className={styles.hint}>Drag the hoodie to rotate.</p>
      </aside>
    </div>
  );
}

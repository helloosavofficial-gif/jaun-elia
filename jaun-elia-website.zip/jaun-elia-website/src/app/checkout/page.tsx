import type { Metadata } from "next";
import { CheckoutView } from "@/components/checkout/CheckoutView";
import styles from "./checkout.module.css";

export const metadata: Metadata = {
  title: "Checkout",
  robots: { index: false, follow: false },
};

export default function CheckoutPage() {
  return (
    <main id="main" tabIndex={-1} className={styles.page}>
      <h1 className={styles.title}>Checkout</h1>
      <CheckoutView />
    </main>
  );
}

import type { Metadata } from "next";
import { Couplet, Eyebrow, ReadingColumn } from "@/components/diwan";
import { ProductCard } from "@/components/shop/ProductCard";
import { hoodieProduct, products } from "@/content/products";
import { site } from "@/content/site";
import styles from "./shop.module.css";

export const metadata: Metadata = {
  title: "Shop",
  description: `${site.label}: ${hoodieProduct.name}, ${hoodieProduct.colour.toLowerCase()}, ${hoodieProduct.priceLabel}.`,
  alternates: { canonical: "/shop" },
};

const [first, ...rest] = site.hero.title; // "Words," / "made wearable."

/**
 * The collection: a short After Dark introduction on ink, then every product
 * on paper. The first piece leads (front and back side by side); any further
 * pieces fall into a regular grid. Built from content/products.ts, so new
 * products appear without layout changes. The product page (/shop/[slug])
 * holds the gallery, 360° view and details.
 */
export default function ShopPage() {
  const count = products.length;
  const [lead, ...others] = products;

  return (
    <main id="main" tabIndex={-1} className={styles.page}>
      <header className={styles.intro}>
        <div className={styles.introText}>
          <Eyebrow marker>{site.label} · After Dark</Eyebrow>
          <Couplet as="h1" size="title" first={first} second={rest.join(" ")} className={styles.title} />
          <p className={styles.lede}>{hoodieProduct.description}</p>
        </div>
        <ReadingColumn variant="divider" length="88px" className={styles.mark} />
      </header>

      <section className={styles.collection} aria-labelledby="collection-title">
        <div className={styles.bar}>
          <h2 id="collection-title" className={styles.barTitle}>
            The collection
          </h2>
          <p className={styles.count}>
            {count} {count === 1 ? "piece" : "pieces"}
          </p>
        </div>

        {lead && <ProductCard product={lead} layout="lead" />}

        {others.length > 0 && (
          <ul className={styles.grid}>
            {others.map((p) => (
              <li key={p.id}>
                <ProductCard product={p} />
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { BuyPanel } from "@/components/shop/BuyPanel";
import { ProductDetails } from "@/components/product/ProductDetails";
import { ProductViewer } from "@/components/product/ProductViewer";
import { JsonLd } from "@/components/JsonLd";
import { products } from "@/content/products";
import { breadcrumbLd, productLd } from "@/lib/structuredData";
import { getStock } from "@/server/inventory";
import styles from "./product.module.css";

/** Rebuilt at most once a minute, so the offer's availability follows the live edition count. */
export const revalidate = 60;

function liveRemaining(productId: string): number | null {
  try {
    return getStock(productId).remaining;
  } catch {
    return null; // database unavailable at build time: leave availability unstated
  }
}

type Params = { slug: string };

const bySlug = (slug: string) => products.find((p) => p.slug === slug);

export function generateStaticParams(): Params[] {
  return products.map((p) => ({ slug: p.slug }));
}

export const dynamicParams = false;

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const product = bySlug((await params).slug);
  if (!product) return {};
  const description = `${product.description} ${product.priceLabel}, cash on delivery.`;
  const { front, back } = product.images;
  return {
    title: product.name,
    description,
    alternates: { canonical: `/shop/${product.slug}` },
    openGraph: {
      title: product.name,
      description,
      url: `/shop/${product.slug}`,
      images: [
        { url: front.src, width: front.width, height: front.height, alt: front.alt },
        { url: back.src, width: back.width, height: back.height, alt: back.alt },
      ],
    },
    twitter: { card: "summary_large_image", title: product.name, description, images: [front.src] },
    other: {
      "product:price:amount": String(product.price),
      "product:price:currency": product.currency,
    },
  };
}

/** The product page: the garment in every available view, buying, and the details. */
export default async function ProductPage({ params }: { params: Promise<Params> }) {
  const product = bySlug((await params).slug);
  if (!product) notFound();

  return (
    <main id="main" tabIndex={-1} className={styles.page}>
      <JsonLd
        data={[
          productLd(product, liveRemaining(product.id)),
          breadcrumbLd([
            { name: "Shop", path: "/shop" },
            { name: product.name, path: `/shop/${product.slug}` },
          ]),
        ]}
      />
      <nav aria-label="Breadcrumb" className={styles.crumbs}>
        <ol>
          <li>
            <Link href="/shop">Shop</Link>
          </li>
          <li aria-current="page">{product.name}</li>
        </ol>
      </nav>
      <div className={styles.layout}>
        <ProductViewer className={styles.viewer} />
        <div className={styles.side}>
          <BuyPanel className={styles.panel} />
          <ProductDetails product={product} />
        </div>
      </div>
    </main>
  );
}

import type { MetadataRoute } from "next";
import { products } from "@/content/products";
import { site } from "@/content/site";
import { PUBLIC_ROUTES, SITE_URL } from "@/lib/siteConfig";

const priority = (path: string) => (path === "/" ? 1 : path.startsWith("/shop") ? 0.9 : path === "/campaign" ? 0.8 : 0.4);
const legal = new Set(["/privacy", "/terms"]);

export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date();
  return PUBLIC_ROUTES.map((path) => {
    const product = products.find((p) => path === `/shop/${p.slug}`);
    const images = product
      ? [product.images.front.src, product.images.back.src]
      : path === "/" || path === "/campaign"
        ? [site.meta.shareImage]
        : undefined;
    return {
      url: `${SITE_URL}${path === "/" ? "" : path}`,
      lastModified,
      changeFrequency: legal.has(path) ? "yearly" : path.startsWith("/shop") ? "daily" : "weekly",
      priority: priority(path),
      ...(images ? { images: images.map((src) => `${SITE_URL}${src}`) } : {}),
    };
  });
}

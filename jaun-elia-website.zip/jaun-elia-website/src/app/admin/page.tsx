import { AdminApp } from "@/components/admin/AdminApp";
import { AdminLogin } from "@/components/admin/AdminLogin";
import { isAdmin } from "@/server/admin";
import { config } from "@/server/config";
import styles from "@/components/admin/admin.module.css";

export const dynamic = "force-dynamic";

/** The team's order desk: orders, messages, release list and the edition count. */
export default async function AdminPage() {
  if (!config.adminPassword) {
    return (
      <main id="main" className={styles.gate}>
        <div className={styles.gateCard}>
          <p className={styles.kicker}>Jaun Elia · Order desk</p>
          <h1 className={styles.gateTitle}>Switched off</h1>
          <p className={styles.muted}>
            Set <code>ADMIN_PASSWORD</code> in the server&rsquo;s environment (see <code>.env.example</code>) and restart to
            turn on the order desk.
          </p>
        </div>
      </main>
    );
  }
  return (await isAdmin()) ? <AdminApp /> : <AdminLogin />;
}

import type { Metadata } from "next";
import Link from "next/link";
import { InfoPage, InfoRows, InfoSection } from "@/components/info/InfoPage";
import { SizeTable } from "@/components/product/SizeTable";
import { hoodieProduct as p } from "@/content/products";

export const metadata: Metadata = {
  title: "Size guide",
  description: "Sizes and garment measurements for the Jaun Elia hoodie.",
  alternates: { canonical: "/size-guide" },
};

const ready = p.sizesConfirmed && p.measurements !== null;

export default function SizeGuidePage() {
  return (
    <InfoPage
      kicker="Help"
      title="Size guide"
      intro={<p>Measurements for the {p.name}.</p>}
      draftNote={ready ? undefined : "The size run and garment measurements have not been confirmed yet."}
    >
      <InfoSection title={p.name}>
        <SizeTable product={p} />
      </InfoSection>
      <InfoSection title="Fit">
        <InfoRows rows={[["Fit", p.details.fit]]} />
      </InfoSection>
      <InfoSection title="Shop">
        <p>
          <Link href={`/shop/${p.slug}`}>Back to the hoodie</Link>
        </p>
      </InfoSection>
    </InfoPage>
  );
}

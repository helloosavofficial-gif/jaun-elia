/**
 * Re-mounts on every navigation, so each page fades in as it arrives.
 * Opacity only: a transform here would break the campaign's sticky scenes and
 * fixed layers. Header, footer and the bag live in the layout and stay put.
 */
export default function Template({ children }: { children: React.ReactNode }) {
  return <div className="page-fade">{children}</div>;
}

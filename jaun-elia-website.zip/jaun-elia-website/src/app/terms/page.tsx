import type { Metadata } from "next";
import { InfoPage, InfoRows, InfoSection } from "@/components/info/InfoPage";
import { hoodieProduct } from "@/content/products";
import { store } from "@/content/store";

export const metadata: Metadata = {
  title: "Terms",
  description: "Terms for ordering from the Jaun Elia First Release.",
  alternates: { canonical: "/terms" },
};

/**
 * Terms of use — a draft. States only what is true of the site today; every
 * business or legal term (payment, delivery, returns, governing law,
 * ownership) is left pending for the client and their adviser to supply.
 */
export default function TermsPage() {
  return (
    <InfoPage
      kicker="Legal"
      title="Terms"
      draftNote="These terms are a draft awaiting the business's details and legal review. They are not complete and must be finished before launch."
    >
      <InfoSection title="Who we are">
        <InfoRows rows={[["Business", store.businessName]]} />
      </InfoSection>
      <InfoSection title="Ordering">
        <p>
          Adding an item to your bag does not reserve it. A piece is reserved for you when you place your order, and we
          contact you to confirm the order before it ships. Orders are paid in cash on delivery; nothing is charged
          online.
        </p>
        <p>The edition is limited. If it sells out before your order is placed, checkout will tell you and no order is made.</p>
      </InfoSection>
      <InfoSection title="Prices">
        <p>
          Prices are shown in Pakistani rupees ({hoodieProduct.currency}). Where shipping isn&rsquo;t shown at checkout,
          we confirm it with you before your order ships.
        </p>
      </InfoSection>
      <InfoSection title="Product images">
        <p>
          Product imagery on this site includes concept renders and design mockups, labelled where they appear. They
          are not photographs of the final garment, and the finished product may differ. Photographs labelled as
          placeholder photography show other hoodies and are not the product.
        </p>
      </InfoSection>
      <InfoSection title="Still to be added">
        <InfoRows
          rows={[
            ["Sizes and availability", null],
            ["Delivery", null],
            ["Returns and exchanges", null],
            ["Intellectual property", null],
            ["Governing law", null],
          ]}
        />
      </InfoSection>
    </InfoPage>
  );
}

import { ImageResponse } from "next/og";
import { flags } from "@/content/site";

export const size = { width: 64, height: 64 };
export const contentType = "image/png";

/**
 * Tab icon: the proposed ن (noon) mark when flags.showProposedMark is on,
 * otherwise a plain dark tile (the mark is not client-approved yet).
 */
export default function Icon() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "#080808", borderRadius: 12 }}>
        {flags.showProposedMark && (
          <svg width="52" height="52" viewBox="135.46 148.46 718.08 718.08">
            <path
              fill="#f2eee6"
              d="M725 255C770 380 775 520 715 610C655 700 520 760 400 725C320 702 262 640 238 545L214 462C258 565 312 612 385 632C500 665 590 632 638 565C672 515 676 420 725 255ZM460.81 319.64L529.42 376.65L479.19 450.36L410.58 393.35Z"
            />
          </svg>
        )}
      </div>
    ),
    size,
  );
}

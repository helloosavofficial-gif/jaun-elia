import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Inter } from "next/font/google";
import { site } from "@/content/site";
import { SmoothScroll } from "@/components/SmoothScroll";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { BagDrawer } from "@/components/bag/BagDrawer";
import { JsonLd } from "@/components/JsonLd";
import { PageSurface } from "@/components/PageSurface";
import { INDEXABLE, SITE_URL } from "@/lib/siteConfig";
import { organizationLd, websiteLd } from "@/lib/structuredData";import "./globals.css";

// Provisional type pairing — not a confirmed brand system.
const serif = Cormorant_Garamond({
  variable: "--font-serif",
  subsets: ["latin"],
  weight: ["300", "400", "500"],
  style: ["normal", "italic"],
});

const sans = Inter({
  variable: "--font-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  // launch switches live in src/lib/siteConfig.ts (environment variables)
  metadataBase: new URL(SITE_URL),
  title: { default: site.meta.title, template: `%s — ${site.label}` },
  description: site.meta.description,
  alternates: { canonical: "/" },
  // share images come from app/opengraph-image.tsx and app/twitter-image.tsx
  openGraph: {
    type: "website",
    siteName: site.label,
    title: site.meta.title,
    description: site.meta.description,
  },
  twitter: { card: "summary_large_image", title: site.meta.title, description: site.meta.description },
  // out of search engines until NEXT_PUBLIC_SITE_INDEXABLE=true
  robots: INDEXABLE ? { index: true, follow: true } : { index: false, follow: false },
};

export const viewport: Viewport = {
  themeColor: "#080808",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    // the inline script below adds class="js" before hydration
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* reveal animations only hide content once JS is confirmed; the intro is
            hidden before paint when it has already played this session */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              "document.documentElement.classList.add('js');if(/[?&]motion=off/.test(location.search))document.documentElement.classList.add('intro-seen')",
          }}
        />
      </head>
      <body className={`${serif.variable} ${sans.variable}`}>
        <a href="#main" className="skip-link">
          Skip to content
        </a>
        <JsonLd data={[organizationLd(), websiteLd()]} />
        <SmoothScroll />
        <PageSurface />
        <SiteHeader />
        {children}
        <SiteFooter />
        <BagDrawer />
      </body>
    </html>
  );
}

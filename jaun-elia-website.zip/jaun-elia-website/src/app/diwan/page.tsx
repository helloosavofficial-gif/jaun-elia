import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import { site } from "@/content/site";
import { Button, Couplet, Eyebrow, MarginNote, ReadingColumn, Reveal, Section, TextLink } from "@/components/diwan";
import styles from "./diwan.module.css";

export const metadata: Metadata = {
  title: "Diwan — design system (internal)",
  robots: { index: false, follow: false },
};

const swatches = [
  { name: "Paper", token: "--paper", note: "Main surface", ink: true },
  { name: "Paper deep", token: "--paper-deep", note: "Image wells", ink: true },
  { name: "Ink", token: "--ink-deep", note: "Text · cinematic sections" },
  { name: "Ink raised", token: "--ink-raised", note: "Panels on ink" },
  { name: "Lamp", token: "--lamp", note: "Live states only", ink: true },
];

const steps = ["--step-5", "--step-4", "--step-3", "--step-2", "--step-1", "--step-0", "--step--1", "--step--2"];

/**
 * Internal preview of the Diwan design system: every token and component on
 * paper and on ink. Development only — a 404 in production builds.
 */
export default function DiwanPreview() {
  if (process.env.NODE_ENV === "production") notFound();

  return (
    <main id="main" tabIndex={-1} className={styles.page}>
      <ReadingColumn variant="progress" rail length="160px" label="Page progress" />

      <Section tone="paper" layout="manuscript" pad="lg">
        <Eyebrow marker>Diwan · design system</Eyebrow>
        <Couplet as="h1" size="display" first="Paper" second="and ink." />
        <p className={styles.lead}>
          The site as a poet&rsquo;s collected works: paper and ink, the Reading Column from the back of the hoodie,
          notes in the margins, headlines in two lines like a sher.
        </p>
        <MarginNote label="Margin note" side="end">
          Commentary sits beside the text, never on it — as in Urdu and Persian manuscripts.
        </MarginNote>
      </Section>

      <Section tone="paper" pad="md" aria-label="Colour">
        <Eyebrow>Colour</Eyebrow>
        <ul className={styles.swatches}>
          {swatches.map((s) => (
            <li key={s.token}>
              <span className={styles.chip} style={{ background: `var(${s.token})` }} data-light={s.ink ? "" : undefined} />
              <strong>{s.name}</strong>
              <code>{s.token}</code>
              <span>{s.note}</span>
            </li>
          ))}
        </ul>
      </Section>

      <Section tone="paper" pad="md" aria-label="Type">
        <Eyebrow>Type — Cormorant Garamond for the voice, Inter for the work</Eyebrow>
        <ul className={styles.scale}>
          {steps.map((t, i) => (
            <li key={t}>
              <code>{t}</code>
              <span style={{ fontSize: `var(${t})`, fontFamily: i < 5 ? "var(--font-display)" : "var(--font-body)", fontWeight: i < 5 ? 300 : 400 }}>
                {i < 5 ? "Words that stay" : "Embroidered front and back · PKR 9,000"}
              </span>
            </li>
          ))}
        </ul>
      </Section>

      <Section tone="ink" layout="manuscript" pad="lg">
        <Eyebrow marker>Couplet on ink</Eyebrow>
        <Couplet size="title" first="Wear the words" second="that remain." />
        <MarginNote label="The artwork" side="start">
          The calligraphy is reproduced exactly as supplied — never redrawn, retyped or translated.
        </MarginNote>
        <div className={styles.row}>
          <Button href="/shop/jaun-elia-hoodie" arrow>
            Primary
          </Button>
          <Button href="/shop" variant="secondary">
            Secondary
          </Button>
          <Button variant="quiet">Quiet</Button>
          <TextLink href="/campaign" arrow>
            Text link
          </TextLink>
        </div>
      </Section>

      <Section tone="paper" layout="manuscript" pad="lg">
        <Eyebrow>Buttons on paper</Eyebrow>
        <div className={styles.row}>
          <Button size="lg">Add to bag</Button>
          <Button variant="secondary" size="lg">
            Size guide
          </Button>
          <Button disabled>Disabled</Button>
        </div>
        <Button block size="lg" arrow>
          Full width
        </Button>
      </Section>

      <Section tone="paper" pad="lg" aria-label="Reading Column">
        <Eyebrow>The Reading Column</Eyebrow>
        <div className={styles.columns}>
          <figure>
            <ReadingColumn variant="divider" length="96px" />
            <figcaption>Divider</figcaption>
          </figure>
          <figure>
            <ReadingColumn variant="marker" />
            <figcaption>Marker</figcaption>
          </figure>
          <figure>
            <ReadingColumn variant="loader" length="64px" />
            <figcaption>Loader</figcaption>
          </figure>
          <figure>
            <ReadingColumn variant="divider" orientation="horizontal" length="120px" />
            <figcaption>Horizontal</figcaption>
          </figure>
          <figure className={styles.source}>
            <Image src="/media/edit/back-name-hd.webp" width={1440} height={1080} alt="The back artwork, where the Reading Column comes from" />
            <figcaption>Source: the back of the hoodie</figcaption>
          </figure>
        </div>
      </Section>

      <Section tone="ink" layout="wide" pad="lg" aria-label="Reveal">
        <Eyebrow>Ink and page — entrances</Eyebrow>
        <div className={styles.reveals}>
          <Reveal variant="ink">
            <Image src={site.media.back.src} width={577} height={1024} alt="Ink reveal demo: the back artwork" className={styles.revealImg} />
            <p className={styles.caption}>ink — drawn down like a pen stroke</p>
          </Reveal>
          <Reveal variant="rise" delay={120}>
            <Image src="/media/edit/detail-cuff.webp" width={432} height={540} alt="Rise reveal demo: cuff close-up" className={styles.revealImg} />
            <p className={styles.caption}>rise — settles into place</p>
          </Reveal>
          <Reveal variant="fade" delay={240}>
            <Image src="/media/edit/angle-profile.webp" width={640} height={800} alt="Fade reveal demo: profile view" className={styles.revealImg} />
            <p className={styles.caption}>fade</p>
          </Reveal>
        </div>
      </Section>
    </main>
  );
}

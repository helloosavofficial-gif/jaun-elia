import type { Metadata } from "next";
import Link from "next/link";
import { ContactForm } from "@/components/contact/ContactForm";
import { InfoPage, InfoRows, InfoSection } from "@/components/info/InfoPage";
import { store } from "@/content/store";

export const metadata: Metadata = {
  title: "Contact",
  description: "Questions about the Jaun Elia hoodie, sizing or an order — send us a message.",
  alternates: { canonical: "/contact" },
};

const c = store.contact;
const hasDirect = Boolean(c.email || c.phone || c.whatsapp);

/**
 * Contact and customer support. The form posts to /api/contact (stored for
 * /admin, and emailed to the team inbox when one is set). Direct details show
 * only once set in content/store.ts.
 */
export default function ContactPage() {
  return (
    <InfoPage kicker="Help" title="Contact" intro={<p>Questions about the hoodie, sizing or an order.</p>}>
      <InfoSection title="Write to us" id="message">
        <ContactForm />
      </InfoSection>
      {hasDirect && (
        <InfoSection title="Reach us">
          <InfoRows
            rows={[
              ["Email", c.email],
              ["Phone", c.phone],
              ["WhatsApp", c.whatsapp],
              ["Hours", c.hours],
            ]}
          />
        </InfoSection>
      )}
      <InfoSection title="Orders">
        <p>
          Include your order number (it starts with JE-) and we&rsquo;ll find it straight away. Your confirmation email
          has a private link that always shows your order&rsquo;s latest status.
        </p>
      </InfoSection>
      <InfoSection title="Before you ask">
        <ul>
          <li>
            <Link href="/size-guide">Size guide</Link>
          </li>
          <li>
            <Link href="/shipping-returns">Shipping &amp; returns</Link>
          </li>
        </ul>
      </InfoSection>
    </InfoPage>
  );
}

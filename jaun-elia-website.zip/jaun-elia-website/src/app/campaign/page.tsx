import Image from "next/image";
import Link from "next/link";
import { site } from "@/content/site";
import { lifestyle } from "@/content/lifestyle";
import { StockCounter } from "@/components/StockCounter";
import { VideoScrub } from "@/components/scenes/VideoScrub";
import { Choreography } from "@/components/scenes/Choreography";
import { Intro } from "@/components/scenes/Intro";
import { FilmOnce } from "@/components/scenes/FilmOnce";
import { hoodieProduct } from "@/content/products";
import s from "./page.module.css";
import h from "./home.module.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Campaign",
  description:
    "Words made wearable: the First Release in motion. An off-white hoodie carrying Jaun Elia's name in Urdu calligraphy, an edition of 2,500.",
  alternates: { canonical: "/campaign" },
};

/** A masked line that rises into place (animated by Choreography). */
function Rise({ text, className }: { text: string; className?: string }) {
  return (
    <span className={`${h.rise} ${className ?? ""}`} aria-hidden>
      <span data-rise>{text}</span>
    </span>
  );
}

const productHref = `/shop/${hoodieProduct.slug}`;
const price = `${hoodieProduct.currency} ${new Intl.NumberFormat("en-PK").format(hoodieProduct.price)}`;
const L = lifestyle.photos;

export default function CampaignPage() {
  const { hero, motion, back } = site;
  const m = site.media;
  const g = site.garment;

  // the one piece, seen four ways — every card opens the product page
  const views = [
    { src: g.front.src, w: g.front.width, ht: g.front.height, alt: "The Jaun Elia hoodie from the front (design mockup)", label: "Front", hover: g.back.src, main: true },
    { src: "/media/edit/angle-back-three-quarter.webp", w: 640, ht: 800, alt: "The hoodie from behind, three-quarter view (concept render)", label: "Back, three-quarter" },
    { src: "/media/edit/back-name-portrait.webp", w: 1200, ht: 1500, alt: "The back artwork: the name in Urdu calligraphy, JAUN ELIA, and four lines of verse", label: "The name, embroidered" },
    { src: "/media/edit/detail-eyelet.webp", w: 432, ht: 540, alt: "Eyelet and drawcord close-up (detail footage)", label: "Eyelets & drawcords" },
  ];

  // close-ups for the details strip — each image used once on the page
  const closeUps = [
    // 2× upscales of the supplied stills; the verse is cut from the full-resolution back artwork (public/art/back-art.png)
    { src: "/media/edit/detail-cuff-2x.webp", w: 864, ht: 1080, alt: "Ribbed cuff close-up (detail footage)", title: "Ribbed cuffs" },
    { src: "/media/edit/front-pocket-2x.webp", w: 1180, ht: 940, alt: "The front pocket and ribbed hem (design mockup)", title: "Pocket & hem" },
    { src: "/media/edit/back-verse-2x.webp", w: 1000, ht: 1250, alt: "Four lines of Urdu verse from the back, between columns of dots (the back artwork)", title: "The verse" },
    { src: "/media/edit/detail-cord-2x.webp", w: 864, ht: 1080, alt: "Drawcord close-up (detail footage)", title: "Tipped drawcords" },
  ];

  return (
    <>
      <Intro />
      <Choreography />

      {/* "#top" links still work: browsers and Lenis treat #top as the page top */}
      <main id="main" tabIndex={-1}>
        {/* ── HERO: the hoodie, turning in the studio ─────────────────── */}
        <section className={h.hero} data-scene="hero" aria-labelledby="hero-title">
          <div className={h.heroStage} data-hero-media>
            {/* turns once when the curtain opens, then rests on the front */}
            <FilmOnce
              className={h.heroVideo}
              src={m.rotation.src}
              poster={m.rotation.poster}
              label="The Jaun Elia hoodie turning in a dark studio (concept render)"
              afterIntro
            />
          </div>
          <div className={h.heroText}>
            <p className={h.script} data-hfade>
              {hero.kicker}
            </p>
            <h1 id="hero-title" className={h.display} aria-label={hero.headline}>
              <Rise text={hero.headline} />
            </h1>
            <Link href={productHref} className={h.textLink} data-hfade>
              {hero.cta}
            </Link>
          </div>
          <p className={h.cornerNote}>{hero.renderNote}</p>
        </section>

        {/* ── THE PIECE: product row ──────────────────────────────────── */}
        <section className={h.row} data-scene="row" aria-labelledby="row-title">
          <div className={h.rowHead}>
            <h2 id="row-title" className={h.rowTitle}>
              {site.label}
            </h2>
            <Link href="/shop" className={h.textLinkDark}>
              Shop
            </Link>
          </div>
          <ul className={h.cards}>
            {views.map((v, i) => (
              <li key={v.label} className={h.card} data-card style={{ ["--i" as string]: i }}>
                <Link href={productHref} className={h.cardLink}>
                  <div className={h.cardImage}>
                    <Image src={v.src} width={v.w} height={v.ht} alt={v.alt} sizes="(max-width: 899px) 70vw, 25vw" className={h.cardImg} />
                    {v.hover && (
                      <Image src={v.hover} width={g.back.width} height={g.back.height} alt="" aria-hidden sizes="(max-width: 899px) 70vw, 25vw" className={h.cardHover} />
                    )}
                    {v.main && <span className={h.badge}>New</span>}
                  </div>
                  <div className={h.cardMeta}>
                    <p className={h.cardName}>{hoodieProduct.name}</p>
                    <p className={h.cardSub}>{v.main ? price : v.label}</p>
                  </div>
                </Link>
                {v.main && (
                  <Link href={productHref} className={h.quickAdd} aria-label={`Choose a size for the ${hoodieProduct.name}`}>
                    +
                  </Link>
                )}
              </li>
            ))}
          </ul>
          <p className={h.rowNote}>Design mockups, concept renders and detail footage of the real design.</p>
        </section>

        {/* ── CAMPAIGN BANNER ─────────────────────────────────────────── */}
        <section className={h.banner} data-scene="banner" aria-labelledby="banner-title">
          <div className={h.bannerImage} data-banner-image>
            <Image src={L.nightHood.src} width={L.nightHood.width} height={L.nightHood.height} alt={L.nightHood.alt} sizes="100vw" />
          </div>
          <div className={h.bannerText}>
            <p className={h.script}>{site.banner.script}</p>
            <h2 id="banner-title" className={h.display}>
              <Rise text={site.banner.title} />
            </h2>
            <a href="#worn" className={h.textLink}>
              {site.banner.cta}
            </a>
          </div>
          {lifestyle.placeholder && <p className={h.cornerNote}>{lifestyle.note}</p>}
        </section>

        {/* ── THE CALLIGRAPHY ─────────────────────────────────────────── */}
        <section id="calligraphy" className={h.callig} data-scene="callig" aria-labelledby="callig-title">
          <figure className={h.calligMedia}>
            <div className={h.calligImage} data-callig-image>
              <Image
                src={m.back.src}
                width={m.back.width}
                height={m.back.height}
                alt="Back of the hoodie: large Urdu calligraphy of the name, JAUN ELIA, four lines of Urdu verse and a column of dots"
                sizes="(max-width: 899px) 86vw, 36vw"
              />
            </div>
            <figcaption className={h.caption}>Design mockup · the real artwork</figcaption>
          </figure>
          <div className={h.calligCopy}>
            <p className={h.eyebrow}>{site.callig.eyebrow}</p>
            <h2 id="callig-title" className={h.displayDark} aria-label={site.callig.title.join(" ")}>
              {site.callig.title.map((line) => (
                <Rise key={line} text={line} />
              ))}
            </h2>
            <p className={h.lead} data-sfade>
              {site.callig.lead}
            </p>
            <dl className={h.facts} data-sfade>
              {site.callig.facts.map(([k, v]) => (
                <div key={k}>
                  <dt>{k}</dt>
                  <dd>{v}</dd>
                </div>
              ))}
            </dl>
            <p className={h.note} data-sfade>
              {back.verseNote}
            </p>
          </div>
        </section>

        {/* ── 03 IN MOTION ────────────────────────────────────────────── */}
        <section id="motion" className={s.motion} data-scene="motion" aria-labelledby="motion-title">
          <div className={s.sticky}>
            <div className={s.studio} aria-hidden />
            <p className={s.viewGhost} data-view-ghost aria-hidden>
              Front
            </p>
            <div className={s.stage} data-stage>
              <VideoScrub
                src={m.rotation.src}
                poster={m.rotation.poster}
                trigger="[data-scene='motion']"
                from={0.06}
                to={0.94}
                alt="The hoodie turning through front, profile and back as you scroll"
                className={s.stageSeq}
              />
            </div>
            <div className={s.motionCopy} data-motion-copy>
              <p className={s.index}>{motion.index}</p>
              <h2 id="motion-title" className={s.motionTitle}>
                <span>{motion.headline[0]}</span>
                <span>{motion.headline[1]}</span>
              </h2>
            </div>
            <div className={s.readout} aria-hidden>
              <p className={s.degrees} data-degrees>
                000°
              </p>
              <ol className={s.viewList}>
                {["Front", "Profile", "Back"].map((v) => (
                  <li key={v} data-view={v}>
                    {v}
                  </li>
                ))}
              </ol>
            </div>
            <div className={s.rail} aria-hidden>
              <span data-rail />
            </div>
            <p className={s.motionHint}>
              <span>{motion.hint}</span>
              <span className={s.motionNote}>{motion.note}</span>
            </p>
          </div>
        </section>

        {/* ── IN THE DETAILS ──────────────────────────────────────────── */}
        <section className={h.details} data-scene="closeups" aria-labelledby="details-title">
          <div className={h.detailsHead}>
            <h2 id="details-title" className={h.displayDark} aria-label="In the details">
              <Rise text="In the details" />
            </h2>
          </div>
          <ul className={h.detailGrid}>
            {closeUps.map((c) => (
              <li key={c.src} className={h.detailItem}>
                <div className={h.detailImage} data-clip>
                  <Image src={c.src} width={c.w} height={c.ht} alt={c.alt} sizes="(max-width: 899px) 70vw, 25vw" />
                </div>
                <p className={h.detailTitle}>{c.title}</p>
              </li>
            ))}
          </ul>
        </section>

        {/* ── WORN ────────────────────────────────────────────────────── */}
        <section id="worn" className={h.look} data-scene="look" aria-labelledby="look-title">
          <div className={h.lookHead}>
            <h2 id="look-title" className={h.display} aria-label={site.look.title.join(" ")}>
              {site.look.title.map((line) => (
                <Rise key={line} text={line} />
              ))}
            </h2>
            {lifestyle.placeholder && <p className={h.placeholderInline}>{lifestyle.note}</p>}
          </div>
          <div className={h.lookGrid}>
            {[
              { p: L.hero, cls: h.lookA, par: "0.1" },
              { p: L.daySteps, cls: h.lookB, par: "0.16" },
              { p: L.nightGreen, cls: h.lookC, par: "0.08" },
              { p: L.dayLean, cls: h.lookD, par: "0.12" },
            ].map(({ p, cls, par }) => (
              <figure key={p.src} className={`${h.lookItem} ${cls}`}>
                <div className={h.lookFrame} data-clip>
                  <div className={h.lookPar} data-par={par}>
                    <Image src={p.src} width={p.width} height={p.height} alt={p.alt} sizes="(max-width: 899px) 90vw, 40vw" />
                  </div>
                </div>
              </figure>
            ))}
          </div>
        </section>

        {/* ── THE EDITION ─────────────────────────────────────────────── */}
        <section id="edition" className={h.edition} data-scene="edition" aria-labelledby="edition-title">
          <div className={h.editionHead}>
            <p className={h.eyebrowLight}>{site.editionCopy.index}</p>
            <h2 id="edition-title" className={h.editionTitle}>
              {site.editionCopy.title}
            </h2>
            <p className={h.editionSub}>{site.editionCopy.sub}</p>
          </div>
          <StockCounter variant="large" className={h.editionCounter} />
        </section>

        {/* ── CLOSING BANNER ──────────────────────────────────────────── */}
        <section className={`${h.banner} ${h.bannerWide}`} data-scene="final" aria-labelledby="final-title">
          <div className={h.bannerImage} data-banner-image>
            <Image src={L.dayWall.src} width={L.dayWall.width} height={L.dayWall.height} alt={L.dayWall.alt} sizes="100vw" />
          </div>
          <div className={h.bannerText}>
            <p className={h.script}>{site.closing.script}</p>
            <h2 id="final-title" className={h.display}>
              <Rise text={site.closing.title} />
            </h2>
            <Link href={productHref} className={h.textLink}>
              {site.closing.cta}
            </Link>
          </div>
          {lifestyle.placeholder && <p className={h.cornerNote}>{lifestyle.note}</p>}
        </section>
      </main>
    </>
  );
}

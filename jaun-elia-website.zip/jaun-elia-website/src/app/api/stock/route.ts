import { json } from "@/server/http";
import { getStock } from "@/server/inventory";

export const dynamic = "force-dynamic";

/** GET /api/stock → { total, remaining, live } — the edition counter on every page. */
export function GET() {
  const s = getStock();
  return json(
    { total: s.total, remaining: s.remaining, live: true },
    200,
    // a few seconds of shared caching absorbs traffic spikes; the counter can lag that much
    { "Cache-Control": "public, max-age=0, s-maxage=5, stale-while-revalidate=30" },
  );
}

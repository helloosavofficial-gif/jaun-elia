import { requireAdmin } from "@/server/admin";
import { error, json, readJson } from "@/server/http";
import { getStock, setStock } from "@/server/inventory";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const denied = await requireAdmin(req);
  return denied ?? json(getStock());
}

/** PUT /api/admin/stock — { total, remaining }: correct the edition count after a stock take. */
export async function PUT(req: Request) {
  const denied = await requireAdmin(req);
  if (denied) return denied;
  const body = await readJson(req, 1_000);
  const total = body?.total;
  const remaining = body?.remaining;
  const whole = (n: unknown): n is number => typeof n === "number" && Number.isInteger(n) && n >= 0 && n <= 1_000_000;
  if (!whole(total) || !whole(remaining)) return error(400, "Use whole numbers of pieces.");
  if (remaining > total) return error(400, "Remaining can't be more than the edition total.", { remaining: "Above total." });
  return json(setStock(getStock().productId, total, remaining));
}

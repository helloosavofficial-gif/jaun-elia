import { requireAdmin } from "@/server/admin";
import { json } from "@/server/http";
import { listSubscribers } from "@/server/inbox";

export const dynamic = "force-dynamic";

/** GET /api/admin/subscribers — JSON, or ?format=csv to download the list. */
export async function GET(req: Request) {
  const denied = await requireAdmin(req);
  if (denied) return denied;
  const subscribers = listSubscribers();
  if (new URL(req.url).searchParams.get("format") !== "csv") return json({ subscribers });

  const cell = (s: string) => (/[",\n]/.test(s) || /^[=+\-@]/.test(s) ? `"${s.replace(/^([=+\-@])/, "'$1").replace(/"/g, '""')}"` : s);
  const csv = ["email,source,joined", ...subscribers.map((s) => [s.email, s.source, s.createdAt].map(cell).join(","))].join("\n");
  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="release-list-${new Date().toISOString().slice(0, 10)}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}

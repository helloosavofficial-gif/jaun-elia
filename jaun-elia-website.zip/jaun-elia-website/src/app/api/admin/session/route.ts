import { NextResponse } from "next/server";
import { ADMIN_COOKIE, checkPassword, cookieOptions, newSession } from "@/server/admin";
import { config } from "@/server/config";
import { error, limited, readJson, sameOrigin } from "@/server/http";

export const dynamic = "force-dynamic";

/** POST /api/admin/session — { password }: sign in. */
export async function POST(req: Request) {
  if (!config.adminPassword) return error(503, "Admin is switched off. Set ADMIN_PASSWORD to turn it on.");
  if (!sameOrigin(req)) return error(403, "Cross-site request refused.");
  const tooMany = limited(req, "admin-login", 8, 15 * 60_000);
  if (tooMany) return tooMany;

  const body = await readJson(req, 1_000);
  const password = typeof body?.password === "string" ? body.password : "";
  if (!checkPassword(password)) return error(401, "That password isn't right.");

  const s = newSession();
  const res = NextResponse.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
  res.cookies.set(ADMIN_COOKIE, s.value, cookieOptions(s.maxAge));
  return res;
}

/** DELETE /api/admin/session — sign out. */
export async function DELETE(req: Request) {
  if (!sameOrigin(req)) return error(403, "Cross-site request refused.");
  const res = NextResponse.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
  res.cookies.set(ADMIN_COOKIE, "", cookieOptions(0));
  return res;
}

import { requireAdmin } from "@/server/admin";
import { error, json, readJson } from "@/server/http";
import { listMessages, setHandled } from "@/server/inbox";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const denied = await requireAdmin(req);
  return denied ?? json({ messages: listMessages() });
}

/** PATCH /api/admin/messages — { id, handled } */
export async function PATCH(req: Request) {
  const denied = await requireAdmin(req);
  if (denied) return denied;
  const body = await readJson(req, 1_000);
  if (typeof body?.id !== "number" || typeof body.handled !== "boolean") return error(400, "Expected { id, handled }.");
  return setHandled(body.id, body.handled) ? json({ ok: true }) : error(404, "Message not found.");
}

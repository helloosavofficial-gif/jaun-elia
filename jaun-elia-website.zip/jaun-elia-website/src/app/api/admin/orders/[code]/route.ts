import { requireAdmin } from "@/server/admin";
import { error, json, readJson } from "@/server/http";
import { getOrderForAdmin, OrderError, parsePatch, updateOrder } from "@/server/orders";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ code: string }> };

export async function GET(req: Request, { params }: Ctx) {
  const denied = await requireAdmin(req);
  if (denied) return denied;
  const order = getOrderForAdmin((await params).code);
  return order ? json(order) : error(404, "Order not found.");
}

/**
 * PATCH /api/admin/orders/:code — { status?, paymentStatus?, shipping?, adminNote? }
 * Status moves: received → confirmed → shipped → delivered; cancel before shipping
 * (cancelling returns the pieces to stock). The customer is emailed on each move.
 */
export async function PATCH(req: Request, { params }: Ctx) {
  const denied = await requireAdmin(req);
  if (denied) return denied;
  const body = await readJson(req);
  if (!body) return error(400, "We couldn't read that request.");
  const parsed = parsePatch(body);
  if (!parsed.ok) return error(400, "Please check the highlighted fields.", parsed.fields);
  try {
    return json(updateOrder((await params).code, parsed.value));
  } catch (err) {
    if (err instanceof OrderError) return error(err.status, err.message, err.fields);
    throw err;
  }
}

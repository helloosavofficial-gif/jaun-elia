import { requireAdmin } from "@/server/admin";
import { json } from "@/server/http";
import { listOrders, orderSummary } from "@/server/orders";

export const dynamic = "force-dynamic";

/** GET /api/admin/orders?status=&q=&offset= — newest first, 50 per page, plus totals. */
export async function GET(req: Request) {
  const denied = await requireAdmin(req);
  if (denied) return denied;
  const sp = new URL(req.url).searchParams;
  const offset = Math.max(0, Number(sp.get("offset")) || 0);
  const { orders, count } = listOrders({
    status: sp.get("status") ?? undefined,
    q: sp.get("q")?.trim().slice(0, 80) || undefined,
    offset,
  });
  return json({ orders, count, offset, summary: orderSummary() });
}

import { error, json, limited, readJson, sameOrigin } from "@/server/http";
import { parseMessage, saveMessage } from "@/server/inbox";
import { isBot } from "@/server/validate";

export const dynamic = "force-dynamic";

/** POST /api/contact — { name, email, phone?, orderCode?, subject, body } */
export async function POST(req: Request) {
  if (!sameOrigin(req)) return error(403, "Cross-site request refused.");
  const tooMany = limited(req, "contact", 5, 10 * 60_000);
  if (tooMany) return tooMany;

  const body = await readJson(req);
  if (!body) return error(400, "We couldn't read that request.");
  if (isBot(body)) return json({ ok: true }, 201); // quietly drop

  const parsed = parseMessage(body);
  if (!parsed.ok) return error(400, "Please check the highlighted fields.", parsed.fields);
  saveMessage(parsed.value);
  return json({ ok: true }, 201);
}

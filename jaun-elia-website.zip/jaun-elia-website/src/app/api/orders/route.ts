import { SITE_URL } from "@/lib/siteConfig";
import { config } from "@/server/config";
import { error, json, limited, readJson, sameOrigin } from "@/server/http";
import {
  createOrder,
  getOrderForCustomer,
  OrderError,
  orderLink,
  parseOrder,
  sendOrderEmails,
} from "@/server/orders";

export const dynamic = "force-dynamic";

/**
 * POST /api/orders — place an order.
 * Body: { lines: [{ productId, size, qty }], customer: { name, email, phone, address, city, postcode?, notes? },
 *         paymentMethod: "cod", idempotencyKey? }
 * 201 → { code, token, url }   400 → { error, fields }   409 → not enough stock   503 → checkout off
 *
 * Prices, totals and stock are worked out here from the catalogue and the
 * database; the browser only says what and how many.
 */
export async function POST(req: Request) {
  if (!sameOrigin(req)) return error(403, "Cross-site request refused.");
  if (!config.checkoutEnabled) return error(503, "Ordering is closed right now. Your bag is still saved.");
  const tooMany = limited(req, "orders", 6, 10 * 60_000);
  if (tooMany) return tooMany;

  const body = await readJson(req);
  if (!body) return error(400, "We couldn't read that request.");

  const parsed = parseOrder(body);
  if (!parsed.ok) return error(400, "Please check the highlighted fields.", parsed.fields);

  try {
    const { code, token, replay } = createOrder(parsed.value);
    const origin = process.env.NEXT_PUBLIC_SITE_URL ? SITE_URL : new URL(req.url).origin;
    const url = orderLink(origin, code, token);
    if (!replay) {
      const order = getOrderForCustomer(code, token);
      if (order) sendOrderEmails(order, url);
    }
    return json({ code, token, url: `/order/${code}?t=${encodeURIComponent(token)}` }, replay ? 200 : 201);
  } catch (err) {
    if (err instanceof OrderError) return error(err.status, err.message, err.fields);
    console.error("[orders] create failed", err);
    return error(500, "Something went wrong on our side and the order was not placed. Please try again.");
  }
}

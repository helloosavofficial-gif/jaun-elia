import { error, json, limited } from "@/server/http";
import { getOrderForCustomer } from "@/server/orders";

export const dynamic = "force-dynamic";

/** GET /api/orders/:code?t=token — the customer's own order. 404 for a wrong code or token alike. */
export async function GET(req: Request, { params }: { params: Promise<{ code: string }> }) {
  const tooMany = limited(req, "order-view", 60, 60_000);
  if (tooMany) return tooMany;
  const { code } = await params;
  const token = new URL(req.url).searchParams.get("t") ?? "";
  const order = getOrderForCustomer(code, token);
  if (!order) return error(404, "We couldn't find that order. Check the link from your confirmation email.");
  return json(order);
}

import { error, json, limited, readJson, sameOrigin } from "@/server/http";
import { parseSubscribe, subscribe, unsubscribe } from "@/server/inbox";
import { isBot } from "@/server/validate";

export const dynamic = "force-dynamic";

/** POST /api/subscribe — { email, source? }: join the release list. */
export async function POST(req: Request) {
  if (!sameOrigin(req)) return error(403, "Cross-site request refused.");
  const tooMany = limited(req, "subscribe", 10, 10 * 60_000);
  if (tooMany) return tooMany;

  const body = await readJson(req, 2_000);
  if (!body) return error(400, "We couldn't read that request.");
  if (isBot(body)) return json({ ok: true }, 201);

  const parsed = parseSubscribe(body);
  if (!parsed.ok) return error(400, parsed.fields.email ?? "Enter a valid email address.", parsed.fields);
  subscribe(parsed.value.email, parsed.value.source);
  return json({ ok: true }, 201);
}

/** DELETE /api/subscribe — { email }: leave the list. */
export async function DELETE(req: Request) {
  if (!sameOrigin(req)) return error(403, "Cross-site request refused.");
  const tooMany = limited(req, "subscribe", 10, 10 * 60_000);
  if (tooMany) return tooMany;
  const body = await readJson(req, 2_000);
  const parsed = body ? parseSubscribe(body) : null;
  if (!parsed?.ok) return error(400, "Enter a valid email address.");
  unsubscribe(parsed.value.email);
  return json({ ok: true });
}

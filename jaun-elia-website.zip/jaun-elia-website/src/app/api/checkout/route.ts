import { MAX_QTY_PER_LINE } from "@/content/products";
import type { CheckoutInfo } from "@/lib/orderTypes";
import { config } from "@/server/config";
import { json } from "@/server/http";
import { getStock } from "@/server/inventory";

export const dynamic = "force-dynamic";

/** GET /api/checkout — what the checkout page needs to know before it shows the form. */
export function GET() {
  const s = getStock();
  const info: CheckoutInfo = {
    enabled: config.checkoutEnabled && s.remaining > 0,
    methods: ["cod"],
    shippingFee: config.shippingFlatFee,
    stock: { total: s.total, remaining: s.remaining },
    maxQtyPerLine: MAX_QTY_PER_LINE,
  };
  return json(info);
}

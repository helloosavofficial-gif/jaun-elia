import type { MetadataRoute } from "next";
import { INDEXABLE, SITE_URL } from "@/lib/siteConfig";

/** Disallows everything until NEXT_PUBLIC_SITE_INDEXABLE=true at launch. */
export default function robots(): MetadataRoute.Robots {
  if (!INDEXABLE) return { rules: { userAgent: "*", disallow: "/" } };
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      // private or per-visitor pages: nothing for search engines there
      disallow: ["/studio", "/diwan", "/bag", "/checkout", "/order/", "/admin", "/api/"],
    },
    sitemap: `${SITE_URL}/sitemap.xml`,
    host: SITE_URL,
  };
}

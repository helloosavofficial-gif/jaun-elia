import { NextResponse } from "next/server";
import { config } from "./config";

/** JSON response that is never cached. */
export function json(data: unknown, status = 200, headers?: Record<string, string>) {
  return NextResponse.json(data, {
    status,
    headers: { "Cache-Control": "no-store", ...headers },
  });
}

export const error = (status: number, message: string, fields?: Record<string, string>) =>
  json({ error: message, ...(fields ? { fields } : {}) }, status);

/** Parses a JSON body of at most `limit` bytes; null when missing, too large or malformed. */
export async function readJson(req: Request, limit = 16_000): Promise<Record<string, unknown> | null> {
  if (!(req.headers.get("content-type") ?? "").includes("application/json")) return null;
  const text = await req.text();
  if (text.length > limit) return null;
  try {
    const v = JSON.parse(text);
    return v && typeof v === "object" && !Array.isArray(v) ? v : null;
  } catch {
    return null;
  }
}

export function clientIp(req: Request): string {
  if (config.trustProxy) {
    const fwd = req.headers.get("x-forwarded-for");
    if (fwd) return fwd.split(",")[0].trim();
    const real = req.headers.get("x-real-ip");
    if (real) return real;
  }
  return "local";
}

/**
 * Fixed-window rate limit kept in memory (per server process). Enough for a
 * single-server shop; use a shared store (e.g. Redis) when running several.
 */
const g = globalThis as unknown as { __jaunRate?: Map<string, { n: number; reset: number }> };
const buckets = (g.__jaunRate ??= new Map());

export function rateLimit(key: string, max: number, windowMs: number): { ok: boolean; retryAfter: number } {
  const t = Date.now();
  const b = buckets.get(key);
  if (!b || b.reset <= t) {
    buckets.set(key, { n: 1, reset: t + windowMs });
    if (buckets.size > 10_000) for (const [k, v] of buckets) if (v.reset <= t) buckets.delete(k);
    return { ok: true, retryAfter: 0 };
  }
  b.n += 1;
  return { ok: b.n <= max, retryAfter: Math.ceil((b.reset - t) / 1000) };
}

export function limited(req: Request, name: string, max: number, windowMs: number) {
  const r = rateLimit(`${name}:${clientIp(req)}`, max, windowMs);
  return r.ok ? null : error(429, "Too many requests. Please wait a little and try again.", undefined);
}

/** Rejects cross-site form posts to state-changing routes (in addition to SameSite cookies). */
export function sameOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return true; // same-origin fetches from older browsers, curl, server-to-server
  try {
    return new URL(origin).host === (req.headers.get("x-forwarded-host") ?? req.headers.get("host"));
  } catch {
    return false;
  }
}

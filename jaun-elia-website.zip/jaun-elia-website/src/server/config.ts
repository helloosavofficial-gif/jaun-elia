/**
 * Server settings, all from environment variables (see .env.example).
 * Nothing here is sent to the browser.
 */
const num = (v: string | undefined) => {
  if (v === undefined || v.trim() === "") return null;
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? Math.round(n) : null;
};

export const config = {
  databasePath: process.env.DATABASE_PATH || "data/store.db",

  /** Orders are accepted unless CHECKOUT_ENABLED=false (an off switch for launch day or sell-out). */
  checkoutEnabled: process.env.CHECKOUT_ENABLED !== "false",

  /**
   * Flat shipping fee in PKR added to every order. Unset = shipping is not
   * charged at checkout; the order is saved with shipping "to be confirmed"
   * and the team sets it from /admin when confirming the order.
   */
  shippingFlatFee: num(process.env.SHIPPING_FLAT_FEE_PKR),

  /** Password for /admin. Unset = the admin area and its API are switched off. */
  adminPassword: process.env.ADMIN_PASSWORD || null,

  /** Email (optional). Without RESEND_API_KEY + MAIL_FROM, emails are logged to the server console only. */
  mail: {
    resendApiKey: process.env.RESEND_API_KEY || null,
    from: process.env.MAIL_FROM || null,
    /** Where new-order and contact-form notifications go. */
    teamInbox: process.env.TEAM_INBOX_EMAIL || null,
  },

  /** Trust X-Forwarded-For for rate limiting (set when behind a proxy/CDN you control). */
  trustProxy: process.env.TRUST_PROXY === "true",
};

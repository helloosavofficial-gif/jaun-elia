import { config } from "./config";

/**
 * Outgoing email. Sends through Resend's HTTP API when RESEND_API_KEY and
 * MAIL_FROM are set; otherwise writes the message to the server log so
 * nothing is silently lost in development. Never throws: a mail failure must
 * not fail the order or message that triggered it.
 */
export type Mail = { to: string; subject: string; text: string; replyTo?: string };

export async function sendMail(mail: Mail): Promise<void> {
  const { resendApiKey, from } = config.mail;
  if (!resendApiKey || !from) {
    console.info(`[mail:not-configured] to=${mail.to} subject="${mail.subject}"\n${mail.text}\n`);
    return;
  }
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${resendApiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: [mail.to],
        subject: mail.subject,
        text: mail.text,
        ...(mail.replyTo ? { reply_to: mail.replyTo } : {}),
      }),
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) console.error(`[mail] ${res.status} sending "${mail.subject}": ${await res.text()}`);
  } catch (err) {
    console.error(`[mail] failed sending "${mail.subject}":`, err);
  }
}

/** Sends to the team inbox if one is configured. */
export function notifyTeam(subject: string, text: string, replyTo?: string) {
  if (!config.mail.teamInbox) {
    console.info(`[team] ${subject}\n${text}\n`);
    return Promise.resolve();
  }
  return sendMail({ to: config.mail.teamInbox, subject, text, replyTo });
}

import { mkdirSync } from "node:fs";
import path from "node:path";
import { edition } from "@/content/edition";
import { hoodieProduct } from "@/content/products";
import { config } from "./config";

/**
 * Storage: SQLite through Node's built-in `node:sqlite` (Node 22.13+), so the
 * backend needs no extra packages. One file, `data/store.db` by default
 * (DATABASE_PATH to move it). Works on any host with a persistent disk; on a
 * serverless host (e.g. Vercel) swap this module for a hosted database — every
 * query lives in src/server/*.ts, nothing else touches SQL.
 *
 * Loaded with process.getBuiltinModule so the bundler never tries to resolve it.
 */

type Value = string | number | bigint | null | Uint8Array;
type Params = Record<string, Value> | Value[];
export type Statement = {
  run(...params: Value[]): { changes: number | bigint; lastInsertRowid: number | bigint };
  run(params: Record<string, Value>): { changes: number | bigint; lastInsertRowid: number | bigint };
  get(...params: Value[]): Record<string, unknown> | undefined;
  get(params: Record<string, Value>): Record<string, unknown> | undefined;
  all(...params: Value[]): Record<string, unknown>[];
  all(params: Record<string, Value>): Record<string, unknown>[];
};
export type Database = {
  exec(sql: string): void;
  prepare(sql: string): Statement;
  close(): void;
};
export type { Params };

const SCHEMA_VERSION = 1;

function open(): Database {
  const { DatabaseSync } = (process as unknown as { getBuiltinModule(id: string): unknown }).getBuiltinModule(
    "node:sqlite",
  ) as { DatabaseSync: new (file: string) => Database };

  const file = path.resolve(process.cwd(), config.databasePath);
  mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec("PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;");
  migrate(db);
  return db;
}

function migrate(db: Database) {
  const version = Number(db.prepare("PRAGMA user_version").get()?.user_version ?? 0);
  if (version >= SCHEMA_VERSION) return;

  db.exec(`
    BEGIN;
    CREATE TABLE IF NOT EXISTS inventory (
      product_id  TEXT PRIMARY KEY,
      total       INTEGER NOT NULL CHECK (total >= 0),
      remaining   INTEGER NOT NULL CHECK (remaining >= 0),
      updated_at  TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      code            TEXT NOT NULL UNIQUE,
      access_token    TEXT NOT NULL,
      idempotency_key TEXT UNIQUE,
      status          TEXT NOT NULL DEFAULT 'pending'
                      CHECK (status IN ('pending','confirmed','shipped','delivered','cancelled')),
      payment_method  TEXT NOT NULL,
      payment_status  TEXT NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid','paid','refunded')),
      currency        TEXT NOT NULL,
      subtotal        INTEGER NOT NULL,
      shipping        INTEGER,
      total           INTEGER NOT NULL,
      name            TEXT NOT NULL,
      email           TEXT NOT NULL,
      phone           TEXT NOT NULL,
      address         TEXT NOT NULL,
      city            TEXT NOT NULL,
      postcode        TEXT,
      notes           TEXT,
      admin_note      TEXT,
      created_at      TEXT NOT NULL,
      updated_at      TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS orders_created ON orders (created_at DESC);
    CREATE INDEX IF NOT EXISTS orders_status ON orders (status);

    CREATE TABLE IF NOT EXISTS order_items (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id    INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
      product_id  TEXT NOT NULL,
      name        TEXT NOT NULL,
      size        TEXT NOT NULL,
      qty         INTEGER NOT NULL CHECK (qty > 0),
      unit_price  INTEGER NOT NULL,
      line_total  INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS order_items_order ON order_items (order_id);

    CREATE TABLE IF NOT EXISTS order_events (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id    INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
      type        TEXT NOT NULL,
      detail      TEXT,
      created_at  TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS messages (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT NOT NULL,
      email       TEXT NOT NULL,
      phone       TEXT,
      order_code  TEXT,
      subject     TEXT NOT NULL,
      body        TEXT NOT NULL,
      handled     INTEGER NOT NULL DEFAULT 0,
      created_at  TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS subscribers (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      email       TEXT NOT NULL UNIQUE COLLATE NOCASE,
      source      TEXT,
      created_at  TEXT NOT NULL
    );

    PRAGMA user_version = ${SCHEMA_VERSION};
    COMMIT;
  `);

  // Seed the edition: 2,500 made, none sold before launch (content/edition.ts).
  db.prepare(
    "INSERT OR IGNORE INTO inventory (product_id, total, remaining, updated_at) VALUES (?, ?, ?, ?)",
  ).run(hoodieProduct.id, edition.total, edition.remaining, now());
}

export const now = () => new Date().toISOString();

/** One connection per server process (survives dev hot reloads). */
const g = globalThis as unknown as { __jaunDb?: Database };
export function db(): Database {
  if (!g.__jaunDb) g.__jaunDb = open();
  return g.__jaunDb;
}

/**
 * Runs `fn` inside a write transaction. node:sqlite is synchronous, so nothing
 * else in this process can interleave; BEGIN IMMEDIATE guards other processes.
 */
export function transaction<T>(fn: (d: Database) => T): T {
  const d = db();
  d.exec("BEGIN IMMEDIATE");
  try {
    const out = fn(d);
    d.exec("COMMIT");
    return out;
  } catch (err) {
    d.exec("ROLLBACK");
    throw err;
  }
}

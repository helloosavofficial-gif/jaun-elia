/** PKR amounts are whole rupees, stored as integers. */
export const formatMoney = (amount: number, currency = "PKR") =>
  `${currency} ${new Intl.NumberFormat("en-PK", { maximumFractionDigits: 0 }).format(amount)}`;

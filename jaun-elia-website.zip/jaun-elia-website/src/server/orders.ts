import { randomBytes, timingSafeEqual } from "node:crypto";
import { findProduct, MAX_QTY_PER_LINE } from "@/content/products";
import type { AdminOrder, OrderItem, OrderStatus, PaymentStatus, PublicOrder } from "@/lib/orderTypes";
import { ORDER_STATUSES, PAYMENT_LABEL, PAYMENT_STATUSES, STATUS_LABEL } from "@/lib/orderTypes";
import { config } from "./config";
import { db, now, transaction, type Database } from "./db";
import { release, reserve } from "./inventory";
import { notifyTeam, sendMail } from "./mail";
import { formatMoney } from "./money";
import { email, phone, text, type Result } from "./validate";

/* ── input ─────────────────────────────────────────────────────────── */

export type OrderInput = {
  lines: { productId: string; size: string; qty: number }[];
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  postcode: string;
  notes: string;
  paymentMethod: "cod";
  idempotencyKey: string | null;
};

const MAX_LINES = 10;

export function parseOrder(body: Record<string, unknown>): Result<OrderInput> {
  const fields: Record<string, string> = {};
  const c = (body.customer ?? {}) as Record<string, unknown>;

  const name = text(fields, "name", c.name, { min: 2, max: 100, label: "Full name" });
  const em = email(fields, "email", c.email);
  const ph = phone(fields, "phone", c.phone);
  const address = text(fields, "address", c.address, { min: 8, max: 300, label: "Address" });
  const city = text(fields, "city", c.city, { min: 2, max: 80, label: "City" });
  const postcode = text(fields, "postcode", c.postcode, { max: 12, label: "Postal code" });
  if (postcode && !/^[A-Za-z0-9 -]+$/.test(postcode)) fields.postcode = "Use letters and numbers only.";
  const notes = text(fields, "notes", c.notes, { max: 500, label: "Delivery notes", multiline: true });

  if (body.paymentMethod !== "cod") fields.paymentMethod = "Choose a payment method.";

  // Lines: product id, size, qty only. Prices are always read on the server.
  const lines: OrderInput["lines"] = [];
  const raw = Array.isArray(body.lines) ? body.lines : [];
  if (raw.length === 0) fields.lines = "Your bag is empty.";
  else if (raw.length > MAX_LINES) fields.lines = "Too many lines in this order.";
  else {
    for (const l of raw) {
      const { productId, size, qty } = (l ?? {}) as Record<string, unknown>;
      const product = typeof productId === "string" ? findProduct(productId) : undefined;
      if (!product || typeof size !== "string" || !product.sizes.includes(size)) {
        fields.lines = "Something in your bag is no longer available. Please review your bag.";
        break;
      }
      if (typeof qty !== "number" || !Number.isInteger(qty) || qty < 1 || qty > MAX_QTY_PER_LINE) {
        fields.lines = `Quantities must be between 1 and ${MAX_QTY_PER_LINE}.`;
        break;
      }
      const same = lines.find((x) => x.productId === product.id && x.size === size);
      if (same) same.qty = Math.min(MAX_QTY_PER_LINE, same.qty + qty);
      else lines.push({ productId: product.id, size, qty });
    }
  }

  const key = typeof body.idempotencyKey === "string" && /^[\w-]{16,64}$/.test(body.idempotencyKey) ? body.idempotencyKey : null;

  if (Object.keys(fields).length) return { ok: false, fields };
  return {
    ok: true,
    value: {
      lines,
      name,
      email: em,
      phone: ph,
      address,
      city,
      postcode,
      notes,
      paymentMethod: "cod",
      idempotencyKey: key,
    },
  };
}

/* ── create ────────────────────────────────────────────────────────── */

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O, 1/I
function orderCode() {
  const bytes = randomBytes(8);
  let s = "";
  for (const b of bytes) s += CODE_ALPHABET[b % CODE_ALPHABET.length];
  return `JE-${s.slice(0, 4)}-${s.slice(4)}`;
}

export class OrderError extends Error {
  constructor(
    public status: number,
    message: string,
    public fields?: Record<string, string>,
  ) {
    super(message);
  }
}

export type Created = { code: string; token: string; replay: boolean };

export function createOrder(input: OrderInput): Created {
  return transaction((d) => {
    if (input.idempotencyKey) {
      const prev = d.prepare("SELECT code, access_token FROM orders WHERE idempotency_key = ?").get(input.idempotencyKey);
      if (prev) return { code: String(prev.code), token: String(prev.access_token), replay: true };
    }

    // Price every line from the catalogue, never from the browser.
    const items: OrderItem[] = input.lines.map((l) => {
      const p = findProduct(l.productId)!;
      return { productId: p.id, name: p.name, size: l.size, qty: l.qty, unitPrice: p.price, lineTotal: p.price * l.qty };
    });
    const currency = findProduct(items[0].productId)!.currency;

    // The edition is counted per product; take every piece or none.
    const perProduct = new Map<string, number>();
    for (const i of items) perProduct.set(i.productId, (perProduct.get(i.productId) ?? 0) + i.qty);
    for (const [productId, qty] of perProduct) {
      if (!reserve(d, productId, qty)) {
        const left = Number(d.prepare("SELECT remaining FROM inventory WHERE product_id = ?").get(productId)?.remaining ?? 0);
        throw new OrderError(
          409,
          left === 0
            ? "The edition has sold out. Nothing has been charged."
            : `Only ${left} ${left === 1 ? "piece remains" : "pieces remain"}. Please reduce the quantity in your bag.`,
          { lines: "Not enough pieces left." },
        );
      }
    }

    const subtotal = items.reduce((n, i) => n + i.lineTotal, 0);
    const shipping = config.shippingFlatFee;
    const total = subtotal + (shipping ?? 0);
    const t = now();
    const code = orderCode();
    const token = randomBytes(24).toString("base64url");

    const res = d
      .prepare(
        `INSERT INTO orders (code, access_token, idempotency_key, status, payment_method, payment_status, currency,
           subtotal, shipping, total, name, email, phone, address, city, postcode, notes, created_at, updated_at)
         VALUES (?, ?, ?, 'pending', ?, 'unpaid', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        code,
        token,
        input.idempotencyKey,
        input.paymentMethod,
        currency,
        subtotal,
        shipping,
        total,
        input.name,
        input.email,
        input.phone,
        input.address,
        input.city,
        input.postcode || null,
        input.notes || null,
        t,
        t,
      );
    const orderId = Number(res.lastInsertRowid);

    const ins = d.prepare(
      "INSERT INTO order_items (order_id, product_id, name, size, qty, unit_price, line_total) VALUES (?, ?, ?, ?, ?, ?, ?)",
    );
    for (const i of items) ins.run(orderId, i.productId, i.name, i.size, i.qty, i.unitPrice, i.lineTotal);
    logEvent(d, orderId, "created", `${PAYMENT_LABEL[input.paymentMethod]} · ${formatMoney(total, currency)}`);

    return { code, token, replay: false };
  });
}

/* ── read ──────────────────────────────────────────────────────────── */

function items(orderId: number): OrderItem[] {
  return db()
    .prepare("SELECT * FROM order_items WHERE order_id = ? ORDER BY id")
    .all(orderId)
    .map((r) => ({
      productId: String(r.product_id),
      name: String(r.name),
      size: String(r.size),
      qty: Number(r.qty),
      unitPrice: Number(r.unit_price),
      lineTotal: Number(r.line_total),
    }));
}

const str = (v: unknown) => (v === null || v === undefined ? null : String(v));

function toPublic(r: Record<string, unknown>): PublicOrder {
  return {
    code: String(r.code),
    status: r.status as OrderStatus,
    paymentMethod: r.payment_method as "cod",
    paymentStatus: r.payment_status as PaymentStatus,
    currency: String(r.currency),
    subtotal: Number(r.subtotal),
    shipping: r.shipping === null ? null : Number(r.shipping),
    total: Number(r.total),
    name: String(r.name),
    email: String(r.email),
    phone: String(r.phone),
    address: String(r.address),
    city: String(r.city),
    postcode: str(r.postcode),
    notes: str(r.notes),
    items: items(Number(r.id)),
    createdAt: String(r.created_at),
  };
}

function toAdmin(r: Record<string, unknown>): AdminOrder {
  const id = Number(r.id);
  return {
    ...toPublic(r),
    id,
    adminNote: str(r.admin_note),
    updatedAt: String(r.updated_at),
    events: db()
      .prepare("SELECT type, detail, created_at FROM order_events WHERE order_id = ? ORDER BY id")
      .all(id)
      .map((e) => ({ type: String(e.type), detail: str(e.detail), createdAt: String(e.created_at) })),
  };
}

const safeEqual = (a: string, b: string) => {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
};

/** The customer's view: needs the private token from their confirmation link. */
export function getOrderForCustomer(code: string, token: string): PublicOrder | null {
  const r = db().prepare("SELECT * FROM orders WHERE code = ?").get(code.toUpperCase());
  if (!r || !token || !safeEqual(String(r.access_token), token)) return null;
  return toPublic(r);
}

export function getOrderForAdmin(code: string): AdminOrder | null {
  const r = db().prepare("SELECT * FROM orders WHERE code = ?").get(code.toUpperCase());
  return r ? toAdmin(r) : null;
}

export function listOrders({ status, q, limit = 50, offset = 0 }: { status?: string; q?: string; limit?: number; offset?: number }) {
  const where: string[] = [];
  const params: (string | number)[] = [];
  if (status && (ORDER_STATUSES as readonly string[]).includes(status)) {
    where.push("status = ?");
    params.push(status);
  }
  if (q) {
    where.push("(code LIKE ? OR name LIKE ? OR email LIKE ? OR phone LIKE ? OR city LIKE ?)");
    const like = `%${q.replace(/[%_]/g, "")}%`;
    params.push(like, like, like, like, like);
  }
  const sqlWhere = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const rows = db()
    .prepare(`SELECT * FROM orders ${sqlWhere} ORDER BY created_at DESC LIMIT ? OFFSET ?`)
    .all(...params, limit, offset);
  const count = Number(db().prepare(`SELECT COUNT(*) AS n FROM orders ${sqlWhere}`).get(...params)?.n ?? 0);
  return { orders: rows.map(toAdmin), count };
}

export function orderSummary() {
  const d = db();
  const byStatus = Object.fromEntries(ORDER_STATUSES.map((s) => [s, 0])) as Record<OrderStatus, number>;
  for (const r of d.prepare("SELECT status, COUNT(*) AS n FROM orders GROUP BY status").all())
    byStatus[r.status as OrderStatus] = Number(r.n);
  const live = d
    .prepare("SELECT COALESCE(SUM(total),0) AS revenue, COALESCE(SUM(oi.pieces),0) AS pieces FROM orders o JOIN (SELECT order_id, SUM(qty) AS pieces FROM order_items GROUP BY order_id) oi ON oi.order_id = o.id WHERE status != 'cancelled'")
    .get();
  return { byStatus, revenue: Number(live?.revenue ?? 0), pieces: Number(live?.pieces ?? 0) };
}

/* ── update (admin) ────────────────────────────────────────────────── */

function logEvent(d: Database, orderId: number, type: string, detail: string | null) {
  d.prepare("INSERT INTO order_events (order_id, type, detail, created_at) VALUES (?, ?, ?, ?)").run(orderId, type, detail, now());
}

/** Allowed moves. Cancelled and delivered are final. */
const NEXT: Record<OrderStatus, OrderStatus[]> = {
  pending: ["confirmed", "cancelled"],
  confirmed: ["shipped", "cancelled"],
  shipped: ["delivered"],
  delivered: [],
  cancelled: [],
};

export type OrderPatch = {
  status?: OrderStatus;
  paymentStatus?: PaymentStatus;
  shipping?: number | null;
  adminNote?: string | null;
};

export function parsePatch(body: Record<string, unknown>): Result<OrderPatch> {
  const fields: Record<string, string> = {};
  const out: OrderPatch = {};
  if (body.status !== undefined) {
    if ((ORDER_STATUSES as readonly unknown[]).includes(body.status)) out.status = body.status as OrderStatus;
    else fields.status = "Unknown status.";
  }
  if (body.paymentStatus !== undefined) {
    if ((PAYMENT_STATUSES as readonly unknown[]).includes(body.paymentStatus)) out.paymentStatus = body.paymentStatus as PaymentStatus;
    else fields.paymentStatus = "Unknown payment status.";
  }
  if (body.shipping !== undefined) {
    if (body.shipping === null) out.shipping = null;
    else if (typeof body.shipping === "number" && Number.isInteger(body.shipping) && body.shipping >= 0 && body.shipping <= 100_000)
      out.shipping = body.shipping;
    else fields.shipping = "Shipping must be a whole number of rupees.";
  }
  if (body.adminNote !== undefined) {
    if (body.adminNote === null || (typeof body.adminNote === "string" && body.adminNote.length <= 1000))
      out.adminNote = body.adminNote ? String(body.adminNote).trim() || null : null;
    else fields.adminNote = "Note is too long.";
  }
  return Object.keys(fields).length ? { ok: false, fields } : { ok: true, value: out };
}

export function updateOrder(code: string, patch: OrderPatch): AdminOrder {
  const notifyCustomer = transaction((d) => {
    const r = d.prepare("SELECT * FROM orders WHERE code = ?").get(code.toUpperCase());
    if (!r) throw new OrderError(404, "Order not found.");
    const id = Number(r.id);
    const from = r.status as OrderStatus;
    const sets: string[] = [];
    const params: (string | number | null)[] = [];
    let statusChanged: OrderStatus | null = null;

    if (patch.status && patch.status !== from) {
      if (!NEXT[from].includes(patch.status))
        throw new OrderError(422, `An order that is ${STATUS_LABEL[from].toLowerCase()} can't be marked ${STATUS_LABEL[patch.status].toLowerCase()}.`);
      sets.push("status = ?");
      params.push(patch.status);
      statusChanged = patch.status;
      if (patch.status === "cancelled") {
        for (const i of items(id)) release(d, i.productId, i.qty);
        logEvent(d, id, "restocked", `${items(id).reduce((n, i) => n + i.qty, 0)} piece(s) returned to stock`);
      }
      logEvent(d, id, "status", `${STATUS_LABEL[from]} → ${STATUS_LABEL[patch.status]}`);
    }
    if (patch.paymentStatus && patch.paymentStatus !== r.payment_status) {
      sets.push("payment_status = ?");
      params.push(patch.paymentStatus);
      logEvent(d, id, "payment", `${r.payment_status} → ${patch.paymentStatus}`);
    }
    if (patch.shipping !== undefined && patch.shipping !== (r.shipping === null ? null : Number(r.shipping))) {
      sets.push("shipping = ?", "total = ?");
      params.push(patch.shipping, Number(r.subtotal) + (patch.shipping ?? 0));
      logEvent(d, id, "shipping", patch.shipping === null ? "Shipping cleared" : `Shipping set to ${formatMoney(patch.shipping, String(r.currency))}`);
    }
    if (patch.adminNote !== undefined && patch.adminNote !== str(r.admin_note)) {
      sets.push("admin_note = ?");
      params.push(patch.adminNote);
    }
    if (sets.length) {
      sets.push("updated_at = ?");
      params.push(now());
      d.prepare(`UPDATE orders SET ${sets.join(", ")} WHERE id = ?`).run(...params, id);
    }
    return statusChanged;
  });

  const order = getOrderForAdmin(code)!;
  if (notifyCustomer && notifyCustomer !== "pending") void sendMail(statusMail(order));
  return order;
}

/* ── emails ────────────────────────────────────────────────────────── */

function itemLines(o: PublicOrder) {
  return o.items.map((i) => `  ${i.qty} × ${i.name}, size ${i.size} — ${formatMoney(i.lineTotal, o.currency)}`).join("\n");
}

function totals(o: PublicOrder) {
  return [
    `Subtotal: ${formatMoney(o.subtotal, o.currency)}`,
    `Shipping: ${o.shipping === null ? "to be confirmed" : formatMoney(o.shipping, o.currency)}`,
    `Total: ${formatMoney(o.total, o.currency)}${o.shipping === null ? " + shipping" : ""}`,
  ].join("\n");
}

export function orderLink(origin: string, code: string, token: string) {
  return `${origin}/order/${code}?t=${encodeURIComponent(token)}`;
}

export function sendOrderEmails(o: PublicOrder, link: string) {
  void sendMail({
    to: o.email,
    subject: `Order ${o.code} received — Jaun Elia`,
    text: [
      `Thank you, ${o.name.split(" ")[0]}.`,
      "",
      `We have your order ${o.code}. Payment is ${PAYMENT_LABEL[o.paymentMethod].toLowerCase()}.`,
      "We will contact you to confirm it before it ships.",
      "",
      itemLines(o),
      "",
      totals(o),
      "",
      `Deliver to: ${o.name}, ${o.address}, ${o.city}${o.postcode ? ` ${o.postcode}` : ""} · ${o.phone}`,
      "",
      `Your order, any time: ${link}`,
    ].join("\n"),
  });
  void notifyTeam(
    `New order ${o.code} · ${formatMoney(o.total, o.currency)}`,
    [
      `${o.name} · ${o.email} · ${o.phone}`,
      `${o.address}, ${o.city}${o.postcode ? ` ${o.postcode}` : ""}`,
      o.notes ? `Notes: ${o.notes}` : "",
      "",
      itemLines(o),
      "",
      totals(o),
    ]
      .filter((l) => l !== null)
      .join("\n"),
    o.email,
  );
}

function statusMail(o: PublicOrder) {
  const line: Record<OrderStatus, string> = {
    pending: "",
    confirmed: "Your order is confirmed and being prepared.",
    shipped: "Your order is on its way.",
    delivered: "Your order has been delivered. We hope it stays with you.",
    cancelled: "Your order has been cancelled. If you did not expect this, reply to this email.",
  };
  return {
    to: o.email,
    subject: `Order ${o.code} · ${STATUS_LABEL[o.status]}`,
    text: [line[o.status], "", itemLines(o), "", totals(o)].join("\n"),
  };
}

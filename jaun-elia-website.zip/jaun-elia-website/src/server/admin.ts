import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { config } from "./config";
import { error, sameOrigin } from "./http";

/**
 * Admin sign-in: one shared password (ADMIN_PASSWORD) exchanged for a signed,
 * HttpOnly, SameSite=Strict session cookie that lasts 12 hours. Changing the
 * password signs everyone out. No password = admin switched off.
 */

export const ADMIN_COOKIE = "je_admin";
const TTL_MS = 12 * 60 * 60 * 1000;

const key = () => createHmac("sha256", "jaun-elia-admin-session").update(config.adminPassword ?? "").digest();
const sign = (payload: string) => createHmac("sha256", key()).update(payload).digest("base64url");

const eq = (a: string, b: string) => {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
};

export function checkPassword(given: string): boolean {
  if (!config.adminPassword) return false;
  // compare digests so the length of the real password isn't leaked by timing
  const h = (s: string) => createHmac("sha256", "cmp").update(s).digest("base64url");
  return eq(h(given), h(config.adminPassword));
}

export function newSession() {
  const exp = Date.now() + TTL_MS;
  return { value: `${exp}.${sign(String(exp))}`, maxAge: TTL_MS / 1000 };
}

export function validSession(value: string | undefined): boolean {
  if (!config.adminPassword || !value) return false;
  const [exp, sig] = value.split(".");
  if (!exp || !sig || !eq(sig, sign(exp))) return false;
  return Number(exp) > Date.now();
}

export async function isAdmin(): Promise<boolean> {
  return validSession((await cookies()).get(ADMIN_COOKIE)?.value);
}

/** Guard for admin API routes: returns an error response, or null to carry on. */
export async function requireAdmin(req: Request) {
  if (!config.adminPassword) return error(503, "Admin is switched off. Set ADMIN_PASSWORD to turn it on.");
  if (!(await isAdmin())) return error(401, "Please sign in again.");
  if (req.method !== "GET" && !sameOrigin(req)) return error(403, "Cross-site request refused.");
  return null;
}

export const cookieOptions = (maxAge: number) => ({
  httpOnly: true,
  sameSite: "strict" as const,
  secure: process.env.NODE_ENV === "production",
  path: "/",
  maxAge,
});

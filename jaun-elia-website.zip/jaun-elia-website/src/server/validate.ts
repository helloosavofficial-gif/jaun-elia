/**
 * Input checks for everything the public can send. Hand-written (no schema
 * library) and shared shape: each returns either clean values or field errors
 * keyed by input name, so forms can show the message next to the right field.
 */

export type Result<T> = { ok: true; value: T } | { ok: false; fields: Record<string, string> };

const clean = (v: unknown) => (typeof v === "string" ? v.replace(/\s+/g, " ").trim() : "");
const cleanMultiline = (v: unknown) => (typeof v === "string" ? v.replace(/\r\n?/g, "\n").trim() : "");

export const EMAIL = /^[^\s@<>()[\],;:"]+@[^\s@<>()[\],;:"]+\.[a-z]{2,}$/i;

export function text(
  fields: Record<string, string>,
  name: string,
  raw: unknown,
  { min = 0, max, label, multiline = false }: { min?: number; max: number; label: string; multiline?: boolean },
): string {
  const v = multiline ? cleanMultiline(raw) : clean(raw);
  if (min > 0 && v.length === 0) fields[name] = `Enter your ${label.toLowerCase()}.`;
  else if (v.length < min) fields[name] = `${label} looks too short.`;
  else if (v.length > max) fields[name] = `${label} must be at most ${max} characters.`;
  return v;
}

export function email(fields: Record<string, string>, name: string, raw: unknown): string {
  const v = clean(raw).toLowerCase();
  if (!v) fields[name] = "Enter your email address.";
  else if (v.length > 254 || !EMAIL.test(v)) fields[name] = "Enter a valid email address, like name@example.com.";
  return v;
}

/** Phone numbers: digits with optional +, spaces, dashes, brackets; 10–15 digits (fits Pakistani and international). */
export function phone(fields: Record<string, string>, name: string, raw: unknown, required = true): string {
  const v = clean(raw);
  if (!v) {
    if (required) fields[name] = "Enter a phone number so the courier can reach you.";
    return v;
  }
  const digits = v.replace(/\D/g, "");
  if (!/^\+?[\d\s\-()]+$/.test(v) || digits.length < 10 || digits.length > 15)
    fields[name] = "Enter a valid phone number, like 0300 1234567 or +92 300 1234567.";
  return v;
}

/** Honeypot: a hidden field real visitors never fill. */
export const isBot = (body: Record<string, unknown>) => clean(body.website).length > 0;

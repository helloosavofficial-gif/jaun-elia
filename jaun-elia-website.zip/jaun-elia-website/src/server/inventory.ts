import { edition } from "@/content/edition";
import { hoodieProduct } from "@/content/products";
import { db, now, type Database } from "./db";

export type StockRow = { productId: string; total: number; remaining: number; updatedAt: string };

const toRow = (r: Record<string, unknown>): StockRow => ({
  productId: String(r.product_id),
  total: Number(r.total),
  remaining: Number(r.remaining),
  updatedAt: String(r.updated_at),
});

export function getStock(productId = hoodieProduct.id): StockRow {
  const r = db().prepare("SELECT * FROM inventory WHERE product_id = ?").get(productId);
  return r
    ? toRow(r)
    : { productId, total: edition.total, remaining: edition.remaining, updatedAt: now() };
}

/** Takes `qty` pieces inside an open transaction; false if not enough remain. */
export function reserve(d: Database, productId: string, qty: number): boolean {
  const res = d
    .prepare("UPDATE inventory SET remaining = remaining - ?, updated_at = ? WHERE product_id = ? AND remaining >= ?")
    .run(qty, now(), productId, qty);
  return Number(res.changes) === 1;
}

/** Puts pieces back (cancelled order), never above the edition total. */
export function release(d: Database, productId: string, qty: number) {
  d.prepare(
    "UPDATE inventory SET remaining = MIN(total, remaining + ?), updated_at = ? WHERE product_id = ?",
  ).run(qty, now(), productId);
}

/** Admin correction of the count (e.g. after a stock take). */
export function setStock(productId: string, total: number, remaining: number): StockRow {
  db()
    .prepare(
      `INSERT INTO inventory (product_id, total, remaining, updated_at) VALUES (?, ?, ?, ?)
       ON CONFLICT (product_id) DO UPDATE SET total = excluded.total, remaining = excluded.remaining, updated_at = excluded.updated_at`,
    )
    .run(productId, total, remaining, now());
  return getStock(productId);
}

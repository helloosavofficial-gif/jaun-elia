import { db, now } from "./db";
import { notifyTeam } from "./mail";
import { email, phone, text, type Result } from "./validate";

/* ── contact form ──────────────────────────────────────────────────── */

export const SUBJECTS = ["Order", "Sizing", "Product", "Press & collaborations", "Other"] as const;

export type MessageInput = {
  name: string;
  email: string;
  phone: string;
  orderCode: string;
  subject: (typeof SUBJECTS)[number];
  body: string;
};

export function parseMessage(b: Record<string, unknown>): Result<MessageInput> {
  const fields: Record<string, string> = {};
  const name = text(fields, "name", b.name, { min: 2, max: 100, label: "Name" });
  const em = email(fields, "email", b.email);
  const ph = phone(fields, "phone", b.phone, false);
  const orderCode = text(fields, "orderCode", b.orderCode, { max: 20, label: "Order number" }).toUpperCase();
  if (orderCode && !/^JE-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(orderCode)) fields.orderCode = "Order numbers look like JE-ABCD-2345.";
  const subject = (SUBJECTS as readonly unknown[]).includes(b.subject) ? (b.subject as MessageInput["subject"]) : null;
  if (!subject) fields.subject = "Choose what your message is about.";
  const body = text(fields, "body", b.body, { min: 10, max: 4000, label: "Message", multiline: true });
  return Object.keys(fields).length
    ? { ok: false, fields }
    : { ok: true, value: { name, email: em, phone: ph, orderCode, subject: subject!, body } };
}

export function saveMessage(m: MessageInput) {
  db()
    .prepare("INSERT INTO messages (name, email, phone, order_code, subject, body, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
    .run(m.name, m.email, m.phone || null, m.orderCode || null, m.subject, m.body, now());
  void notifyTeam(
    `Message · ${m.subject}${m.orderCode ? ` · ${m.orderCode}` : ""} — ${m.name}`,
    [`${m.name} · ${m.email}${m.phone ? ` · ${m.phone}` : ""}`, "", m.body].join("\n"),
    m.email,
  );
}

export type Message = MessageInput & { id: number; handled: boolean; createdAt: string };

export function listMessages(): Message[] {
  return db()
    .prepare("SELECT * FROM messages ORDER BY handled ASC, created_at DESC LIMIT 200")
    .all()
    .map((r) => ({
      id: Number(r.id),
      name: String(r.name),
      email: String(r.email),
      phone: r.phone ? String(r.phone) : "",
      orderCode: r.order_code ? String(r.order_code) : "",
      subject: r.subject as Message["subject"],
      body: String(r.body),
      handled: Boolean(r.handled),
      createdAt: String(r.created_at),
    }));
}

export function setHandled(id: number, handled: boolean) {
  return Number(db().prepare("UPDATE messages SET handled = ? WHERE id = ?").run(handled ? 1 : 0, id).changes) === 1;
}

/* ── release list ("Notify me") ────────────────────────────────────── */

export function parseSubscribe(b: Record<string, unknown>): Result<{ email: string; source: string }> {
  const fields: Record<string, string> = {};
  const em = email(fields, "email", b.email);
  const source = typeof b.source === "string" ? b.source.slice(0, 40) : "site";
  return Object.keys(fields).length ? { ok: false, fields } : { ok: true, value: { email: em, source } };
}

/** Adds the address once; signing up twice is not an error (and doesn't reveal who is already on the list). */
export function subscribe(emailAddr: string, source: string) {
  db().prepare("INSERT OR IGNORE INTO subscribers (email, source, created_at) VALUES (?, ?, ?)").run(emailAddr, source, now());
}

export function unsubscribe(emailAddr: string) {
  db().prepare("DELETE FROM subscribers WHERE email = ?").run(emailAddr);
}

export function listSubscribers() {
  return db()
    .prepare("SELECT email, source, created_at FROM subscribers ORDER BY created_at DESC")
    .all()
    .map((r) => ({ email: String(r.email), source: r.source ? String(r.source) : "", createdAt: String(r.created_at) }));
}

"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ORDER_STATUSES,
  PAYMENT_LABEL,
  STATUS_LABEL,
  type AdminOrder,
  type OrderStatus,
  type PaymentStatus,
} from "@/lib/orderTypes";
import styles from "./admin.module.css";

/* ── tiny API helper: every admin call goes through here ─────────────── */

type ApiResult<T> = { ok: true; data: T } | { ok: false; error: string; status: number };
type Guard = <T>(r: ApiResult<T>) => ApiResult<T>;

async function api<T>(url: string, init?: RequestInit): Promise<ApiResult<T>> {
  try {
    const res = await fetch(url, { ...init, headers: { "Content-Type": "application/json" }, cache: "no-store" });
    const data = await res.json().catch(() => ({}));
    return res.ok ? { ok: true, data } : { ok: false, error: data.error ?? `Error ${res.status}`, status: res.status };
  } catch {
    return { ok: false, error: "Couldn't reach the server.", status: 0 };
  }
}

const money = (n: number, c = "PKR") => `${c} ${new Intl.NumberFormat("en-PK").format(n)}`;
const when = (iso: string) =>
  new Intl.DateTimeFormat("en-PK", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Karachi" }).format(new Date(iso));
const ago = (iso: string) => {
  const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h ago`;
  return when(iso);
};

type Tab = "orders" | "messages" | "list" | "edition";
type Summary = { byStatus: Record<OrderStatus, number>; revenue: number; pieces: number };

export function AdminApp() {
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("orders");
  const [expired, setExpired] = useState(false);

  const signOut = async () => {
    await fetch("/api/admin/session", { method: "DELETE" });
    router.refresh();
  };

  /** Any 401 means the session ran out: show the sign-in again. */
  const guard: Guard = useCallback(<T,>(r: ApiResult<T>) => {
    if (!r.ok && r.status === 401) setExpired(true);
    return r;
  }, []);

  useEffect(() => {
    if (expired) router.refresh();
  }, [expired, router]);

  if (expired) return null;

  return (
    <div className={styles.app}>
      <header className={styles.bar}>
        <p className={styles.brand}>
          Jaun Elia <span>Order desk</span>
        </p>
        <nav className={styles.tabs} aria-label="Sections">
          {(
            [
              ["orders", "Orders"],
              ["messages", "Messages"],
              ["list", "Release list"],
              ["edition", "Edition"],
            ] as [Tab, string][]
          ).map(([t, label]) => (
            <button key={t} type="button" data-on={tab === t} aria-current={tab === t ? "page" : undefined} onClick={() => setTab(t)}>
              {label}
            </button>
          ))}
        </nav>
        <div className={styles.barEnd}>
          <a href="/" target="_blank" rel="noreferrer">
            View site ↗
          </a>
          <button type="button" onClick={signOut}>
            Sign out
          </button>
        </div>
      </header>

      <main id="main" className={styles.main} key={tab}>
        {tab === "orders" && <Orders guard={guard} />}
        {tab === "messages" && <Messages guard={guard} />}
        {tab === "list" && <ReleaseList guard={guard} />}
        {tab === "edition" && <Edition guard={guard} />}
      </main>
    </div>
  );
}

/* ── Orders ──────────────────────────────────────────────────────────── */

function Orders({ guard }: { guard: Guard }) {
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [count, setCount] = useState(0);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [status, setStatus] = useState<OrderStatus | "">("");
  const [q, setQ] = useState("");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [open, setOpen] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const sp = new URLSearchParams();
    if (status) sp.set("status", status);
    if (query) sp.set("q", query);
    const r = guard(await api<{ orders: AdminOrder[]; count: number; summary: Summary }>(`/api/admin/orders?${sp}`));
    setLoading(false);
    if (!r.ok) return setError(r.error);
    setError("");
    setOrders(r.data.orders);
    setCount(r.data.count);
    setSummary(r.data.summary);
  }, [status, query, guard]);

  useEffect(() => {
    load();
  }, [load]);

  // debounce the search box
  useEffect(() => {
    const t = setTimeout(() => setQuery(q.trim()), 250);
    return () => clearTimeout(t);
  }, [q]);

  // refresh quietly every minute so new orders appear
  useEffect(() => {
    const t = setInterval(() => document.visibilityState === "visible" && load(), 60_000);
    return () => clearInterval(t);
  }, [load]);

  const selected = orders.find((o) => o.code === open) ?? null;
  const replace = (o: AdminOrder) => {
    setOrders((list) => list.map((x) => (x.code === o.code ? o : x)));
    load();
  };

  return (
    <>
      {summary && (
        <dl className={styles.stats}>
          <div>
            <dt>To confirm</dt>
            <dd>{summary.byStatus.pending}</dd>
          </div>
          <div>
            <dt>To ship</dt>
            <dd>{summary.byStatus.confirmed}</dd>
          </div>
          <div>
            <dt>In transit</dt>
            <dd>{summary.byStatus.shipped}</dd>
          </div>
          <div>
            <dt>Delivered</dt>
            <dd>{summary.byStatus.delivered}</dd>
          </div>
          <div>
            <dt>Pieces ordered</dt>
            <dd>{summary.pieces.toLocaleString("en-PK")}</dd>
          </div>
          <div>
            <dt>Order value</dt>
            <dd>{money(summary.revenue)}</dd>
          </div>
        </dl>
      )}

      <div className={styles.toolbar}>
        <div className={styles.chips} role="group" aria-label="Filter by status">
          <button type="button" data-on={status === ""} onClick={() => setStatus("")}>
            All
          </button>
          {ORDER_STATUSES.map((s) => (
            <button key={s} type="button" data-on={status === s} onClick={() => setStatus(s)}>
              {STATUS_LABEL[s]}
              {summary ? <span>{summary.byStatus[s]}</span> : null}
            </button>
          ))}
        </div>
        <input
          className={styles.search}
          type="search"
          placeholder="Search code, name, phone, city"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Search orders"
        />
      </div>

      {error && <p className={styles.error}>{error}</p>}

      <div className={styles.split} data-open={Boolean(selected)}>
        <div className={styles.tableWrap} aria-busy={loading}>
          {orders.length === 0 && !loading ? (
            <p className={styles.empty}>{query || status ? "No orders match." : "No orders yet. They'll appear here as they come in."}</p>
          ) : (
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Customer</th>
                  <th>City</th>
                  <th className={styles.num}>Pcs</th>
                  <th className={styles.num}>Total</th>
                  <th>Status</th>
                  <th>Placed</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((o) => (
                  <tr
                    key={o.code}
                    data-on={o.code === open}
                    tabIndex={0}
                    onClick={() => setOpen(o.code === open ? null : o.code)}
                    onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), setOpen(o.code === open ? null : o.code))}
                  >
                    <td className={styles.mono}>{o.code}</td>
                    <td>{o.name}</td>
                    <td>{o.city}</td>
                    <td className={styles.num}>{o.items.reduce((n, i) => n + i.qty, 0)}</td>
                    <td className={styles.num}>
                      {money(o.total, o.currency)}
                      {o.shipping === null && <span className={styles.flag} title="Shipping not set">+ship</span>}
                    </td>
                    <td>
                      <span className={styles.status} data-status={o.status}>
                        {STATUS_LABEL[o.status]}
                      </span>
                    </td>
                    <td className={styles.dim}>{ago(o.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {count > orders.length && <p className={styles.dim}>Showing the latest {orders.length} of {count}. Narrow with search or a filter.</p>}
        </div>

        {selected && <OrderPanel key={selected.code} order={selected} onClose={() => setOpen(null)} onSaved={replace} guard={guard} />}
      </div>
    </>
  );
}

const NEXT_ACTION: Partial<Record<OrderStatus, { to: OrderStatus; label: string }>> = {
  pending: { to: "confirmed", label: "Confirm order" },
  confirmed: { to: "shipped", label: "Mark shipped" },
  shipped: { to: "delivered", label: "Mark delivered" },
};

function OrderPanel({
  order: o,
  onClose,
  onSaved,
  guard,
}: {
  order: AdminOrder;
  onClose: () => void;
  onSaved: (o: AdminOrder) => void;
  guard: Guard;
}) {
  const [shipping, setShipping] = useState(o.shipping === null ? "" : String(o.shipping));
  const [note, setNote] = useState(o.adminNote ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [confirmCancel, setConfirmCancel] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const patch = async (body: Record<string, unknown>) => {
    setBusy(true);
    setError("");
    const r = guard(
      await api<AdminOrder>(`/api/admin/orders/${o.code}`, { method: "PATCH", body: JSON.stringify(body) }),
    );
    setBusy(false);
    setConfirmCancel(false);
    if (!r.ok) return setError(r.error);
    onSaved(r.data);
  };

  const shippingValue = shipping.trim() === "" ? null : Number(shipping);
  const shippingChanged = shippingValue !== o.shipping;
  const shippingValid = shippingValue === null || (Number.isInteger(shippingValue) && shippingValue >= 0);
  const next = NEXT_ACTION[o.status];
  const canCancel = o.status === "pending" || o.status === "confirmed";
  const pieces = o.items.reduce((n, i) => n + i.qty, 0);
  const waText = useMemo(() => o.phone.replace(/\D/g, "").replace(/^0/, "92"), [o.phone]);

  return (
    <aside className={styles.panel} aria-label={`Order ${o.code}`}>
      <div className={styles.panelHead}>
        <div>
          <p className={styles.mono}>{o.code}</p>
          <p className={styles.dim}>{when(o.createdAt)}</p>
        </div>
        <span className={styles.status} data-status={o.status}>
          {STATUS_LABEL[o.status]}
        </span>
        <button type="button" className={styles.close} onClick={onClose} aria-label="Close order">
          ×
        </button>
      </div>

      <section className={styles.panelSection}>
        <h3>Customer</h3>
        <p className={styles.strong}>{o.name}</p>
        <p>
          <a href={`tel:${o.phone.replace(/[^\d+]/g, "")}`}>{o.phone}</a> ·{" "}
          <a href={`https://wa.me/${waText}`} target="_blank" rel="noreferrer">
            WhatsApp
          </a>
        </p>
        <p>
          <a href={`mailto:${o.email}?subject=${encodeURIComponent(`Your order ${o.code}`)}`}>{o.email}</a>
        </p>
        <address>
          {o.address}
          <br />
          {o.city}
          {o.postcode ? ` ${o.postcode}` : ""}
        </address>
        {o.notes && <p className={styles.quote}>&ldquo;{o.notes}&rdquo;</p>}
      </section>

      <section className={styles.panelSection}>
        <h3>
          {pieces} {pieces === 1 ? "piece" : "pieces"}
        </h3>
        <ul className={styles.lines}>
          {o.items.map((i) => (
            <li key={`${i.productId}-${i.size}`}>
              <span>
                <b>{i.size}</b> × {i.qty}
              </span>
              <span>{money(i.lineTotal, o.currency)}</span>
            </li>
          ))}
        </ul>
        <dl className={styles.sums}>
          <div>
            <dt>Subtotal</dt>
            <dd>{money(o.subtotal, o.currency)}</dd>
          </div>
          <div>
            <dt>Shipping</dt>
            <dd>{o.shipping === null ? <em>not set</em> : money(o.shipping, o.currency)}</dd>
          </div>
          <div className={styles.sumTotal}>
            <dt>{PAYMENT_LABEL[o.paymentMethod]}</dt>
            <dd>{money(o.total, o.currency)}</dd>
          </div>
        </dl>
      </section>

      <section className={styles.panelSection}>
        <h3>Manage</h3>
        <div className={styles.inline}>
          <label className={styles.field}>
            <span>Shipping (PKR)</span>
            <input
              inputMode="numeric"
              value={shipping}
              onChange={(e) => setShipping(e.target.value.replace(/[^\d]/g, ""))}
              placeholder="e.g. 250"
              disabled={busy || o.status === "cancelled" || o.status === "delivered"}
            />
          </label>
          <button
            type="button"
            className={styles.secondary}
            disabled={busy || !shippingChanged || !shippingValid}
            onClick={() => patch({ shipping: shippingValue })}
          >
            Save
          </button>
        </div>

        <label className={styles.field}>
          <span>Payment</span>
          <select
            value={o.paymentStatus}
            disabled={busy}
            onChange={(e) => patch({ paymentStatus: e.target.value as PaymentStatus })}
          >
            <option value="unpaid">Unpaid</option>
            <option value="paid">Paid (cash received)</option>
            <option value="refunded">Refunded</option>
          </select>
        </label>

        <label className={styles.field}>
          <span>Team note (private)</span>
          <textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} disabled={busy} maxLength={1000} />
        </label>
        {note !== (o.adminNote ?? "") && (
          <button type="button" className={styles.secondary} disabled={busy} onClick={() => patch({ adminNote: note })}>
            Save note
          </button>
        )}

        {error && <p className={styles.error}>{error}</p>}

        <div className={styles.actions}>
          {next && (
            <button
              type="button"
              className={styles.primary}
              disabled={busy || (next.to === "shipped" && o.shipping === null)}
              title={next.to === "shipped" && o.shipping === null ? "Set the shipping cost first" : undefined}
              onClick={() => patch({ status: next.to })}
            >
              {next.label}
            </button>
          )}
          {canCancel &&
            (confirmCancel ? (
              <span className={styles.confirm}>
                Cancel and return {pieces} to stock?
                <button type="button" className={styles.danger} disabled={busy} onClick={() => patch({ status: "cancelled" })}>
                  Yes, cancel
                </button>
                <button type="button" className={styles.textBtn} onClick={() => setConfirmCancel(false)}>
                  Keep
                </button>
              </span>
            ) : (
              <button type="button" className={styles.textBtn} onClick={() => setConfirmCancel(true)}>
                Cancel order
              </button>
            ))}
        </div>
        {next?.to === "shipped" && o.shipping === null && <p className={styles.dim}>Set the shipping cost before marking it shipped.</p>}
        <p className={styles.dim}>The customer is emailed each time the status changes.</p>
      </section>

      <section className={styles.panelSection}>
        <h3>History</h3>
        <ol className={styles.history}>
          {o.events.map((e, i) => (
            <li key={i}>
              <span>{e.detail ?? e.type}</span>
              <time className={styles.dim}>{when(e.createdAt)}</time>
            </li>
          ))}
        </ol>
      </section>
    </aside>
  );
}

/* ── Messages ────────────────────────────────────────────────────────── */

type Message = {
  id: number;
  name: string;
  email: string;
  phone: string;
  orderCode: string;
  subject: string;
  body: string;
  handled: boolean;
  createdAt: string;
};

function Messages({ guard }: { guard: Guard }) {
  const [messages, setMessages] = useState<Message[] | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    const r = guard(await api<{ messages: Message[] }>("/api/admin/messages"));
    if (r.ok) setMessages(r.data.messages);
    else setError(r.error);
  }, [guard]);

  useEffect(() => {
    load();
  }, [load]);

  const toggle = async (m: Message) => {
    setMessages((list) => list?.map((x) => (x.id === m.id ? { ...x, handled: !m.handled } : x)) ?? null);
    const r = guard(await api("/api/admin/messages", { method: "PATCH", body: JSON.stringify({ id: m.id, handled: !m.handled }) }));
    if (!r.ok) {
      setError(r.error);
      load();
    }
  };

  if (error) return <p className={styles.error}>{error}</p>;
  if (!messages) return <p className={styles.dim}>Loading…</p>;
  if (messages.length === 0) return <p className={styles.empty}>No messages yet.</p>;

  const open = messages.filter((m) => !m.handled).length;

  return (
    <>
      <p className={styles.lede}>
        {open === 0 ? "All caught up." : `${open} to answer.`} Replies go out from your own email: each address opens a reply.
      </p>
      <ul className={styles.messages}>
        {messages.map((m) => (
          <li key={m.id} data-handled={m.handled}>
            <div className={styles.msgHead}>
              <span className={styles.tag}>{m.subject}</span>
              {m.orderCode && <span className={styles.mono}>{m.orderCode}</span>}
              <span className={styles.dim}>{ago(m.createdAt)}</span>
            </div>
            <p className={styles.strong}>
              {m.name} ·{" "}
              <a href={`mailto:${m.email}?subject=${encodeURIComponent(`Re: ${m.subject}`)}`}>{m.email}</a>
              {m.phone && <> · {m.phone}</>}
            </p>
            <p className={styles.body}>{m.body}</p>
            <button type="button" className={styles.textBtn} onClick={() => toggle(m)}>
              {m.handled ? "Mark as open" : "Mark answered"}
            </button>
          </li>
        ))}
      </ul>
    </>
  );
}

/* ── Release list ────────────────────────────────────────────────────── */

function ReleaseList({ guard }: { guard: Guard }) {
  const [subs, setSubs] = useState<{ email: string; source: string; createdAt: string }[] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      const r = guard(await api<{ subscribers: { email: string; source: string; createdAt: string }[] }>("/api/admin/subscribers"));
      if (r.ok) setSubs(r.data.subscribers);
      else setError(r.error);
    })();
  }, [guard]);

  if (error) return <p className={styles.error}>{error}</p>;
  if (!subs) return <p className={styles.dim}>Loading…</p>;

  return (
    <>
      <div className={styles.toolbar}>
        <p className={styles.lede}>
          {subs.length.toLocaleString("en-PK")} {subs.length === 1 ? "person" : "people"} asked to hear about releases.
        </p>
        {subs.length > 0 && (
          <a className={styles.secondary} href="/api/admin/subscribers?format=csv" download>
            Download CSV
          </a>
        )}
      </div>
      {subs.length === 0 ? (
        <p className={styles.empty}>No sign-ups yet.</p>
      ) : (
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Email</th>
              <th>From</th>
              <th>Joined</th>
            </tr>
          </thead>
          <tbody>
            {subs.map((s) => (
              <tr key={s.email}>
                <td>{s.email}</td>
                <td className={styles.dim}>{s.source}</td>
                <td className={styles.dim}>{when(s.createdAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </>
  );
}

/* ── Edition count ───────────────────────────────────────────────────── */

function Edition({ guard }: { guard: Guard }) {
  const [stock, setStock] = useState<{ total: number; remaining: number; updatedAt: string } | null>(null);
  const [total, setTotal] = useState("");
  const [remaining, setRemaining] = useState("");
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      const r = guard(await api<{ total: number; remaining: number; updatedAt: string }>("/api/admin/stock"));
      if (!r.ok) return setError(r.error);
      setStock(r.data);
      setTotal(String(r.data.total));
      setRemaining(String(r.data.remaining));
    })();
  }, [guard]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    setMsg("");
    const r = guard(
      await api<{ total: number; remaining: number; updatedAt: string }>("/api/admin/stock", {
        method: "PUT",
        body: JSON.stringify({ total: Number(total), remaining: Number(remaining) }),
      }),
    );
    setBusy(false);
    if (!r.ok) return setError(r.error);
    setStock(r.data);
    setMsg("Saved. The counter on the site updates within a few seconds.");
  };

  if (!stock) return error ? <p className={styles.error}>{error}</p> : <p className={styles.dim}>Loading…</p>;

  const sold = stock.total - stock.remaining;
  const changed = Number(total) !== stock.total || Number(remaining) !== stock.remaining;

  return (
    <div className={styles.edition}>
      <p className={styles.big}>
        {stock.remaining.toLocaleString("en-PK")}
        <span> / {stock.total.toLocaleString("en-PK")}</span>
      </p>
      <p className={styles.lede}>
        pieces remaining · {sold.toLocaleString("en-PK")} reserved by orders · updated {ago(stock.updatedAt)}
      </p>
      <span className={styles.meter} aria-hidden>
        <span style={{ transform: `scaleX(${stock.total ? stock.remaining / stock.total : 0})` }} />
      </span>

      <form className={styles.editionForm} onSubmit={save}>
        <p className={styles.dim}>
          Orders take pieces off automatically and cancelling puts them back. Change these only to correct the count
          after a stock take.
        </p>
        <div className={styles.inline}>
          <label className={styles.field}>
            <span>Edition total</span>
            <input inputMode="numeric" value={total} onChange={(e) => setTotal(e.target.value.replace(/\D/g, ""))} />
          </label>
          <label className={styles.field}>
            <span>Remaining</span>
            <input inputMode="numeric" value={remaining} onChange={(e) => setRemaining(e.target.value.replace(/\D/g, ""))} />
          </label>
          <button className={styles.secondary} disabled={busy || !changed || total === "" || remaining === ""}>
            Save count
          </button>
        </div>
        {error && <p className={styles.error}>{error}</p>}
        {msg && <p className={styles.ok}>{msg}</p>}
      </form>
    </div>
  );
}

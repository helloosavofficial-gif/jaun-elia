"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { flags, site } from "@/content/site";
import { NoonMark } from "@/components/Marks";
import { bagDrawer, useBag } from "@/lib/bag";
import { lockScroll, unlockScroll } from "@/lib/scroll";
import styles from "./SiteHeader.module.css";

const nav = [
  { label: "Shop", href: "/shop" },
  { label: "The Hoodie", href: "/shop/jaun-elia-hoodie" },
  { label: "Campaign", href: "/campaign" },
  { label: "Story", href: "/about" },
];

const menuExtra = [
  { label: "Size guide", href: "/size-guide" },
  { label: "Shipping & returns", href: "/shipping-returns" },
  { label: "Contact", href: "/contact" },
];

/** "/shop" stays current on product pages under it. */
const isCurrent = (pathname: string, href: string) =>
  href.startsWith("/#") ? false : href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);

/**
 * Site-wide header in the shape of a fashion storefront: a rotating
 * announcement bar, links left, the wordmark centred, the bag right.
 * A slab of prism glass: clear over the home cover and the campaign hero, smokier once scrolled; hides on the
 * way down and returns on the way up. On phones the links move into a
 * full-screen menu.
 */
export function SiteHeader() {
  const pathname = usePathname();
  const [hidden, setHidden] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [menu, setMenu] = useState(false);
  const [note, setNote] = useState(0);
  const { count } = useBag();
  const notes = site.announcements;

  useEffect(() => {
    let last = window.scrollY;
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 40);
      if (Math.abs(y - last) < 6) return;
      setHidden(y > 160 && y > last);
      last = y;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // rotate the announcement
  useEffect(() => {
    if (notes.length < 2) return;
    const t = window.setInterval(() => setNote((n) => (n + 1) % notes.length), 4500);
    return () => window.clearInterval(t);
  }, [notes.length]);

  useEffect(() => {
    setHidden(false);
    setMenu(false);
  }, [pathname]);

  useEffect(() => {
    if (!menu) return;
    lockScroll();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setMenu(false);
    window.addEventListener("keydown", onKey);
    return () => {
      unlockScroll();
      window.removeEventListener("keydown", onKey);
    };
  }, [menu]);

  // the band of light inside the glass drifts toward the pointer (CSS --gx, SiteHeader.module.css)
  const glass = useRef<HTMLElement>(null);
  useEffect(() => {
    const el = glass.current;
    if (!el || !window.matchMedia("(pointer: fine)").matches || window.matchMedia("(prefers-reduced-motion: reduce)").matches)
      return;
    let target = 30;
    let now = 30;
    let raf = 0;
    const tick = () => {
      now += (target - now) * 0.07;
      el.style.setProperty("--gx", now.toFixed(2));
      raf = Math.abs(target - now) > 0.05 ? requestAnimationFrame(tick) : 0;
    };
    const kick = () => {
      if (!raf) raf = requestAnimationFrame(tick);
    };
    const move = (e: PointerEvent) => {
      target = (e.clientX / window.innerWidth) * 100;
      kick();
    };
    const leave = () => {
      target = 30;
      kick();
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerleave", leave);
    return () => {
      cancelAnimationFrame(raf);
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerleave", leave);
    };
  }, [pathname]);

  if (pathname.startsWith("/studio") || pathname.startsWith("/admin")) return null;

  // transparent over the full-screen openings of the home and campaign pages
  const overHero = (pathname === "/" || pathname === "/campaign") && !scrolled && !menu;
  const step = (d: number) => setNote((n) => (n + d + notes.length) % notes.length);

  return (
    <header ref={glass} className={styles.header} data-site-header data-hidden={hidden && !menu} data-solid={!overHero}>
      <span className={styles.glint} aria-hidden />
      <span className={styles.prism} aria-hidden />
      <span className={styles.rim} aria-hidden />
      <div className={styles.announce}>
        <button type="button" className={styles.arrow} onClick={() => step(-1)} aria-label="Previous announcement">
          ‹
        </button>
        <p className={styles.note} aria-live="polite">
          <span key={note}>{notes[note]}</span>
        </p>
        <button type="button" className={styles.arrow} onClick={() => step(1)} aria-label="Next announcement">
          ›
        </button>
      </div>

      <div className={styles.bar}>
        <nav aria-label="Main" className={styles.nav}>
          {nav.map((n) => (
            <Link key={n.href} href={n.href} aria-current={isCurrent(pathname, n.href) ? "page" : undefined}>
              {n.label}
            </Link>
          ))}
        </nav>
        <button
          type="button"
          className={styles.menuButton}
          aria-expanded={menu}
          aria-controls="site-menu"
          onClick={() => setMenu((m) => !m)}
        >
          <span className={styles.burger} data-open={menu} aria-hidden />
          <span className={styles.srOnly}>{menu ? "Close menu" : "Menu"}</span>
        </button>

        <Link href="/" className={styles.brand} aria-label={`${site.label} — home`}>
          {flags.showProposedMark && <NoonMark className={styles.mark} title="Proposed mark" />}
          <span>{site.wordmark}</span>
        </Link>

        <div className={styles.actions}>
          <span className={styles.locale}>PK / PKR</span>
          <Link
            href="/bag"
            className={styles.bag}
            aria-label={`Bag, ${count} ${count === 1 ? "item" : "items"}`}
            aria-current={pathname === "/bag" ? "page" : undefined}
            aria-haspopup="dialog"
            onClick={(e) => {
              if (pathname === "/bag" || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
              e.preventDefault();
              bagDrawer.open();
            }}
          >
            <svg viewBox="0 0 24 24" aria-hidden className={styles.bagIcon}>
              <path d="M6 8h12l-1 12H7L6 8Z" />
              <path d="M9 8V6a3 3 0 0 1 6 0v2" />
            </svg>
            <span className={styles.count} data-filled={count > 0} aria-hidden>
              {count}
            </span>
          </Link>
        </div>
      </div>

      <div id="site-menu" className={styles.menu} data-open={menu} hidden={!menu}>
        <nav aria-label="Menu" className={styles.menuNav}>
          {nav.map((n) => (
            <Link key={n.href} href={n.href} onClick={() => setMenu(false)}>
              {n.label}
            </Link>
          ))}
        </nav>
        <nav aria-label="Help" className={styles.menuSub}>
          {menuExtra.map((n) => (
            <Link key={n.href} href={n.href} onClick={() => setMenu(false)}>
              {n.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}

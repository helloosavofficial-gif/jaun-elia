"use client";

import { useEffect, useState } from "react";

/**
 * The cover's dateline: the current time in Pakistan, so "After Dark" is
 * literal once the evening comes. Filled in after mount (the server has no
 * visitor clock), updated every 15 seconds.
 */
export function CoverClock({ label, className }: { label: string; className?: string }) {
  const [time, setTime] = useState<string | null>(null);

  useEffect(() => {
    const fmt = new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Karachi", hour: "numeric", minute: "2-digit" });
    const tick = () => setTime(fmt.format(new Date()));
    tick();
    const id = window.setInterval(tick, 15000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <p className={className} aria-label={time ? `${time} in ${label}` : undefined}>
      <span>{label}</span>
      <span aria-hidden>·</span>
      <time aria-hidden>{time ?? "--:--"}</time>
    </p>
  );
}

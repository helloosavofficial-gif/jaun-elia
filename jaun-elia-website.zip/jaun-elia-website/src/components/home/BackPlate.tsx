import Image from "next/image";
import styles from "./BackPlate.module.css";

type Mark = { label: string; body: string; at: number };

type Props = {
  image: { src: string; width: number; height: number; alt: string };
  marks: Mark[];
  caption: string;
  className?: string;
};

/**
 * The back of the hoodie as an annotated plate: leader lines run from notes in
 * the margin to each part of the artwork, as commentary sits beside the text
 * in a manuscript. On narrow screens the notes become a numbered list under
 * the image, keyed to small numbers pinned on it.
 */
export function BackPlate({ image, marks, caption, className }: Props) {
  return (
    <figure className={`${styles.plate} ${className ?? ""}`}>
      <div className={styles.frame}>
        {/* pins are placed against the artwork alone, not the notes listed under it */}
        <div className={styles.art}>
          <Image
            src={image.src}
            width={image.width}
            height={image.height}
            alt={image.alt}
            sizes="(max-width: 1279px) 80vw, 420px"
            className={styles.image}
          />
          <span className={styles.pins} aria-hidden>
            {marks.map((m, i) => (
              <span key={m.label} className={styles.pin} style={{ "--at": m.at } as React.CSSProperties}>
                {i + 1}
              </span>
            ))}
          </span>
        </div>
        <ol className={styles.marks}>
          {marks.map((m, i) => (
            <li key={m.label} className={styles.mark} style={{ "--at": m.at } as React.CSSProperties}>
              <span className={styles.no} aria-hidden>
                {i + 1}
              </span>
              <span className={styles.text}>
                <span className={styles.label}>{m.label}</span>
                {m.body}
              </span>
              <span className={styles.leader} aria-hidden />
            </li>
          ))}
        </ol>
      </div>
      <figcaption className={styles.caption}>{caption}</figcaption>
    </figure>
  );
}

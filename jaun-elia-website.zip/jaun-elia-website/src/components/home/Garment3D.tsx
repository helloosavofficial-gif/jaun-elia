"use client";

import Image from "next/image";
import { useEffect, useRef } from "react";
import { prefersCalmerMotion } from "@/lib/motion";
import styles from "./Garment3D.module.css";

type Props = {
  /** A cut-out garment (transparent background). */
  src: string;
  width: number;
  height: number;
  alt: string;
  sizes: string;
  /** Offsets the idle float so two garments side by side don't bob in step. */
  phase?: number;
  className?: string;
};

const MAX_TILT = 9; // degrees

/**
 * A cut-out garment staged as an object: lit from behind, floating over its
 * own floor shadow, turning slightly toward the pointer in perspective, with a
 * sheen (masked to the garment's silhouette) that slides as it turns.
 * Tilt eases toward the pointer each frame and settles back on leave; the
 * float and tilt are dropped for visitors who ask for less motion.
 */
export function Garment3D({ src, width, height, alt, sizes, phase = 0, className }: Props) {
  const stage = useRef<HTMLDivElement>(null);

  // the idle float only runs while the garment is on screen
  useEffect(() => {
    const el = stage.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(([e]) => el.toggleAttribute("data-offscreen", !e.isIntersecting), {
      rootMargin: "120px 0px",
    });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    const el = stage.current;
    if (!el || prefersCalmerMotion() || !window.matchMedia("(pointer: fine)").matches) return;

    let target = { x: 0, y: 0 };
    const now = { x: 0, y: 0 };
    let raf = 0;

    const tick = () => {
      now.x += (target.x - now.x) * 0.08;
      now.y += (target.y - now.y) * 0.08;
      el.style.setProperty("--ry", `${(now.x * MAX_TILT).toFixed(3)}deg`);
      el.style.setProperty("--rx", `${(-now.y * MAX_TILT * 0.6).toFixed(3)}deg`);
      el.style.setProperty("--sheen", `${(50 + now.x * 38).toFixed(2)}%`);
      raf = Math.abs(target.x - now.x) + Math.abs(target.y - now.y) > 0.001 ? requestAnimationFrame(tick) : 0;
    };
    const kick = () => {
      if (!raf) raf = requestAnimationFrame(tick);
    };
    const move = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      target = {
        x: Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width) * 2 - 1)),
        y: Math.max(-1, Math.min(1, ((e.clientY - r.top) / r.height) * 2 - 1)),
      };
      kick();
    };
    const leave = () => {
      target = { x: 0, y: 0 };
      kick();
    };

    el.addEventListener("pointermove", move);
    el.addEventListener("pointerleave", leave);
    return () => {
      cancelAnimationFrame(raf);
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerleave", leave);
    };
  }, []);

  return (
    <div
      ref={stage}
      className={`${styles.stage} ${className ?? ""}`}
      style={{ ["--phase" as string]: `${phase}s`, ["--mask" as string]: `url(${src})` }}
    >
      <span className={styles.light} aria-hidden />
      <div className={styles.float}>
        <div className={styles.tilt}>
          <Image src={src} width={width} height={height} alt={alt} sizes={sizes} className={styles.img} />
          <span className={styles.sheen} aria-hidden />
        </div>
      </div>
      <span className={styles.floor} aria-hidden />
    </div>
  );
}

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { PENDING } from "@/content/products";
import { bagDrawer, formatPrice, useBag, useBagDrawer } from "@/lib/bag";
import { lockScroll, unlockScroll } from "@/lib/scroll";
import { BagLines } from "./BagLines";
import styles from "./BagDrawer.module.css";

const CLOSE_MS = 450;

/**
 * The slide-out bag. A native modal <dialog>, so focus is held inside while
 * open, Escape closes it, the page behind is inert, and focus returns to the
 * Bag button afterwards. Opened by the header's Bag button and by Add to bag;
 * closes on Escape, the close button, a click outside, or navigating away.
 */
export function BagDrawer() {
  const open = useBagDrawer();
  const pathname = usePathname();
  const { items, count, subtotal, currency } = useBag();
  const dialog = useRef<HTMLDialogElement>(null);
  const [state, setState] = useState<"closed" | "opening" | "open" | "closing">("closed");

  // open / close the dialog, with the slide played around it
  useEffect(() => {
    const d = dialog.current;
    if (!d) return;
    if (open && !d.open) {
      d.showModal();
      lockScroll();
      setState("opening");
      // start the slide on the next frame; the timer covers throttled (background) tabs
      const show = () => setState((s) => (s === "opening" ? "open" : s));
      const raf = requestAnimationFrame(() => requestAnimationFrame(show));
      const t = window.setTimeout(show, 60);
      return () => {
        cancelAnimationFrame(raf);
        window.clearTimeout(t);
      };
    }
    if (open && d.open) {
      setState("open"); // reopened while still sliding shut
      return;
    }
    if (!open && d.open) {
      setState("closing");
      const t = window.setTimeout(() => {
        d.close();
        unlockScroll();
        setState("closed");
      }, CLOSE_MS);
      return () => window.clearTimeout(t);
    }
  }, [open]);

  // leaving the page closes the bag
  useEffect(() => bagDrawer.close(), [pathname]);

  // never leave the page locked if this unmounts while open
  useEffect(() => () => unlockScroll(), []);

  return (
    <dialog
      ref={dialog}
      className={styles.dialog}
      data-state={state}
      aria-labelledby="bag-drawer-title"
      onCancel={(e) => {
        e.preventDefault(); // Escape: close with the slide instead of instantly
        bagDrawer.close();
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) bagDrawer.close(); // the backdrop
      }}
    >
      <div className={styles.panel}>
        <header className={styles.head}>
          <h2 id="bag-drawer-title" className={styles.title}>
            Bag <span className={styles.count}>({count})</span>
          </h2>
          <button type="button" className={styles.close} onClick={() => bagDrawer.close()} aria-label="Close bag">
            Close
          </button>
        </header>

        {items.length === 0 ? (
          <div className={styles.empty}>
            <p>Your bag is empty.</p>
            <Link href="/shop" className={styles.primary} onClick={() => bagDrawer.close()}>
              Go to the shop
            </Link>
          </div>
        ) : (
          <>
            <div className={styles.scroll} data-lenis-prevent>
              <BagLines compact onNavigate={() => bagDrawer.close()} />
            </div>
            <footer className={styles.foot}>
              <dl className={styles.totals}>
                <div>
                  <dt>Subtotal</dt>
                  <dd>{formatPrice(subtotal, currency)}</dd>
                </div>
                <div>
                  <dt>Shipping</dt>
                  <dd>{PENDING}</dd>
                </div>
              </dl>
              <Link href="/checkout" className={styles.primary}>
                Checkout
              </Link>
              <Link href="/bag" className={styles.secondary}>
                View bag
              </Link>
              <p className={styles.notice}>Saved in this browser. Cash on delivery at checkout.</p>
            </footer>
          </>
        )}
      </div>
    </dialog>
  );
}

"use client";

import Image from "next/image";
import Link from "next/link";
import { MAX_QTY_PER_LINE } from "@/content/products";
import { bag, formatPrice, useBag } from "@/lib/bag";
import styles from "./BagLines.module.css";

type Props = {
  /** Smaller layout for the slide-out drawer. */
  compact?: boolean;
  /** Quantities shown but not editable (checkout summary). */
  readOnly?: boolean;
  /** Called when a product link is followed (the drawer closes itself). */
  onNavigate?: () => void;
};

/** The bag's lines, shared by the drawer, the bag page and checkout. */
export function BagLines({ compact, readOnly, onNavigate }: Props) {
  const { items } = useBag();

  return (
    <ul className={styles.lines} data-compact={compact ?? false} aria-label="Items in your bag">
      {items.map((item) => {
        const label = `${item.product.name}, size ${item.size}`;
        return (
          <li key={`${item.productId}-${item.size}`} className={styles.line} data-readonly={readOnly ?? false}>
            <div className={styles.thumb}>
              <Image src={item.product.images.front.src} alt="" fill sizes="96px" />
            </div>
            <div className={styles.info}>
              <p className={styles.name}>
                <Link href={`/shop/${item.product.slug}`} onClick={onNavigate}>
                  {item.product.name}
                </Link>
              </p>
              <p className={styles.meta}>
                {item.product.colour} · Size {item.size}
              </p>
              <p className={styles.meta}>
                {formatPrice(item.product.price, item.product.currency)} each
                {readOnly ? ` · Qty ${item.qty}` : ""}
              </p>
            </div>
            {!readOnly && (
              <div className={styles.qty} role="group" aria-label={`Quantity for ${label}`}>
                <button
                  type="button"
                  onClick={() => bag.setQty(item.productId, item.size, item.qty - 1)}
                  aria-label={item.qty === 1 ? `Remove ${label}` : `Decrease quantity of ${label}`}
                >
                  −
                </button>
                <output aria-live="polite">{item.qty}</output>
                <button
                  type="button"
                  onClick={() => bag.setQty(item.productId, item.size, item.qty + 1)}
                  disabled={item.qty >= MAX_QTY_PER_LINE}
                  aria-label={`Increase quantity of ${label}`}
                >
                  +
                </button>
              </div>
            )}
            <p className={styles.lineTotal}>{formatPrice(item.lineTotal, item.product.currency)}</p>
            {!readOnly && (
              <button
                type="button"
                className={styles.remove}
                onClick={() => bag.remove(item.productId, item.size)}
                aria-label={`Remove ${label}`}
              >
                Remove
              </button>
            )}
          </li>
        );
      })}
    </ul>
  );
}

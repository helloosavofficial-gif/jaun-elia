"use client";

import Link from "next/link";
import { PENDING } from "@/content/products";
import { formatPrice, useBag } from "@/lib/bag";
import { useMounted } from "@/lib/useMounted";
import { BagLines } from "./BagLines";
import styles from "./BagView.module.css";

/**
 * The bag page: lines, summary, the empty state and the way to checkout.
 * The bag lives in the browser; checkout sends it to /api/orders.
 */
export function BagView() {
  const { items, count, subtotal, currency } = useBag();
  // the saved bag is only readable in the browser; avoid flashing "empty" before it loads
  const mounted = useMounted();

  if (!mounted) return <p className={styles.loading}>Loading your bag…</p>;

  if (items.length === 0) {
    return (
      <div className={styles.empty}>
        <p>Your bag is empty.</p>
        <Link href="/shop" className={styles.primary}>
          Go to the shop
        </Link>
      </div>
    );
  }

  return (
    <div className={styles.layout}>
      <BagLines />

      <aside className={styles.summary} aria-label="Summary">
        <dl>
          <div>
            <dt>Items</dt>
            <dd>{count}</dd>
          </div>
          <div>
            <dt>Subtotal</dt>
            <dd>{formatPrice(subtotal, currency)}</dd>
          </div>
          <div>
            <dt>Shipping</dt>
            <dd>{PENDING}</dd>
          </div>
        </dl>
        <Link href="/checkout" className={styles.primary}>
          Checkout
        </Link>
        <p className={styles.notice}>
          Pay with cash on delivery. Your bag is saved in this browser; pieces are reserved only once you place your
          order.
        </p>
        <Link href="/shop" className={styles.secondary}>
          Continue shopping
        </Link>
      </aside>
    </div>
  );
}

import Link from "next/link";
import { PENDING, type Product } from "@/content/products";
import { store } from "@/content/store";
import { SizeTable } from "./SizeTable";
import styles from "./ProductDetails.module.css";

const orPending = (v: string | null | undefined) => v ?? PENDING;

/**
 * Description, size guide, details, care, and shipping & returns, as native
 * disclosure sections (keyboard and screen-reader friendly without script).
 * Every unconfirmed value shows PENDING rather than a guess; fill them in
 * content/products.ts and content/store.ts.
 */
export function ProductDetails({ product, className }: { product: Product; className?: string }) {
  const rows: [string, string][] = [
    ["Colour", product.colour],
    ["Finish", product.finish],
    ["Fabric", orPending(product.details.fabric)],
    ["Weight", orPending(product.details.weight)],
    ["Fit", orPending(product.details.fit)],
    ["Made in", orPending(product.details.madeIn)],
  ];

  return (
    <div className={`${styles.details} ${className ?? ""}`}>
      <details open>
        <summary>Description</summary>
        <div className={styles.body}>
          <p>{product.description}</p>
        </div>
      </details>

      <details id="size-guide">
        <summary>Size guide</summary>
        <div className={styles.body}>
          <SizeTable product={product} />
          <p className={styles.muted}>
            <Link href="/size-guide">Full size guide</Link>
          </p>
        </div>
      </details>

      <details>
        <summary>Product details</summary>
        <div className={styles.body}>
          <dl className={styles.rows}>
            {rows.map(([k, v]) => (
              <div key={k}>
                <dt>{k}</dt>
                <dd data-pending={v === PENDING}>{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </details>

      <details>
        <summary>Care</summary>
        <div className={styles.body}>
          {product.care ? (
            <ul>
              {product.care.map((c) => (
                <li key={c}>{c}</li>
              ))}
            </ul>
          ) : (
            <p>Care instructions: {PENDING.toLowerCase()}.</p>
          )}
        </div>
      </details>

      <details>
        <summary>Shipping &amp; returns</summary>
        <div className={styles.body}>
          <dl className={styles.rows}>
            <div>
              <dt>Delivers to</dt>
              <dd data-pending={!store.shipping.regions}>{orPending(store.shipping.regions)}</dd>
            </div>
            <div>
              <dt>Shipping cost</dt>
              <dd data-pending={!store.shipping.cost}>{orPending(store.shipping.cost)}</dd>
            </div>
            <div>
              <dt>Delivery time</dt>
              <dd data-pending={!store.shipping.deliveryTime}>{orPending(store.shipping.deliveryTime)}</dd>
            </div>
            <div>
              <dt>Returns</dt>
              <dd data-pending={!store.returns.policy}>{orPending(store.returns.policy)}</dd>
            </div>
          </dl>
          <p className={styles.muted}>
            <Link href="/shipping-returns">Shipping &amp; returns</Link>
          </p>
        </div>
      </details>
    </div>
  );
}

import { PENDING, type Product } from "@/content/products";
import styles from "./SizeTable.module.css";

/**
 * Garment measurements per size, from content/products.ts. Until the client
 * supplies them, says so instead of showing a table of guesses.
 */
export function SizeTable({ product }: { product: Product }) {
  const keys = product.measurements
    ? Array.from(new Set(Object.values(product.measurements).flatMap((m) => Object.keys(m))))
    : [];

  return (
    <div className={styles.wrap}>
      {product.measurements ? (
        <div className={styles.scroll}>
          <table className={styles.table}>
            <caption className={styles.caption}>Garment measurements</caption>
            <thead>
              <tr>
                <th scope="col">Size</th>
                {keys.map((k) => (
                  <th key={k} scope="col">
                    {k}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {product.sizes.map((size) => (
                <tr key={size}>
                  <th scope="row">{size}</th>
                  {keys.map((k) => (
                    <td key={k}>{product.measurements?.[size]?.[k] ?? "—"}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p>Measurements: {PENDING.toLowerCase()}.</p>
      )}
      <p className={styles.muted}>
        Sizes: {product.sizes.join(", ")}
        {product.sizesConfirmed ? "" : ` (size run ${PENDING.toLowerCase()})`}.
      </p>
    </div>
  );
}

"use client";

import dynamic from "next/dynamic";
import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { site } from "@/content/site";
import { RotationViewer } from "@/components/shop/RotationViewer";
import { ErrorBoundary } from "@/components/viewer/ErrorBoundary";
import { hasWebGL, modelExists } from "@/components/viewer/support";
import styles from "./ProductViewer.module.css";

// three.js only loads when a real model file is actually served
const ModelViewer = dynamic(() => import("@/components/viewer/ModelViewer").then((m) => m.ModelViewer), {
  ssr: false,
});

type ViewId = "turn" | "front" | "back" | "detail";

const MOCKUP_NOTE = "Design mockup · not a photograph of the final garment";

const g = site.garment;
const m = site.media;
const stills = {
  front: { ...g.front, alt: "Front of the hoodie: Jaun Elia's name in Urdu calligraphy on the left chest (design mockup)" },
  back: { ...g.back, alt: "Back of the hoodie: the name in large calligraphy above a verse (design mockup)" },
};
const details = [
  { id: "chest", label: "Chest", ...m.frontChest, alt: "Close-up of the chest calligraphy and drawcords (design mockup)" },
  { id: "drawcord", label: "Drawcords", ...m.drawcord, alt: "Close-up of the drawcords and eyelets (design mockup)" },
  { id: "cuff", label: "Cuff", ...m.cuff, alt: "Close-up of the ribbed cuff (design mockup)" },
];

const VIEWS: { id: ViewId; label: string }[] = [
  { id: "front", label: "Front" },
  { id: "back", label: "Back" },
  { id: "detail", label: "Detail" },
  { id: "turn", label: "360°" },
];

/**
 * The product page's garment gallery: Front, Back, Detail and 360°.
 *
 * Opens on Front. The 360° view mounts only when first chosen (so its frames
 * and the 3D-model check cost nothing until then) and stays mounted after.
 * It uses a real 3D model when one is served at site.garment.modelUrl and
 * WebGL works; otherwise the concept-render rotation, labelled as such.
 * Front, Back and Detail are the client's design mockups (the real artwork),
 * labelled as mockups. Still images zoom on click or Enter.
 */
export function ProductViewer({ className }: { className?: string }) {
  const [view, setView] = useState<ViewId>("front");
  const [turnMounted, setTurnMounted] = useState(false);
  const [model, setModel] = useState(false);
  const [detail, setDetail] = useState(0);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);

  // the 3D-model check only runs once the 360° view is wanted
  useEffect(() => {
    if (!turnMounted) return;
    let alive = true;
    (async () => {
      const ok = hasWebGL() && (await modelExists(g.modelUrl));
      if (alive) setModel(ok);
    })();
    return () => {
      alive = false;
    };
  }, [turnMounted]);

  // the 360° panel mounts on first selection and then stays mounted (frames load once)
  const select = (id: ViewId) => {
    if (id === "turn") setTurnMounted(true);
    setView(id);
  };

  // deep links: ?view=360 (or back / detail) opens on that view
  useEffect(() => {
    const asked = new URLSearchParams(window.location.search).get("view");
    const id = asked === "360" ? "turn" : VIEWS.find((v) => v.id === asked)?.id;
    if (id && id !== "front") select(id);
  }, []);

  const onTabKey = (e: React.KeyboardEvent, i: number) => {
    const step = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : 0;
    const to = e.key === "Home" ? 0 : e.key === "End" ? VIEWS.length - 1 : step ? (i + step + VIEWS.length) % VIEWS.length : -1;
    if (to < 0) return;
    e.preventDefault();
    select(VIEWS[to].id);
    tabs.current[to]?.focus();
  };

  const rotation = <RotationViewer className={styles.rotation} />;

  return (
    <div className={`${styles.viewer} ${className ?? ""}`}>
      <div className={styles.stage}>
        <div id="view-turn" role="tabpanel" aria-labelledby="tab-turn" className={styles.panel} hidden={view !== "turn"}>
          {!turnMounted ? null : model ? (
            <ErrorBoundary fallback={rotation} onError={() => setModel(false)}>
              <div className={styles.model}>
                <ModelViewer url={g.modelUrl} side="front" zoom={1} resetToken={0} onSideChange={() => {}} />
              </div>
              <p className={styles.note}>Interactive 3D model · drag to turn</p>
            </ErrorBoundary>
          ) : (
            rotation
          )}
        </div>

        {(["front", "back"] as const).map((side) => (
          <div
            key={side}
            id={`view-${side}`}
            role="tabpanel"
            aria-labelledby={`tab-${side}`}
            className={styles.panel}
            hidden={view !== side}
          >
            {/* Front is the opening view, so it loads first */}
            <Still {...stills[side]} sizes="(max-width: 899px) 90vw, 46vw" priority={side === "front"} />
            <p className={styles.note}>{MOCKUP_NOTE}</p>
          </div>
        ))}

        <div id="view-detail" role="tabpanel" aria-labelledby="tab-detail" className={styles.panel} hidden={view !== "detail"}>
          <Still key={details[detail].id} {...details[detail]} sizes="(max-width: 899px) 90vw, 46vw" />
          <div className={styles.detailPicker} role="group" aria-label="Detail">
            {details.map((d, i) => (
              <button
                key={d.id}
                type="button"
                className={styles.detailThumb}
                aria-pressed={detail === i}
                aria-label={d.label}
                onClick={() => setDetail(i)}
              >
                <Image src={d.src} alt="" width={72} height={72} />
              </button>
            ))}
          </div>
          <p className={styles.note}>{MOCKUP_NOTE}</p>
        </div>
      </div>

      <div className={styles.tabs} role="tablist" aria-label="Views of the hoodie">
        {VIEWS.map((v, i) => (
          <button
            key={v.id}
            ref={(el) => {
              tabs.current[i] = el;
            }}
            id={`tab-${v.id}`}
            type="button"
            role="tab"
            aria-selected={view === v.id}
            aria-controls={`view-${v.id}`}
            tabIndex={view === v.id ? 0 : -1}
            className={styles.tab}
            onClick={() => select(v.id)}
            onKeyDown={(e) => onTabKey(e, i)}
          >
            {v.label}
          </button>
        ))}
      </div>
    </div>
  );
}

/** A still that zooms to 2× where you click, and follows the pointer while zoomed. */
function Still({ src, width, height, alt, sizes, priority }: { src: string; width: number; height: number; alt: string; sizes: string; priority?: boolean }) {
  const [zoomed, setZoomed] = useState(false);
  const [origin, setOrigin] = useState("50% 50%");

  const aim = (e: React.PointerEvent | React.MouseEvent) => {
    const r = e.currentTarget.getBoundingClientRect();
    setOrigin(`${((e.clientX - r.left) / r.width) * 100}% ${((e.clientY - r.top) / r.height) * 100}%`);
  };

  return (
    <button
      type="button"
      className={styles.still}
      style={{ aspectRatio: `${width} / ${height}` }}
      aria-pressed={zoomed}
      aria-label={zoomed ? "Zoom out" : "Zoom in"}
      data-zoomed={zoomed}
      onClick={(e) => {
        if (e.detail > 0) aim(e); // keyboard presses zoom to the centre
        else setOrigin("50% 50%");
        setZoomed((z) => !z);
      }}
      onPointerMove={(e) => zoomed && e.pointerType === "mouse" && aim(e)}
      onKeyDown={(e) => e.key === "Escape" && setZoomed(false)}
    >
      <Image
        src={src}
        alt={alt}
        fill
        sizes={sizes}
        priority={priority}
        // hidden views never enter the viewport, so lazy loading would wait for the click
        loading={priority ? undefined : "eager"}
        fetchPriority={priority ? undefined : "low"}
        style={{ transformOrigin: origin }}
        className={styles.stillImage}
      />
    </button>
  );
}

import Link from "next/link";
import { createElement, type ElementType, type ReactNode } from "react";
import { ReadingColumn } from "./ReadingColumn";
import styles from "./diwan.module.css";

/* ── Section ──────────────────────────────────────────────────────────── */

type SectionProps = {
  children: ReactNode;
  /** paper (light, the default surface) or ink (cinematic moments). */
  tone?: "paper" | "ink";
  /**
   * manuscript: a reading column with margins either side for MarginNotes ·
   * wide: full width inside the page margins · bleed: edge to edge
   */
  layout?: "manuscript" | "wide" | "bleed";
  pad?: "lg" | "md" | "none";
  as?: ElementType;
  id?: string;
  className?: string;
  "aria-labelledby"?: string;
  "aria-label"?: string;
};

/** A page of the diwan: sets the surface (paper or ink) and the grid. */
export function Section({ children, tone = "paper", layout = "wide", pad = "lg", as = "section", className, ...rest }: SectionProps) {
  return createElement(
    as,
    {
      ...rest,
      className: `${styles.section} ${className ?? ""}`,
      "data-tone": tone,
      "data-layout": layout,
      "data-pad": pad,
    },
    children,
  );
}

/* ── Eyebrow ──────────────────────────────────────────────────────────── */

/** Small uppercase label above a headline, optionally led by the Reading Column's dots. */
export function Eyebrow({ children, marker = false, className }: { children: ReactNode; marker?: boolean; className?: string }) {
  return (
    <p className={`${styles.eyebrow} ${className ?? ""}`}>
      {marker && <ReadingColumn variant="marker" orientation="horizontal" />}
      {children}
    </p>
  );
}

/* ── Margin note (hashiya) ────────────────────────────────────────────── */

type NoteProps = {
  children: ReactNode;
  label?: string;
  /** Which margin it sits in on wide screens (inside a manuscript Section). Inline on phones. */
  side?: "start" | "end";
  className?: string;
};

/**
 * A note in the margin, as commentary sits beside the text in Urdu and
 * Persian manuscripts. Captions, product facts and honesty notes go here —
 * beside the image or text they belong to, never on top of it.
 */
export function MarginNote({ children, label, side = "end", className }: NoteProps) {
  return (
    <aside className={`${styles.note} ${className ?? ""}`} data-side={side}>
      <span className={styles.noteMark}>
        <ReadingColumn variant="marker" />
      </span>
      <span>
        {label && <span className={styles.noteLabel}>{label}</span>}
        {children}
      </span>
    </aside>
  );
}

/* ── Button ───────────────────────────────────────────────────────────── */

type ButtonBase = {
  children: ReactNode;
  variant?: "primary" | "secondary" | "quiet";
  size?: "md" | "lg";
  /** Full width (buy panel, bag). */
  block?: boolean;
  /** Trailing arrow that nudges forward on hover. */
  arrow?: boolean;
  className?: string;
};

type ButtonAsLink = ButtonBase & { href: string; onClick?: never; type?: never; disabled?: never };
type ButtonAsButton = ButtonBase & {
  href?: undefined;
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
};

/**
 * The house button. Primary inverts the surface (ink on paper, paper on ink);
 * feedback is near-instant (--dur-ui) — shopping never waits on decoration.
 */
export function Button(props: ButtonAsLink | ButtonAsButton) {
  const { children, variant = "primary", size = "md", block, arrow, className } = props;
  const cls = `${styles.button} ${styles[variant]} ${className ?? ""}`;
  const data = { "data-size": size, "data-block": block ? "" : undefined };
  const inner = (
    <>
      <span>{children}</span>
      {arrow && (
        <span className={styles.arrow} aria-hidden>
          →
        </span>
      )}
    </>
  );
  if (props.href !== undefined) {
    return (
      <Link href={props.href} className={cls} {...data}>
        {inner}
      </Link>
    );
  }
  return (
    <button type={props.type ?? "button"} className={cls} onClick={props.onClick} disabled={props.disabled} {...data}>
      {inner}
    </button>
  );
}

/* ── Text link ────────────────────────────────────────────────────────── */

/** An inline link with a quiet rule that inks in fully on hover. */
export function TextLink({ href, children, arrow = false, className }: { href: string; children: ReactNode; arrow?: boolean; className?: string }) {
  return (
    <Link href={href} className={`${styles.link} ${className ?? ""}`}>
      <span>{children}</span>
      {arrow && (
        <span className={styles.arrow} aria-hidden>
          →
        </span>
      )}
    </Link>
  );
}

/**
 * Diwan — the site's design system. Tokens live in app/globals.css
 * (--paper, --ink-deep, --lamp, --step-*, --space-*, --dur-*, --ease-*).
 * Preview everything at /diwan in development.
 */
export { Section, Eyebrow, MarginNote, Button, TextLink } from "./Primitives";
export { Couplet } from "./Couplet";
export { ReadingColumn } from "./ReadingColumn";
export { Reveal, revealOnView, type RevealVariant } from "./Reveal";

"use client";

import { useEffect, useRef, useState } from "react";
import styles from "./diwan.module.css";

type Variant = "divider" | "marker" | "progress" | "loader";

type Props = {
  /**
   * divider: three dots and a hairline, between sections or beside text ·
   * marker: just the dots (bullets, active states) ·
   * progress: the hairline fills and the dots light up with scroll ·
   * loader: the dots ink in and the line draws, on a loop
   */
  variant?: Variant;
  orientation?: "vertical" | "horizontal";
  /** Hairline length, any CSS length. */
  length?: string;
  /** progress only: fixed rail at the page edge, tracking the whole page. */
  rail?: boolean;
  /** progress only: track this element's pass through the viewport instead of the page. */
  target?: React.RefObject<HTMLElement | null>;
  /** Accessible name; decorative (hidden) when omitted. Loaders get "Loading". */
  label?: string;
  className?: string;
};

/**
 * The Reading Column — three dots over a hairline, from the back of the
 * hoodie, where it leads the eye from the name down through the verse.
 * The brand's signature device.
 */
export function ReadingColumn({
  variant = "divider",
  orientation = "vertical",
  length,
  rail = false,
  target,
  label,
  className,
}: Props) {
  const root = useRef<HTMLSpanElement>(null);
  const [lit, setLit] = useState(0);

  useEffect(() => {
    if (variant !== "progress") return;
    const el = root.current;
    if (!el) return;
    let raf = 0;
    const measure = () => {
      raf = 0;
      let p: number;
      const t = target?.current;
      if (t) {
        const r = t.getBoundingClientRect();
        p = (window.innerHeight - r.top) / (window.innerHeight + r.height);
      } else {
        const max = document.documentElement.scrollHeight - window.innerHeight;
        p = max > 0 ? window.scrollY / max : 0;
      }
      p = Math.min(1, Math.max(0, p));
      el.style.setProperty("--progress", p.toFixed(4));
      setLit(p >= 0.98 ? 3 : p >= 0.62 ? 2 : p >= 0.28 ? 1 : 0);
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(measure);
    };
    measure();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [variant, target]);

  const showHair = variant !== "marker";
  const a11y =
    variant === "loader"
      ? { role: "status", "aria-label": label ?? "Loading" }
      : label
        ? { role: "img", "aria-label": label }
        : { "aria-hidden": true };

  return (
    <span
      ref={root}
      className={`${styles.column} ${rail ? styles.rail : ""} ${className ?? ""}`}
      data-variant={variant}
      data-orientation={orientation}
      style={length ? ({ "--len": length } as React.CSSProperties) : undefined}
      {...a11y}
    >
      {[0, 1, 2].map((i) => (
        <i key={i} className={styles.dot} data-on={variant === "progress" ? i < lit : undefined} />
      ))}
      {showHair && (
        <span className={styles.hair}>
          <span className={styles.hairFill} />
        </span>
      )}
    </span>
  );
}

"use client";

import { createElement, useEffect, useRef } from "react";
import { revealOnView } from "./Reveal";
import styles from "./diwan.module.css";

type Props = {
  /** First line (misra-e-ula). */
  first: string;
  /** Second line (misra-e-sani) — set italic, answering the first. */
  second?: string;
  as?: "h1" | "h2" | "h3" | "p";
  size?: "display" | "title" | "heading";
  align?: "start" | "center";
  /** Lines rise out of their masks when the couplet scrolls into view. */
  reveal?: boolean;
  id?: string;
  className?: string;
};

/**
 * The house headline: two balanced lines, like the two halves of a sher.
 * Screen readers get the whole couplet as one heading.
 */
export function Couplet({ first, second, as = "h2", size = "title", align = "start", reveal = true, id, className }: Props) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => (reveal && ref.current ? revealOnView(ref.current) : undefined), [reveal]);

  const line = (text: string, i: number) => (
    <span key={i} className={`${styles.misra} ${i === 1 ? styles.misraSecond : ""}`} aria-hidden>
      <span
        data-diwan-reveal={reveal ? "line" : undefined}
        style={reveal && i ? ({ "--reveal-delay": "140ms" } as React.CSSProperties) : undefined}
      >
        {text}
      </span>
    </span>
  );

  return createElement(
    as,
    {
      ref,
      id,
      className: `${styles.couplet} ${className ?? ""}`,
      "data-size": size,
      "data-align": align,
      "aria-label": second ? `${first} ${second}` : first,
    },
    line(first, 0),
    second ? line(second, 1) : null,
  );
}

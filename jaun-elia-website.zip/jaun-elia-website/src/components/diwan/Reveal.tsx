"use client";

import { createElement, useEffect, useRef, type ElementType, type ReactNode } from "react";

export type RevealVariant = "ink" | "rise" | "line" | "fade";

/**
 * Marks `el` (and every [data-diwan-reveal] inside it) as shown the first
 * time it comes into view. Styles live in globals.css: content is visible by
 * default and only hidden once JS is confirmed, so nothing stays invisible
 * if scripts fail. Returns a cleanup.
 */
export function revealOnView(el: Element, { threshold = 0.18, margin = "0px 0px -8% 0px" } = {}) {
  const show = () => {
    if (el.hasAttribute("data-diwan-reveal")) el.setAttribute("data-shown", "");
    el.querySelectorAll("[data-diwan-reveal]").forEach((n) => n.setAttribute("data-shown", ""));
  };
  if (typeof IntersectionObserver === "undefined") {
    show();
    return () => {};
  }
  // Browsers measure an element after its own clip-path, so an "ink" reveal clipped to
  // nothing never counts as visible and would stay hidden for good. Watch its parent instead.
  const clipped = getComputedStyle(el).clipPath !== "none";
  const target = clipped && el.parentElement ? el.parentElement : el;
  const io = new IntersectionObserver(
    ([entry]) => {
      if (!entry.isIntersecting) return;
      show();
      io.disconnect();
    },
    { threshold: clipped ? Math.min(threshold, 0.1) : threshold, rootMargin: margin },
  );
  io.observe(target);
  return () => io.disconnect();
}

type RevealProps = {
  children: ReactNode;
  /** ink: drawn downward like a pen stroke · rise: settles up · line: rises out of a mask · fade */
  variant?: RevealVariant;
  /** Milliseconds before this one starts (for gentle sequences). */
  delay?: number;
  as?: ElementType;
  className?: string;
};

/** "Ink and page" entrance: reveals its content once, as it scrolls into view. */
export function Reveal({ children, variant = "rise", delay = 0, as = "div", className }: RevealProps) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => (ref.current ? revealOnView(ref.current) : undefined), []);
  return createElement(
    as,
    {
      ref,
      className,
      "data-diwan-reveal": variant,
      style: delay ? ({ "--reveal-delay": `${delay}ms` } as React.CSSProperties) : undefined,
    },
    children,
  );
}

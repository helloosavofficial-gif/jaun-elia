"use client";

import { useEffect, useRef, useState } from "react";
import { edition, fetchStock, formatCount, type Stock } from "@/content/edition";
import { prefersReduced } from "@/lib/motion";
import styles from "./StockCounter.module.css";

type Props = {
  /** compact: one line + bar (buy panel). large: the edition section. */
  variant?: "compact" | "large";
  /** Light background (ivory sections). */
  tone?: "dark" | "light";
  /** Typeface for the figures: the bold sans (default) or the display serif. */
  face?: "sans" | "serif";
  className?: string;
};

const DIGITS = "0123456789".split("");
/** Each column holds the digits three times, so it rolls two full turns before landing. */
const REEL = [...DIGITS, ...DIGITS, ...DIGITS];

/**
 * Pieces remaining from the edition, shown as rolling digits (an odometer)
 * that spin into place when the counter comes into view — pure CSS
 * transforms, so it stays smooth. Reads content/edition.ts (fetchStock),
 * which the backend replaces with live inventory.
 */
export function StockCounter({ variant = "compact", tone = "dark", face = "sans", className }: Props) {
  const [stock, setStock] = useState<Stock>({ total: edition.total, remaining: edition.remaining, live: edition.live });
  const [rolled, setRolled] = useState(false);
  const root = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let alive = true;
    fetchStock().then((s) => alive && setStock(s));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    const el = root.current;
    if (!el) return;
    if (prefersReduced()) {
      setRolled(true);
      return;
    }
    const io = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return;
        io.disconnect();
        // next frame, so the starting position paints before the roll
        requestAnimationFrame(() => requestAnimationFrame(() => setRolled(true)));
      },
      { threshold: 0.5 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const text = formatCount(stock.remaining);
  const pct = stock.total ? stock.remaining / stock.total : 0;
  let col = 0;

  return (
    <div
      ref={root}
      className={`${styles.counter} ${className ?? ""}`}
      data-variant={variant}
      data-tone={tone}
      data-face={face}
      data-rolled={rolled}
      role="group"
      aria-label={`${text} of ${formatCount(stock.total)} pieces remaining`}
    >
      <div className={styles.figures} aria-hidden>
        <span className={styles.remaining}>
          {text.split("").map((ch, i) => {
            if (!/\d/.test(ch)) {
              return (
                <span key={i} className={styles.sep}>
                  {ch}
                </span>
              );
            }
            const n = Number(ch);
            const order = col++;
            return (
              <span key={i} className={styles.digit}>
                <span
                  className={styles.reel}
                  style={{
                    transform: `translateY(${rolled ? (-(20 + n) * 100) / REEL.length : 0}%)`,
                    transitionDelay: `${order * 0.12}s`,
                  }}
                >
                  {REEL.map((d, k) => (
                    <span key={k}>{d}</span>
                  ))}
                </span>
              </span>
            );
          })}
        </span>
        <span className={styles.total}>/ {formatCount(stock.total)}</span>
      </div>
      <div className={styles.labels} aria-hidden>
        <span>Pieces remaining</span>
        <span className={styles.status}>
          <i className={styles.dot} data-live={stock.live} />
          {stock.live ? "Live count" : "Before launch"}
        </span>
      </div>
      <span className={styles.track} aria-hidden>
        <span className={styles.bar} style={{ transform: `scaleX(${rolled ? pct : 0})` }} />
      </span>
    </div>
  );
}

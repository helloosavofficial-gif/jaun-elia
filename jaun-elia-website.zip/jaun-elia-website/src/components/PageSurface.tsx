"use client";

import { usePathname } from "next/navigation";
import { useLayoutEffect } from "react";

const TRANSPARENT = /rgba\([^)]*,\s*0\)|transparent/;

/** The colour a visitor will see behind the middle of the screen on the page that just mounted. */
function surfaceAt(x: number, y: number): string | null {
  // the fixed header or an open drawer can sit over the sample point; look underneath
  let el =
    (document.elementsFromPoint(x, y).find((e) => !e.closest("[data-site-header], dialog")) as HTMLElement | undefined) ??
    null;
  for (; el && el !== document.body && el !== document.documentElement; el = el.parentElement) {
    const cs = getComputedStyle(el);
    if (cs.backgroundColor && !TRANSPARENT.test(cs.backgroundColor)) return cs.backgroundColor;
    if (cs.backgroundImage.includes("gradient")) {
      // a vignette: use its outer colour (computed styles list colours as rgb())
      const stops = cs.backgroundImage.match(/rgba?\([^)]*\)/g);
      if (stops?.length) return stops[stops.length - 1];
    }
  }
  return null;
}

/**
 * Page changes fade the new page in (app/template.tsx). Underneath, the body
 * takes on the colour of the incoming page and eases there, so going from one
 * paper page to another never flashes ink, and ink → paper reads as a dissolve
 * rather than a cut. Sets --surface on <html>; globals.css does the easing.
 */
export function PageSurface() {
  const pathname = usePathname();

  useLayoutEffect(() => {
    const root = document.documentElement;
    const apply = () => {
      // the page's own paper or ink first; sample the screen only for pages built from full-bleed sections
      const main = document.getElementById("main");
      const own = main ? getComputedStyle(main).backgroundColor : "";
      const colour = own && !TRANSPARENT.test(own) ? own : surfaceAt(window.innerWidth / 2, window.innerHeight * 0.6);
      if (colour) root.style.setProperty("--surface", colour);
      else root.style.removeProperty("--surface");
    };
    apply();
    // the router restores or resets the scroll position just after this; sample again once it has
    const raf = requestAnimationFrame(apply);
    return () => cancelAnimationFrame(raf);
  }, [pathname]);

  return null;
}

"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import gsap from "gsap";
import { flags, site } from "@/content/site";
import { NoonMark } from "@/components/Marks";
import { prefersReduced } from "@/lib/motion";
import styles from "./Teaser.module.css";

type FormState = "idle" | "sending" | "done" | "error" | "offline";

const pad = (n: number) => String(Math.max(0, n)).padStart(2, "0");

/** Days / hours / minutes / seconds until `iso`, or null once it has passed. */
function remaining(iso: string) {
  const ms = new Date(iso).getTime() - Date.now();
  if (!Number.isFinite(ms) || ms <= 0) return null;
  const s = Math.floor(ms / 1000);
  return { d: Math.floor(s / 86400), h: Math.floor((s % 86400) / 3600), m: Math.floor((s % 3600) / 60), s: s % 60 };
}

/**
 * The pre-launch teaser: the hoodie turning in its studio, the name in large
 * type, a countdown (once a launch date is set) and a sign-up.
 * One screen, no scrolling story — the full campaign lives at /campaign.
 */
export function Teaser() {
  const root = useRef<HTMLDivElement>(null);
  const t = site.teaser;
  const launch = site.launch;
  const [clock, setClock] = useState<ReturnType<typeof remaining>>(null);
  const [form, setForm] = useState<FormState>("idle");
  const [email, setEmail] = useState("");

  // countdown
  useEffect(() => {
    if (!launch.date) return;
    const tick = () => setClock(remaining(launch.date!));
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, [launch.date]);

  // entrance, and the studio light following the pointer
  useEffect(() => {
    const el = root.current;
    if (!el) return;
    if (prefersReduced()) return;
    const q = gsap.utils.selector(el);
    const tl = gsap.timeline({ defaults: { ease: "expo.out" } });
    tl.fromTo(q("[data-t='stage']"), { opacity: 0, scale: 0.9 }, { opacity: 1, scale: 1, duration: 2.4 }, 0.1)
      .fromTo(q("[data-t='char']"), { yPercent: 110 }, { yPercent: 0, duration: 1.4, stagger: 0.05 }, 0.5)
      .fromTo(q("[data-t='fade']"), { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 1.2, stagger: 0.08 }, 1.0)
      .fromTo(q("[data-t='rule']"), { scaleX: 0 }, { scaleX: 1, duration: 1.4, ease: "power3.inOut" }, 0.8);

    const fine = window.matchMedia("(pointer: fine)").matches;
    const onMove = (e: PointerEvent) => {
      el.style.setProperty("--mx", `${(e.clientX / window.innerWidth) * 100}%`);
      el.style.setProperty("--my", `${(e.clientY / window.innerHeight) * 100}%`);
    };
    if (fine) window.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      tl.kill();
      window.removeEventListener("pointermove", onMove);
    };
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!launch.signupEndpoint) {
      setForm("offline");
      return;
    }
    setForm("sending");
    try {
      const res = await fetch(launch.signupEndpoint, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email }),
      });
      setForm(res.ok ? "done" : "error");
    } catch {
      setForm("error");
    }
  };

  const status: Record<FormState, string> = {
    idle: "",
    sending: "Sending…",
    done: "You're on the list. We'll write when it drops.",
    error: "That didn't go through. Please try again.",
    offline: "Sign-ups aren't connected yet. Please check back soon.",
  };

  return (
    <div ref={root} className={styles.teaser}>
      <div className={styles.light} aria-hidden />
      <div className={styles.grain} aria-hidden />

      <header className={styles.top}>
        <Link href="/" className={styles.brand} aria-label={`${site.wordmark} — home`}>
          {flags.showProposedMark && <NoonMark className={styles.mark} title="Proposed mark" />}
          <span>{site.wordmark}</span>
        </Link>
        <p className={styles.topCenter} data-t="fade">
          {t.eyebrow}
        </p>
        <nav className={styles.topNav} aria-label="Main">
          <Link href={`/shop/jaun-elia-hoodie`}>The hoodie</Link>
          <Link href="/campaign">Campaign</Link>
        </nav>
      </header>

      <main id="main" tabIndex={-1} className={styles.main}>
        <div className={styles.stage} data-t="stage">
          <video
            className={styles.video}
            src={site.media.rotation.src}
            poster={site.media.rotation.poster}
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            disablePictureInPicture
            aria-label="The Jaun Elia hoodie turning in a dark studio (concept render)"
          />
        </div>

        <section className={styles.left} aria-labelledby="teaser-title">
          <p className={styles.script} data-t="fade">
            {t.eyebrow}
          </p>
          <h1 id="teaser-title" className={styles.title} aria-label={t.title}>
            {t.title.split(" ").map((word, w) => (
              <span key={w} className={styles.word} aria-hidden>
                {word.split("").map((c, i) => (
                  <span key={i} className={styles.mask}>
                    <span data-t="char">{c}</span>
                  </span>
                ))}
              </span>
            ))}
          </h1>
          <span className={styles.rule} data-t="rule" aria-hidden />
          <p className={styles.line} data-t="fade">
            {t.line}
          </p>
        </section>

        <section className={styles.right} aria-label="Launch">
          <div data-t="fade">
            {clock ? (
              <div className={styles.clock} role="timer" aria-label={`Launching in ${clock.d} days, ${clock.h} hours, ${clock.m} minutes`}>
                {(
                  [
                    ["Days", clock.d],
                    ["Hours", clock.h],
                    ["Minutes", clock.m],
                    ["Seconds", clock.s],
                  ] as const
                ).map(([label, v]) => (
                  <div key={label} className={styles.unit}>
                    <span key={v} className={styles.num}>
                      {pad(v)}
                    </span>
                    <span className={styles.unitLabel}>{label}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className={styles.soon}>
                <i className={styles.pulse} aria-hidden />
                {t.soon}
              </p>
            )}
            <p className={styles.edition}>{t.edition}</p>
          </div>

          <form className={styles.form} onSubmit={submit} data-t="fade" noValidate={false}>
            <label htmlFor="notify-email" className={styles.formLabel}>
              {t.notifyLabel}
            </label>
            <div className={styles.field}>
              <input
                id="notify-email"
                type="email"
                required
                autoComplete="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (form !== "idle" && form !== "sending") setForm("idle");
                }}
                disabled={form === "sending" || form === "done"}
              />
              <button type="submit" disabled={form === "sending" || form === "done"}>
                {t.notifyCta}
              </button>
            </div>
            <p className={styles.formStatus} role="status" aria-live="polite">
              {status[form]}
            </p>
          </form>
        </section>
      </main>

      <footer className={styles.bottom}>
        <p>{t.renderNote}</p>
        <nav aria-label="Legal" className={styles.bottomNav}>
          <Link href="/contact">Contact</Link>
          <Link href="/privacy">Privacy</Link>
          <Link href="/terms">Terms</Link>
        </nav>
      </footer>
    </div>
  );
}

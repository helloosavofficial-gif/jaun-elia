"use client";

import { useEffect, useRef, useState } from "react";
import { sequences } from "@/content/site";
import { prefersCalmerMotion, prefersReduced } from "@/lib/motion";
import styles from "./RotationViewer.module.css";

const seq = sequences.rotation;
const COUNT = seq.count;
/** The auto-turn: one full revolution in 12 s, played once. */
const SPIN_PER_MS = 1 / 12000;
/** Pixels of horizontal drag for one full turn. */
const PX_PER_TURN = 900;
/** Frame sets on disk (see content/site.ts). */
const SETS = {
  sm: { src: seq.sm, height: 800 },
  lg: { src: seq.lg, height: seq.height },
};
/** Density counted when choosing a frame set; beyond ~1.5× a soft render gains little. */
const SELECT_DPR_CAP = 1.5;
/** Every 8th frame (24) loads first, so a full turn is available quickly. */
const KEY_STRIDE = 8;
/** Start downloading when the viewer is this close to the viewport. */
const LOAD_MARGIN = "300px 0px";

/** Which side faces the camera, by position in the turn (0–1). */
const VIEWS = [
  { label: "Front", to: 0.19 },
  { label: "Side", to: 0.42 },
  { label: "Back", to: 0.7 },
  { label: "Side", to: 0.89 },
  { label: "Front", to: 1.01 },
];
const viewAt = (a: number) => VIEWS.find((v) => a < v.to)?.label ?? "Front";
const wrap = (a: number) => ((a % 1) + 1) % 1;

type IdleWindow = Window & {
  requestIdleCallback?: (cb: () => void, opts?: { timeout: number }) => number;
  cancelIdleCallback?: (id: number) => void;
};

/**
 * Interactive turn of the hoodie, drawn from frames of the supplied rotation
 * footage. When it first comes into view it turns once on its own, then
 * rests; drag (mouse or touch) or the arrow keys turn it, with a little
 * momentum. Vertical swipes are left to the page, so phones still scroll.
 * The auto-turn is skipped with ?motion=off or the OS "reduce motion"
 * setting (only the automatic turn; dragging and keys still work).
 *
 * Performance: frames download only when the viewer nears the viewport (key
 * frames first, the rest when the browser is idle or the visitor interacts);
 * the frame set is chosen from the drawn size; the canvas never holds more
 * pixels than the frames; and nothing animates while the viewer is off
 * screen, its tab is hidden, or nothing is moving.
 */
export function RotationViewer({ className }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [view, setView] = useState("Front");
  const [dragging, setDragging] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const stage = stageRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !stage || !ctx) return;
    const win = window as IdleWindow;

    const autoSpin = !prefersReduced() && !prefersCalmerMotion();
    const images: (HTMLImageElement | null)[] = new Array(COUNT).fill(null);
    const loaded = new Uint8Array(COUNT);
    const inFlight = new Set<HTMLImageElement>();
    const timers = new Set<number>();
    let set: (typeof SETS)[keyof typeof SETS] | null = null;
    let disposed = false;
    let started = false; // downloads begun
    let restStarted = false;
    let idleHandle = 0;
    let inView = false;
    let running = false;
    let raf = 0;
    let angle = 0; // 0–1 around the turn
    let velocity = 0; // turns per ms, from a released drag
    let drawn = -1;
    let lastTime = 0;
    let pointer: { id: number; x: number; t: number } | null = null;
    let lastView = "Front";
    // the one auto-turn: starts once frames are ready, ends after a full revolution or on any interaction
    let spinState: "waiting" | "spinning" | "done" = autoSpin ? "waiting" : "done";
    let spun = 0;

    const nearest = (i: number) => {
      for (let d = 0; d < COUNT; d++) {
        const a = (i - d + COUNT) % COUNT;
        if (loaded[a]) return a;
        const b = (i + d) % COUNT;
        if (loaded[b]) return b;
      }
      return -1;
    };

    const paint = (img: HTMLImageElement, alpha: number) => {
      const s = Math.min(canvas.width / img.naturalWidth, canvas.height / img.naturalHeight);
      const w = img.naturalWidth * s;
      const h = img.naturalHeight * s;
      ctx.globalAlpha = alpha;
      ctx.drawImage(img, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
    };

    // cross-fades the two frames either side of the exact position, so the
    // turn moves continuously instead of stepping frame to frame
    const draw = () => {
      if (!canvas.width) return;
      const pos = wrap(angle) * COUNT;
      const key = Math.round(pos * 50); // redraw only when the position visibly changes
      if (key === drawn) return;
      const i0 = Math.floor(pos) % COUNT;
      const i1 = (i0 + 1) % COUNT;
      const f = pos - Math.floor(pos);
      const a = loaded[i0] ? i0 : nearest(i0);
      if (a < 0) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      paint(images[a]!, 1);
      if (a === i0 && loaded[i1] && f > 0.02) paint(images[i1]!, f);
      ctx.globalAlpha = 1;
      if (drawn < 0) setReady(true);
      drawn = key;
      const v = viewAt(wrap(angle));
      if (v !== lastView) {
        lastView = v;
        setView(v);
      }
      stage.setAttribute("aria-valuenow", String(Math.round(wrap(angle) * 360)));
    };

    /* ── Animation loop: runs only while visible and something is moving ── */
    const canAnimate = () => !disposed && inView && document.visibilityState === "visible";
    const moving = () => pointer !== null || Math.abs(velocity) > 1e-6 || spinState === "spinning";

    const frame = (now: number) => {
      if (!canAnimate()) {
        running = false;
        return;
      }
      const dt = Math.min(now - lastTime, 64);
      lastTime = now;
      if (!pointer) {
        if (Math.abs(velocity) > 1e-6) {
          angle += velocity * dt;
          velocity *= Math.pow(0.94, dt / 16);
          if (Math.abs(velocity) < 1e-6) velocity = 0;
        } else if (spinState === "spinning") {
          const step = Math.min(SPIN_PER_MS * dt, 1 - spun);
          spun += step;
          angle += step;
          if (spun >= 1) spinState = "done"; // back at the front, at rest
        }
      }
      draw();
      if (moving()) raf = requestAnimationFrame(frame);
      else running = false;
    };

    /** Draws now, and starts the loop if there is motion to animate. */
    const kick = () => {
      draw();
      if (running || !canAnimate() || !moving()) return;
      running = true;
      lastTime = performance.now();
      raf = requestAnimationFrame(frame);
    };

    const stopSpin = () => {
      if (spinState !== "done") spinState = "done";
    };

    /* ── Canvas size: the drawn size, never more pixels than the frames hold ── */
    const resize = () => {
      const r = canvas.getBoundingClientRect();
      if (!r.width || !r.height) return; // hidden (e.g. an inactive tab panel)
      const dpr = window.devicePixelRatio || 1;
      const srcHeight = (set ?? SETS.lg).height;
      const scale = Math.max(1, Math.min(dpr, srcHeight / r.height));
      canvas.width = Math.round(r.width * scale);
      canvas.height = Math.round(r.height * scale);
      drawn = -1;
      draw();
    };
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    /* ── Loading: key frames first, the rest when idle or on interaction ── */
    const chooseSet = () => {
      const h = stage.getBoundingClientRect().height;
      const need = (h || window.innerHeight * 0.8) * Math.min(window.devicePixelRatio || 1, SELECT_DPR_CAP);
      return need <= SETS.sm.height ? SETS.sm : SETS.lg;
    };

    const loadOne = (i: number, attempt = 0) =>
      new Promise<void>((resolve) => {
        if (disposed || loaded[i]) return resolve();
        const img = new Image();
        img.decoding = "async";
        inFlight.add(img);
        img.onload = () => {
          inFlight.delete(img);
          if (disposed) return resolve();
          images[i] = img;
          loaded[i] = 1;
          drawn = -1; // a newly loaded frame may be the better match for the current position
          draw();
          resolve();
        };
        img.onerror = () => {
          inFlight.delete(img);
          if (disposed || attempt >= 1) return resolve(); // skipped: drawing falls back to the nearest loaded frame
          const t = window.setTimeout(() => {
            timers.delete(t);
            loadOne(i, attempt + 1).then(resolve);
          }, 600);
          timers.add(t);
        };
        img.src = set!.src(i);
      });

    const loadAll = async (list: number[], concurrency: number) => {
      let k = 0;
      const worker = async () => {
        while (k < list.length && !disposed) await loadOne(list[k++]);
      };
      await Promise.all(Array.from({ length: concurrency }, worker));
    };

    const keyFrames: number[] = [];
    for (let i = 0; i < COUNT; i += KEY_STRIDE) keyFrames.push(i);
    const restFrames: number[] = [];
    const seen = new Set(keyFrames);
    for (const stride of [4, 2, 1])
      for (let i = 0; i < COUNT; i += stride)
        if (!seen.has(i)) {
          seen.add(i);
          restFrames.push(i);
        }

    const beginSpin = () => {
      if (spinState !== "waiting" || disposed) return;
      if (!loaded.some((v) => v === 1)) {
        spinState = "done"; // nothing loaded: the poster stays, nothing to turn
        return;
      }
      spinState = "spinning";
      spun = 0;
      kick();
    };

    const startRest = () => {
      if (restStarted || disposed) return;
      restStarted = true;
      if (idleHandle) {
        if (win.cancelIdleCallback) win.cancelIdleCallback(idleHandle);
        else window.clearTimeout(idleHandle);
        idleHandle = 0;
      }
      loadAll(restFrames, 3).then(beginSpin); // the auto-turn waits for the full set, so it is smooth
    };

    const startLoading = () => {
      if (started || disposed) return;
      started = true;
      set = chooseSet();
      resize();
      loadAll(keyFrames, 4).then(() => {
        if (disposed || restStarted) return;
        idleHandle = win.requestIdleCallback
          ? win.requestIdleCallback(startRest, { timeout: 2500 })
          : window.setTimeout(startRest, 400);
      });
    };

    /* ── Visibility: load near the viewport; animate only on screen and in a visible tab ── */
    let loadIO: IntersectionObserver | null = null;
    let viewIO: IntersectionObserver | null = null;
    if (typeof IntersectionObserver === "undefined") {
      inView = true;
      startLoading();
    } else {
      loadIO = new IntersectionObserver(
        ([e]) => {
          if (e.isIntersecting) {
            startLoading();
            loadIO?.disconnect();
          }
        },
        { rootMargin: LOAD_MARGIN },
      );
      loadIO.observe(stage);
      viewIO = new IntersectionObserver(([e]) => {
        inView = e.isIntersecting;
        if (inView) kick();
      });
      viewIO.observe(stage);
    }
    const onVisibility = () => {
      if (document.visibilityState === "visible") kick();
    };
    document.addEventListener("visibilitychange", onVisibility);

    /* ── Interaction: drag to turn (horizontal only), arrow keys ── */
    const onDown = (e: PointerEvent) => {
      startRest(); // full smoothness as soon as someone takes hold
      stopSpin();
      pointer = { id: e.pointerId, x: e.clientX, t: performance.now() };
      velocity = 0;
      try {
        stage.setPointerCapture(e.pointerId);
      } catch {
        // pointer already gone (e.g. a cancelled touch) — dragging still works without capture
      }
      setDragging(true);
      kick();
    };
    const onMove = (e: PointerEvent) => {
      if (!pointer || e.pointerId !== pointer.id) return;
      const now = performance.now();
      const dx = e.clientX - pointer.x;
      const delta = dx / PX_PER_TURN;
      angle += delta;
      velocity = delta / Math.max(now - pointer.t, 1);
      pointer = { id: e.pointerId, x: e.clientX, t: now };
      draw();
    };
    const onUp = (e: PointerEvent) => {
      if (!pointer || e.pointerId !== pointer.id) return;
      if (performance.now() - pointer.t > 80) velocity = 0; // held still before release
      pointer = null;
      setDragging(false);
      kick(); // momentum, if any
    };
    const onKey = (e: KeyboardEvent) => {
      const step = e.shiftKey ? 1 / 8 : 1 / 24;
      if (e.key === "ArrowRight") angle += step;
      else if (e.key === "ArrowLeft") angle -= step;
      else if (e.key === "Home") angle = 0;
      else return;
      e.preventDefault();
      startRest();
      stopSpin();
      velocity = 0;
      kick();
    };

    stage.addEventListener("pointerdown", onDown);
    stage.addEventListener("pointermove", onMove);
    stage.addEventListener("pointerup", onUp);
    stage.addEventListener("pointercancel", onUp);
    stage.addEventListener("keydown", onKey);

    if (process.env.NODE_ENV !== "production") {
      // dev-only test hooks
      Object.assign(stage, {
        __angle: () => wrap(angle),
        __frame: () => drawn,
        __state: () => ({ started, restStarted, running, inView, spinState, loaded: loaded.reduce((a, b) => a + b, 0), set: set === SETS.sm ? "sm" : set ? "lg" : null }),
      });
    }

    return () => {
      disposed = true;
      running = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
      loadIO?.disconnect();
      viewIO?.disconnect();
      if (idleHandle) {
        if (win.cancelIdleCallback) win.cancelIdleCallback(idleHandle);
        else window.clearTimeout(idleHandle);
      }
      timers.forEach((t) => window.clearTimeout(t));
      inFlight.forEach((img) => {
        img.onload = null;
        img.onerror = null;
        img.src = ""; // abandon pending downloads
      });
      document.removeEventListener("visibilitychange", onVisibility);
      stage.removeEventListener("pointerdown", onDown);
      stage.removeEventListener("pointermove", onMove);
      stage.removeEventListener("pointerup", onUp);
      stage.removeEventListener("pointercancel", onUp);
      stage.removeEventListener("keydown", onKey);
    };
  }, []);

  return (
    <div className={`${styles.viewer} ${className ?? ""}`}>
      <div
        ref={stageRef}
        className={styles.stage}
        data-ready={ready}
        data-dragging={dragging}
        data-rotation-stage
        tabIndex={0}
        role="slider"
        aria-label="Turn the concept render of the hoodie. Drag or use the left and right arrow keys."
        aria-valuemin={0}
        aria-valuemax={360}
        aria-valuenow={0}
        aria-valuetext={`${view} view`}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img className={styles.poster} src={seq.poster} alt="" aria-hidden />
        <canvas ref={canvasRef} className={styles.canvas} aria-hidden />
      </div>
      <p className={styles.caption} aria-hidden>
        <span>{view}</span>
        <span className={styles.hint}>Drag to turn</span>
      </p>
      {/* The rotation is AI concept footage, not a photograph or scan of the finished hoodie. */}
      <p className={styles.disclosure}>Concept render · not a photograph of the final garment</p>
    </div>
  );
}

"use client";

import Image from "next/image";
import Link from "next/link";
import { useId, useState } from "react";
import { availability, type Product } from "@/content/products";
import { bag, bagDrawer, formatPrice } from "@/lib/bag";
import styles from "./ProductCard.module.css";

/**
 * A product in the collection: images, name, price, a size choice and quick
 * add, and the way into the product page. Uses the existing bag (frontend
 * only); nothing here places an order.
 *
 * lead: the first piece of a collection, front and back side by side with the
 * details beside them · grid: a regular cell (front, the back on hover).
 */
export function ProductCard({ product: p, layout = "grid" }: { product: Product; layout?: "lead" | "grid" }) {
  const uid = useId();
  const [size, setSize] = useState("");
  const [message, setMessage] = useState("");
  const href = `/shop/${p.slug}`;
  const stock = size ? availability(p, size) : null;
  const canAdd = Boolean(size) && (stock ? stock.canBuy : true);
  const lead = layout === "lead";
  const sizes = lead ? "(max-width: 767px) 46vw, (max-width: 1099px) 30vw, 26vw" : "(max-width: 699px) 92vw, (max-width: 1099px) 46vw, 420px";

  const add = () => {
    if (!canAdd) return;
    bag.add(p.id, size);
    bagDrawer.open();
    setMessage(`Added to bag · size ${size}.`);
  };

  return (
    <article className={styles.card} data-layout={layout} aria-labelledby={`${uid}-name`}>
      <Link href={href} className={styles.media} aria-labelledby={`${uid}-name`} tabIndex={-1}>
        <span className={styles.frame}>
          <Image
            src={p.images.front.src}
            width={p.images.front.width}
            height={p.images.front.height}
            alt={p.images.front.alt}
            sizes={sizes}
            className={styles.front}
            priority
          />
          {!lead && (
            <Image
              src={p.images.back.src}
              width={p.images.back.width}
              height={p.images.back.height}
              alt=""
              aria-hidden
              sizes={sizes}
              className={styles.back}
            />
          )}
        </span>
        {lead && (
          <span className={styles.frame}>
            <Image
              src={p.images.back.src}
              width={p.images.back.width}
              height={p.images.back.height}
              alt={p.images.back.alt}
              sizes={sizes}
              className={styles.front}
            />
          </span>
        )}
      </Link>

      <div className={styles.info}>
        <p className={styles.label}>{lead ? `Front and back · ${p.images.label}` : p.images.label}</p>

        <div className={styles.meta}>
          <h3 id={`${uid}-name`} className={styles.name}>
            <Link href={href}>{p.name}</Link>
          </h3>
          <p className={styles.price}>{formatPrice(p.price, p.currency)}</p>
        </div>
        <p className={styles.facts}>
          {p.colour} · {p.finish}
        </p>
        {lead && <p className={styles.description}>{p.description}</p>}

        <fieldset className={styles.sizes}>
          <legend>Size</legend>
          <div className={styles.sizeRow}>
            {p.sizes.map((s) => (
              <label key={s} className={styles.size} data-on={size === s}>
                <input
                  type="radio"
                  name={`${uid}-size`}
                  value={s}
                  checked={size === s}
                  onChange={() => {
                    setSize(s);
                    setMessage("");
                  }}
                />
                <span>{s}</span>
              </label>
            ))}
          </div>
          {!p.sizesConfirmed && <p className={styles.note}>Size run to be confirmed.</p>}
        </fieldset>
        {stock && <p className={styles.note}>{stock.label}</p>}

        <div className={styles.actions}>
          <button type="button" className={styles.add} onClick={add} disabled={!canAdd} aria-describedby={`${uid}-hint`}>
            Add to bag
          </button>
          <Link href={href} className={styles.view}>
            View details <span aria-hidden>→</span>
          </Link>
        </div>
        <p id={`${uid}-hint`} className={styles.message} role="status" aria-live="polite">
          {message || (size ? "" : "Choose a size to add it to your bag.")}
        </p>
      </div>
    </article>
  );
}

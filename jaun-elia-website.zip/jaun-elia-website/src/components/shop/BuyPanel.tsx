"use client";

import { useEffect, useId, useRef, useState } from "react";
import Link from "next/link";
import { availability, hoodieProduct as p } from "@/content/products";
import { site } from "@/content/site";
import { bag, bagDrawer } from "@/lib/bag";
import { StockCounter } from "@/components/StockCounter";
import styles from "./BuyPanel.module.css";

const price = new Intl.NumberFormat("en-PK", { maximumFractionDigits: 0 }).format(p.price);

/**
 * Price, size and the add-to-bag action — nothing else.
 * The bag is frontend-only (saved in this browser); checkout is not
 * connected yet, so nothing here claims an order was placed.
 *
 * On phones, a slim bar with the price and the same action stays at the
 * bottom of the screen whenever the panel's own button is out of view.
 */
export function BuyPanel({ className, detailsHref }: { className?: string; detailsHref?: string }) {
  const sizeGroup = useId(); // unique per panel, so two size pickers on a page never clash
  const [size, setSize] = useState("");
  const [message, setMessage] = useState("");
  const [added, setAdded] = useState(false);
  const [barShown, setBarShown] = useState(false);
  const buyRef = useRef<HTMLButtonElement>(null);
  const sizesRef = useRef<HTMLFieldSetElement>(null);
  const stock = size ? availability(p, size) : null;

  // the phone bar appears only while the panel's own button is off screen
  useEffect(() => {
    const el = buyRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(([e]) => setBarShown(!e.isIntersecting));
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const add = () => {
    if (!size) {
      setAdded(false);
      setMessage("Select a size first.");
      return;
    }
    if (stock && !stock.canBuy) return;
    bag.add(p.id, size);
    bagDrawer.open();
    setAdded(true);
    setMessage(`Added to bag · size ${size}.`);
  };

  /** From the phone bar: add if a size is chosen, otherwise take the visitor to the sizes. */
  const barAction = () => {
    if (size) return add();
    const group = sizesRef.current;
    if (!group) return;
    group.scrollIntoView({ behavior: "smooth", block: "center" });
    group.querySelector<HTMLInputElement>("input")?.focus({ preventScroll: true });
    setMessage("Select a size first.");
  };

  return (
    <section className={`${styles.panel} ${className ?? ""}`} aria-labelledby="product-name">
      <p className={styles.kicker}>{site.label}</p>
      <h1 id="product-name" className={styles.name}>
        {p.name}
      </h1>
      <p className={styles.price}>
        <span>{p.currency}</span> {price}
      </p>

      <ul className={styles.facts}>
        <li>{p.colour}</li>
        <li>{p.finish}</li>
      </ul>

      <fieldset ref={sizesRef} className={styles.sizes}>
        <legend>Size</legend>
        <Link href="/size-guide" className={styles.sizeGuide}>
          Size guide
        </Link>
        <div className={styles.sizeRow}>
          {p.sizes.map((s) => (
            <label key={s} className={styles.size} data-on={size === s}>
              <input
                type="radio"
                name={sizeGroup}
                value={s}
                checked={size === s}
                onChange={() => {
                  setSize(s);
                  setMessage("");
                  setAdded(false);
                }}
              />
              <span>{s}</span>
            </label>
          ))}
        </div>
        {!p.sizesConfirmed && <p className={styles.note}>Size run to be confirmed.</p>}
      </fieldset>

      {stock && <p className={styles.stock}>{stock.label}</p>}

      <button ref={buyRef} type="button" className={styles.buy} onClick={add} disabled={stock ? !stock.canBuy : false}>
        Add to bag
      </button>
      <p className={styles.message} role="status" aria-live="polite">
        {message}
        {added && (
          <>
            {" "}
            <Link href="/bag" className={styles.messageLink}>
              View bag
            </Link>
          </>
        )}
      </p>

      <StockCounter tone="light" className={styles.stockCounter} />

      {detailsHref && (
        <Link href={detailsHref} className={styles.details}>
          Details, size guide &amp; care <span aria-hidden>→</span>
        </Link>
      )}

      {/* phone only (hidden by CSS on wider screens) */}
      <div className={styles.bar} data-shown={barShown} inert={!barShown} aria-hidden={!barShown}>
        <div className={styles.barInfo}>
          <span className={styles.barName}>{p.name}</span>
          <span className={styles.barPrice}>
            {p.currency} {price}
            {size && <span className={styles.barSize}> · Size {size}</span>}
          </span>
        </div>
        <button type="button" className={styles.barButton} onClick={barAction} disabled={stock ? !stock.canBuy : false}>
          {size ? "Add to bag" : "Select size"}
        </button>
      </div>
    </section>
  );
}

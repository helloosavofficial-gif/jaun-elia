"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useId, useRef, useState } from "react";
import { PENDING } from "@/content/products";
import { BagLines } from "@/components/bag/BagLines";
import { bag, formatPrice, useBag } from "@/lib/bag";
import { getCheckoutInfo, newIdempotencyKey, placeOrder, type Customer } from "@/lib/checkout";
import type { CheckoutInfo } from "@/lib/orderTypes";
import { useMounted } from "@/lib/useMounted";
import styles from "./CheckoutView.module.css";

type Field = {
  name: keyof Customer;
  label: string;
  type?: string;
  autoComplete: string;
  wide?: boolean;
  optional?: boolean;
  inputMode?: React.HTMLAttributes<HTMLInputElement>["inputMode"];
  hint?: string;
};

const CONTACT: Field[] = [
  { name: "name", label: "Full name", autoComplete: "name", wide: true },
  { name: "email", label: "Email", type: "email", autoComplete: "email", inputMode: "email", hint: "For your confirmation." },
  { name: "phone", label: "Phone", type: "tel", autoComplete: "tel", inputMode: "tel", hint: "For the courier." },
];

const DELIVERY: Field[] = [
  { name: "address", label: "Address", autoComplete: "street-address", wide: true, hint: "House, street, area." },
  { name: "city", label: "City", autoComplete: "address-level2" },
  { name: "postcode", label: "Postal code", autoComplete: "postal-code", optional: true },
];

const withoutKey = (o: Record<string, string>, k: string) => {
  const next = { ...o };
  delete next[k];
  return next;
};

const EMPTY: Customer ={ name: "", email: "", phone: "", address: "", city: "", postcode: "", notes: "" };
const DRAFT_KEY = "jaun-checkout-draft-v1";

/** Mirrors the server's checks so most mistakes are caught before sending. The server still decides. */
function check(c: Customer): Record<string, string> {
  const e: Record<string, string> = {};
  if (c.name.trim().length < 2) e.name = "Enter your full name.";
  if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(c.email.trim())) e.email = "Enter a valid email address, like name@example.com.";
  const digits = c.phone.replace(/\D/g, "");
  if (digits.length < 10 || digits.length > 15) e.phone = "Enter a valid phone number, like 0300 1234567.";
  if (c.address.trim().length < 8) e.address = "Enter your full address, with house and street.";
  if (c.city.trim().length < 2) e.city = "Enter your city.";
  return e;
}

/**
 * Checkout: contact, delivery and payment beside the order summary. Posts the
 * bag (ids, sizes, quantities only) and the details to /api/orders; the server
 * prices it, checks the edition count and saves it. Only once the server
 * confirms is the bag cleared and the visitor taken to their order.
 */
export function CheckoutView() {
  const { items, count, subtotal, currency } = useBag();
  const mounted = useMounted();
  const router = useRouter();
  const uid = useId();

  const [info, setInfo] = useState<CheckoutInfo | null>(null);
  const [infoError, setInfoError] = useState("");
  const [customer, setCustomer] = useState<Customer>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");
  const [sending, setSending] = useState(false);
  const [placed, setPlaced] = useState(false);
  const key = useRef("");
  const alertRef = useRef<HTMLParagraphElement>(null);

  useEffect(() => {
    key.current = newIdempotencyKey();
    getCheckoutInfo().then((r) => (r.ok ? setInfo(r.data) : setInfoError(r.message)));
    try {
      const saved = sessionStorage.getItem(DRAFT_KEY);
      if (saved) setCustomer({ ...EMPTY, ...JSON.parse(saved) });
    } catch {
      /* storage blocked: start empty */
    }
  }, []);

  // keep what's been typed for this visit, so a trip back to the bag loses nothing
  useEffect(() => {
    if (!mounted || placed) return;
    try {
      sessionStorage.setItem(DRAFT_KEY, JSON.stringify(customer));
    } catch {
      /* ignore */
    }
  }, [customer, mounted, placed]);

  if (!mounted) return <p className={styles.muted}>Loading your bag…</p>;

  if (placed) return <p className={styles.muted} role="status">Order placed. Taking you to it…</p>;

  if (items.length === 0) {
    return (
      <div className={styles.empty}>
        <p>Your bag is empty, so there is nothing to check out.</p>
        <Link href="/shop" className={styles.primary}>
          Go to the shop
        </Link>
      </div>
    );
  }

  const closed = info !== null && !info.enabled;
  const soldOut = info !== null && info.stock.remaining === 0;
  const shipping = info?.shippingFee ?? null;
  const total = subtotal + (shipping ?? 0);

  const update = (name: keyof Customer) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const value = e.target.value;
    setCustomer((c) => ({ ...c, [name]: value }));
    if (errors[name]) setErrors((all) => withoutKey(all, name));
  };

  const focusFirst = (errs: Record<string, string>) => {
    const first = [...CONTACT, ...DELIVERY].find((f) => errs[f.name]);
    if (first) document.getElementById(`${uid}-${first.name}`)?.focus();
    else alertRef.current?.focus();
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (sending || closed) return;
    setFormError("");
    const errs = check(customer);
    setErrors(errs);
    if (Object.keys(errs).length) {
      setFormError("Please check the highlighted fields.");
      requestAnimationFrame(() => focusFirst(errs));
      return;
    }

    setSending(true);
    const res = await placeOrder({
      lines: items.map(({ productId, size, qty }) => ({ productId, size, qty })),
      customer,
      paymentMethod: "cod",
      idempotencyKey: key.current,
    });

    if (res.ok) {
      setPlaced(true);
      bag.clear();
      try {
        sessionStorage.removeItem(DRAFT_KEY);
      } catch {
        /* ignore */
      }
      router.replace(res.data.url);
      return;
    }

    setSending(false);
    setErrors(res.fields);
    setFormError(res.message);
    // a stock or availability problem means the bag needs changing, not the form
    if (res.status === 409 || res.fields.lines) getCheckoutInfo().then((r) => r.ok && setInfo(r.data));
    requestAnimationFrame(() => focusFirst(res.fields));
  };

  const fields = (list: Field[]) =>
    list.map((f) => {
      const id = `${uid}-${f.name}`;
      const err = errors[f.name];
      const described = [f.hint && `${id}-hint`, err && `${id}-err`].filter(Boolean).join(" ") || undefined;
      return (
        <div key={f.name} className={styles.field} data-wide={f.wide ?? false} data-invalid={Boolean(err)}>
          <label htmlFor={id}>
            {f.label}
            {f.optional && <em> · optional</em>}
          </label>
          <input
            id={id}
            name={f.name}
            type={f.type ?? "text"}
            inputMode={f.inputMode}
            autoComplete={f.autoComplete}
            value={customer[f.name]}
            onChange={update(f.name)}
            required={!f.optional}
            aria-invalid={Boolean(err)}
            aria-describedby={described}
          />
          {f.hint && !err && (
            <small id={`${id}-hint`} className={styles.hint}>
              {f.hint}
            </small>
          )}
          {err && (
            <small id={`${id}-err`} className={styles.error}>
              {err}
            </small>
          )}
        </div>
      );
    });

  return (
    <div className={styles.wrap}>
      {(closed || infoError) && (
        <p className={styles.banner} role="status">
          {soldOut ? (
            <>
              <strong>The edition has sold out.</strong> Every one of the {info?.stock.total.toLocaleString("en-PK")} pieces
              has found a home.
            </>
          ) : closed ? (
            <>
              <strong>Ordering is closed right now.</strong> Your bag is saved in this browser.
            </>
          ) : (
            <>
              <strong>We couldn&rsquo;t reach the shop.</strong> {infoError} You can still try placing your order.
            </>
          )}
        </p>
      )}

      <form className={styles.layout} onSubmit={submit} noValidate aria-busy={sending}>
        <div className={styles.main}>
          <fieldset className={styles.step} disabled={sending || closed}>
            <legend className={styles.stepHead}>
              <span className={styles.stepN}>01</span>
              <span className={styles.stepTitle}>Contact</span>
            </legend>
            <div className={styles.fields}>{fields(CONTACT)}</div>
          </fieldset>

          <fieldset className={styles.step} disabled={sending || closed}>
            <legend className={styles.stepHead}>
              <span className={styles.stepN}>02</span>
              <span className={styles.stepTitle}>Delivery</span>
            </legend>
            <div className={styles.fields}>
              {fields(DELIVERY)}
              <div className={styles.field} data-wide>
                <label htmlFor={`${uid}-notes`}>
                  Delivery notes<em> · optional</em>
                </label>
                <textarea
                  id={`${uid}-notes`}
                  name="notes"
                  rows={3}
                  maxLength={500}
                  value={customer.notes}
                  onChange={update("notes")}
                  placeholder="Landmark, best time to call, gate code"
                />
              </div>
            </div>
          </fieldset>

          <fieldset className={styles.step} disabled={sending || closed}>
            <legend className={styles.stepHead}>
              <span className={styles.stepN}>03</span>
              <span className={styles.stepTitle}>Payment</span>
            </legend>
            <div className={styles.methods}>
              <label className={styles.method}>
                <input type="radio" name="paymentMethod" value="cod" checked readOnly />
                <span className={styles.methodText}>
                  <strong>Cash on delivery</strong>
                  <span>Pay the courier in cash when your order arrives. Nothing is charged now.</span>
                </span>
              </label>
            </div>
          </fieldset>
        </div>

        <aside className={styles.summary} aria-labelledby={`${uid}-summary`}>
          <div className={styles.summaryHead}>
            <h2 id={`${uid}-summary`}>Order summary</h2>
            <Link href="/bag">Edit bag</Link>
          </div>
          <BagLines readOnly />
          <dl className={styles.totals}>
            <div>
              <dt>Items</dt>
              <dd>{count}</dd>
            </div>
            <div>
              <dt>Subtotal</dt>
              <dd>{formatPrice(subtotal, currency)}</dd>
            </div>
            <div>
              <dt>Shipping</dt>
              <dd>{shipping === null ? PENDING : shipping === 0 ? "Free" : formatPrice(shipping, currency)}</dd>
            </div>
            <div className={styles.total}>
              <dt>Total</dt>
              <dd>
                {formatPrice(total, currency)}
                {shipping === null && <span className={styles.plus}> + shipping</span>}
              </dd>
            </div>
          </dl>

          {formError && (
            <p ref={alertRef} className={styles.alert} role="alert" tabIndex={-1}>
              {formError}
              {errors.lines && (
                <>
                  {" "}
                  <Link href="/bag">Review your bag</Link>
                </>
              )}
            </p>
          )}

          <button type="submit" className={styles.primary} disabled={sending || closed} data-busy={sending}>
            <span>{sending ? "Placing order" : "Place order"}</span>
          </button>
          <p className={styles.muted}>
            {shipping === null
              ? "We'll confirm the shipping cost with you before your order ships. You pay in cash on delivery."
              : "You pay in cash on delivery. Nothing is charged now."}{" "}
            By placing an order you agree to our <Link href="/terms">terms</Link> and{" "}
            <Link href="/privacy">privacy notice</Link>.
          </p>
        </aside>
      </form>
    </div>
  );
}

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { flags, site } from "@/content/site";
import { NoonMark } from "@/components/Marks";
import styles from "./SiteFooter.module.css";

const groups = [
  {
    title: "Shop",
    links: [
      { label: "Shop", href: "/shop" },
      { label: "The Hoodie", href: "/shop/jaun-elia-hoodie" },
      { label: "Campaign", href: "/campaign" },
      { label: "Bag", href: "/bag" },
    ],
  },
  {
    title: "Help",
    links: [
      { label: "Size guide", href: "/size-guide" },
      { label: "Shipping & returns", href: "/shipping-returns" },
      { label: "Contact", href: "/contact" },
    ],
  },
  {
    title: "About",
    links: [
      { label: "Story", href: "/about" },
      { label: "Privacy", href: "/privacy" },
      { label: "Terms", href: "/terms" },
    ],
  },
];

/** Site-wide footer: brand, grouped links, and (on the campaign page) the scenes. */
export function SiteFooter() {
  const pathname = usePathname();
  if (pathname.startsWith("/studio") || pathname.startsWith("/admin")) return null;
  const home = pathname === "/campaign";

  return (
    <footer className={styles.footer}>
      <div className={styles.brand}>
        {flags.showProposedMark && <NoonMark className={styles.mark} title="Proposed mark" />}
        <span>{site.label}</span>
      </div>
      <nav className={styles.groups} aria-label="Footer">
        {groups.map((g) => (
          <div key={g.title} className={styles.group}>
            <h2 className={styles.groupTitle}>{g.title}</h2>
            <ul>
              {g.links.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} aria-current={pathname === l.href ? "page" : undefined}>
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
        {home && (
          <div className={styles.group}>
            <h2 className={styles.groupTitle}>This page</h2>
            <ul>
              {site.nav.map((n) => (
                <li key={n.href}>
                  <a href={n.href}>{n.label}</a>
                </li>
              ))}
            </ul>
          </div>
        )}
      </nav>
      <p className={styles.note}>
        <span>© {new Date().getFullYear()} {site.label}</span>
        <span>{site.footer}</span>
        <a href="#top">Back to top</a>
      </p>
    </footer>
  );
}

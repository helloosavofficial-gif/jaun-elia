"use client";

import { useId, useRef, useState } from "react";
import { sendMessage } from "@/lib/checkout";
import styles from "./ContactForm.module.css";

const SUBJECTS = ["Order", "Sizing", "Product", "Press & collaborations", "Other"] as const;

type Values = { name: string; email: string; phone: string; orderCode: string; subject: string; body: string; website: string };
const EMPTY: Values = { name: "", email: "", phone: "", orderCode: "", subject: "", body: "", website: "" };

/** Sends to /api/contact, which stores the message for /admin and emails the team inbox. */
export function ContactForm() {
  const uid = useId();
  const [v, setV] = useState<Values>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [state, setState] = useState<"idle" | "sending" | "sent">("idle");
  const [formError, setFormError] = useState("");
  const done = useRef<HTMLDivElement>(null);

  const set = (k: keyof Values) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const value = e.target.value;
    setV((x) => ({ ...x, [k]: value }));
    if (errors[k])
      setErrors((all) => {
        const next = { ...all };
        delete next[k];
        return next;
      });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (state === "sending") return;
    const errs: Record<string, string> = {};
    if (v.name.trim().length < 2) errs.name = "Enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(v.email.trim())) errs.email = "Enter a valid email address.";
    if (!v.subject) errs.subject = "Choose what your message is about.";
    if (v.body.trim().length < 10) errs.body = "Tell us a little more (at least 10 characters).";
    setErrors(errs);
    if (Object.keys(errs).length) {
      setFormError("");
      document.getElementById(`${uid}-${Object.keys(errs)[0]}`)?.focus();
      return;
    }
    setState("sending");
    setFormError("");
    const res = await sendMessage(v);
    if (res.ok) {
      setState("sent");
      setV(EMPTY);
      requestAnimationFrame(() => done.current?.focus());
    } else {
      setState("idle");
      setErrors(res.fields);
      setFormError(res.message);
    }
  };

  if (state === "sent") {
    return (
      <div ref={done} className={styles.sent} role="status" tabIndex={-1}>
        <p className={styles.sentTitle}>Thank you. Your message is with us.</p>
        <p>We&rsquo;ll reply to you by email.</p>
        <button type="button" className={styles.link} onClick={() => setState("idle")}>
          Send another message
        </button>
      </div>
    );
  }

  const field = (k: keyof Values, label: string, input: React.ReactNode, opts: { wide?: boolean; optional?: boolean } = {}) => (
    <div className={styles.field} data-wide={opts.wide ?? false} data-invalid={Boolean(errors[k])}>
      <label htmlFor={`${uid}-${k}`}>
        {label}
        {opts.optional && <em> · optional</em>}
      </label>
      {input}
      {errors[k] && (
        <small id={`${uid}-${k}-err`} className={styles.error}>
          {errors[k]}
        </small>
      )}
    </div>
  );

  const a11y = (k: keyof Values) => ({
    id: `${uid}-${k}`,
    "aria-invalid": Boolean(errors[k]),
    "aria-describedby": errors[k] ? `${uid}-${k}-err` : undefined,
  });

  return (
    <form className={styles.form} onSubmit={submit} noValidate aria-busy={state === "sending"}>
      <fieldset className={styles.fields} disabled={state === "sending"}>
        {field("name", "Name", <input {...a11y("name")} autoComplete="name" value={v.name} onChange={set("name")} />)}
        {field(
          "email",
          "Email",
          <input {...a11y("email")} type="email" inputMode="email" autoComplete="email" value={v.email} onChange={set("email")} />,
        )}
        {field(
          "phone",
          "Phone",
          <input {...a11y("phone")} type="tel" inputMode="tel" autoComplete="tel" value={v.phone} onChange={set("phone")} />,
          { optional: true },
        )}
        {field(
          "orderCode",
          "Order number",
          <input
            {...a11y("orderCode")}
            placeholder="JE-ABCD-2345"
            autoCapitalize="characters"
            value={v.orderCode}
            onChange={set("orderCode")}
          />,
          { optional: true },
        )}
        {field(
          "subject",
          "About",
          <select {...a11y("subject")} value={v.subject} onChange={set("subject")}>
            <option value="" disabled>
              Choose one
            </option>
            {SUBJECTS.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>,
          { wide: true },
        )}
        {field("body", "Message", <textarea {...a11y("body")} rows={6} maxLength={4000} value={v.body} onChange={set("body")} />, {
          wide: true,
        })}
        {/* honeypot: hidden from people and screen readers */}
        <input
          className={styles.trap}
          tabIndex={-1}
          aria-hidden
          autoComplete="off"
          name="website"
          value={v.website}
          onChange={set("website")}
        />
      </fieldset>

      {formError && (
        <p className={styles.alert} role="alert">
          {formError}
        </p>
      )}

      <div className={styles.actions}>
        <button type="submit" className={styles.primary} disabled={state === "sending"}>
          {state === "sending" ? "Sending…" : "Send message"}
        </button>
        <p className={styles.small}>We use your details only to reply to you.</p>
      </div>
    </form>
  );
}

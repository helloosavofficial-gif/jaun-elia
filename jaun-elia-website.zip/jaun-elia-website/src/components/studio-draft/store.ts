/**
 * Mutable view state shared between scroll animations (GSAP) and the 3D scene.
 * Plain object on purpose: written every frame, never triggers React renders.
 */
export const view = {
  /** Base rotation around Y driven by scroll (radians). */
  rotY: 0,
  /** Slow idle spin weight, 0–1. */
  spin: 1,
  /** Camera distance, height and look-at height. */
  camZ: 7.4,
  camY: 0.1,
  lookY: -0.05,
  /** Horizontal offset of the garment in world units (for side-by-side layouts). */
  x: 0,
  /** Rotation added by the visitor dragging. */
  drag: 0,
};

export type ViewState = typeof view;

export const presets = {
  hero: { rotY: 0, camZ: 7.4, camY: 0.1, lookY: -0.05, x: 0 },
  front: { rotY: 0, camZ: 6.7, camY: 0.3, lookY: -0.05, x: 0 },
  frontDetail: { rotY: -0.42, camZ: 2.8, camY: 0.3, lookY: 0.14, x: 0 },
  back: { rotY: Math.PI, camZ: 6.7, camY: 0.2, lookY: -0.12, x: 0 },
  backDetail: { rotY: Math.PI, camZ: 2.6, camY: 0.25, lookY: 0.1, x: 0 },
  threeQuarter: { rotY: -0.65, camZ: 6.6, camY: 0.4, lookY: -0.05, x: 0 },
} satisfies Record<string, Partial<ViewState>>;

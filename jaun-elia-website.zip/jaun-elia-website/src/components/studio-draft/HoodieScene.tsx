"use client";

import { Suspense, useMemo, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer } from "@react-three/drei";
import { Hoodie } from "./Hoodie";
import { view as defaultView, type ViewState } from "./store";

type Props = {
  view?: ViewState;
  /** Keep the drawing buffer so the canvas can be exported as PNG (studio). */
  preserveDrawingBuffer?: boolean;
  background?: string | null;
  className?: string;
  onReady?: () => void;
  frameloop?: "always" | "never" | "demand";
  dpr?: number | [number, number];
};

export function HoodieScene({
  view = defaultView,
  preserveDrawingBuffer = false,
  background = null,
  className,
  onReady,
  frameloop = "always",
  dpr = [1, 2],
}: Props) {
  return (
    <Canvas
      className={className}
      shadows
      dpr={dpr}
      frameloop={frameloop}
      camera={{ position: [0, view.camY, view.camZ], fov: 28, near: 0.1, far: 50 }}
      gl={{ antialias: true, alpha: background === null, preserveDrawingBuffer }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.05;
      }}
    >
      {background && <color attach="background" args={[background]} />}
      <Lights />
      <Suspense fallback={null}>
        <Rig view={view} onReady={onReady} glow={background === null} />
      </Suspense>
    </Canvas>
  );
}

/** Warm studio glow behind the garment, so transparent pages read as lit. */
function Glow() {
  const tex = useMemo(() => {
    const size = 256;
    const cv = document.createElement("canvas");
    cv.width = cv.height = size;
    const ctx = cv.getContext("2d")!;
    const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    g.addColorStop(0, "rgba(196,178,152,0.22)");
    g.addColorStop(0.5, "rgba(196,178,152,0.07)");
    g.addColorStop(1, "rgba(196,178,152,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
    const t = new THREE.CanvasTexture(cv);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, []);
  return (
    <mesh position={[0, 0.1, -3]} scale={[9, 9, 1]}>
      <planeGeometry />
      <meshBasicMaterial map={tex} transparent depthWrite={false} toneMapped={false} />
    </mesh>
  );
}

/** Soft radial shadow under the garment (cheaper and steadier than a shadow pass). */
function GroundShadow() {
  const tex = useMemo(() => {
    const size = 256;
    const cv = document.createElement("canvas");
    cv.width = cv.height = size;
    const ctx = cv.getContext("2d")!;
    const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    g.addColorStop(0, "rgba(0,0,0,0.75)");
    g.addColorStop(0.45, "rgba(0,0,0,0.35)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
    const t = new THREE.CanvasTexture(cv);
    return t;
  }, []);
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.2, 0]} scale={[2.9, 1.2, 1]}>
      <planeGeometry />
      <meshBasicMaterial map={tex} transparent depthWrite={false} />
    </mesh>
  );
}

function Lights() {
  return (
    <>
      <ambientLight intensity={0.06} />
      {/* key: high, front-left, soft */}
      <directionalLight
        position={[-4.5, 4, 2.6]}
        intensity={2.6}
        color="#fff6ea"
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0004}
        shadow-normalBias={0.02}
      >
        <orthographicCamera attach="shadow-camera" args={[-2.5, 2.5, 2.5, -2.5, 0.1, 20]} />
      </directionalLight>
      {/* warm rim from behind-right to carve the silhouette */}
      <spotLight position={[3.5, 3, -4]} angle={0.6} penumbra={1} intensity={60} color="#ffd9a8" />
      {/* cool low fill */}
      <pointLight position={[2.5, -1, 3]} intensity={3} color="#c9d4ff" />
      <Environment resolution={256}>
        <Lightformer form="rect" intensity={1.3} position={[0, 4, 2]} rotation={[Math.PI / 2, 0, 0]} scale={[6, 3, 1]} />
        <Lightformer form="rect" intensity={0.9} position={[-4, 1, 1]} rotation={[0, Math.PI / 2, 0]} scale={[3, 4, 1]} />
        <Lightformer form="rect" intensity={0.8} color="#ffd9b0" position={[4, 1, -2]} rotation={[0, -Math.PI / 2, 0]} scale={[3, 4, 1]} />
      </Environment>
    </>
  );
}

const damp = THREE.MathUtils.damp;

function Rig({ view, onReady, glow }: { view: ViewState; onReady?: () => void; glow: boolean }) {
  const group = useRef<THREE.Group>(null);
  const follow = useRef<THREE.Group>(null);
  const { camera, size } = useThree();
  const look = useRef(new THREE.Vector3(0, view.lookY, 0));
  const idle = useRef(0);
  const ready = useRef(false);

  useFrame((_, dt) => {
    const g = group.current;
    if (!g) return;
    if (!ready.current) {
      ready.current = true;
      onReady?.();
    }
    const d = Math.min(dt, 1 / 20);
    if (view.spin > 0.01) {
      idle.current += d * 0.22 * view.spin;
    } else {
      // settle the idle spin onto a whole turn so scroll-driven angles land exactly
      const TAU = Math.PI * 2;
      idle.current = damp(idle.current, Math.round(idle.current / TAU) * TAU, 2.5, d);
    }
    const target = view.rotY + view.drag + idle.current;
    g.rotation.y = damp(g.rotation.y, target, 4, d);
    // portrait screens: pull the camera back and keep the garment centred
    const aspect = size.width / Math.max(1, size.height);
    const zScale = aspect < 1 ? Math.min(1.8, 0.95 / aspect) : 1;
    const xScale = aspect < 1 ? 0 : Math.min(1, aspect / 1.6);
    g.position.x = damp(g.position.x, view.x * xScale, 4, d);
    if (follow.current) follow.current.position.x = g.position.x;
    camera.position.z = damp(camera.position.z, view.camZ * zScale, 3.2, d);
    camera.position.y = damp(camera.position.y, view.camY, 3.2, d);
    look.current.y = damp(look.current.y, view.lookY, 3.2, d);
    camera.lookAt(look.current);
  });

  return (
    <>
      <group ref={group}>
        <Hoodie />
      </group>
      {/* shadow and glow track the garment's position but not its rotation */}
      <group ref={follow}>
        <GroundShadow />
        {glow && <Glow />}
      </group>
    </>
  );
}

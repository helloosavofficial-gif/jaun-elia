"use client";

import { useEffect, type RefObject } from "react";
import type { ViewState } from "./store";

/**
 * Horizontal drag rotates the garment, with a little inertia on release.
 * Vertical gestures are left to the page so touch scrolling still works.
 */
export function useDragRotate(target: RefObject<HTMLElement | null>, view: ViewState) {
  useEffect(() => {
    const el = target.current;
    if (!el) return;
    el.style.touchAction = "pan-y";
    el.style.cursor = "grab";

    let active = false;
    let lastX = 0;
    let velocity = 0;
    let raf = 0;

    const coast = () => {
      velocity *= 0.94;
      view.drag += velocity;
      if (Math.abs(velocity) > 0.0005) raf = requestAnimationFrame(coast);
    };

    const down = (e: PointerEvent) => {
      active = true;
      lastX = e.clientX;
      velocity = 0;
      cancelAnimationFrame(raf);
      el.setPointerCapture(e.pointerId);
      el.style.cursor = "grabbing";
    };
    const move = (e: PointerEvent) => {
      if (!active) return;
      const dx = e.clientX - lastX;
      lastX = e.clientX;
      velocity = dx * 0.008;
      view.drag += velocity;
    };
    const up = (e: PointerEvent) => {
      if (!active) return;
      active = false;
      el.releasePointerCapture?.(e.pointerId);
      el.style.cursor = "grab";
      raf = requestAnimationFrame(coast);
    };

    el.addEventListener("pointerdown", down);
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
    return () => {
      cancelAnimationFrame(raf);
      el.removeEventListener("pointerdown", down);
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
    };
  }, [target, view]);
}

import * as THREE from "three";

/**
 * INTERNAL DRAFT (used only by /studio). Procedural concept model of the oversized hoodie.
 * Proportions are approximated from the client's mockup — this is not a scan
 * or pattern-accurate model of the real garment.
 *
 * Units: roughly metres / 0.6 (the body is ~2.3 units tall). Front faces +z.
 */

const TAU = Math.PI * 2;
const clamp01 = (t: number) => Math.min(1, Math.max(0, t));
const smooth = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const spow = (v: number, p: number) => Math.sign(v) * Math.pow(Math.abs(v), p);

export const BODY = {
  hem: -1.14,
  ribTop: -0.99,
  shoulder: 0.46,
  neck: 0.8,
};

/** Half-width / half-depth / squareness of the body at height y. */
function bodyProfile(y: number) {
  const top = clamp01((y - BODY.shoulder) / (BODY.neck - BODY.shoulder));
  const rib = 1 - smooth(BODY.ribTop - 0.03, BODY.ribTop + 0.03, y);
  const blouse = Math.exp(-Math.pow((y - (BODY.ribTop + 0.07)) / 0.07, 2)) * 0.025;

  let a = 0.69 - 0.025 * smooth(0.2, -0.8, y) + blouse;
  let b = 0.28 + 0.025 * Math.exp(-Math.pow((y - 0.2) / 0.35, 2)) + blouse * 0.6;
  // drop shoulder: stays broad, then rolls toward the neck
  a = lerp(a, 0.215, Math.pow(top, 0.78));
  b = lerp(b, 0.175, Math.pow(top, 1.1));
  // ribbed hem band tucks in
  a = lerp(a, 0.64, rib);
  b = lerp(b, 0.255, rib);
  const n = lerp(2.35, 2.05, top);
  return { a, b, n, rib };
}

/** Point on the body surface. theta = 0 is centre front. */
export function bodyPoint(theta: number, y: number, inflate = 0) {
  const { a, b, n, rib } = bodyProfile(y);
  const s = Math.sin(theta);
  const c = Math.cos(theta);
  let x = a * spow(s, 2 / n);
  let z = b * spow(c, 2 / n);
  // rib knit + soft folds
  const ribBump = rib * 0.0045 * Math.cos(theta * 150);
  const folds =
    0.006 * Math.sin(y * 9 + Math.sin(theta * 3) * 2.2) * smooth(-0.95, -0.5, y) * (1 - smooth(0.2, 0.5, y)) +
    0.012 * Math.sin(theta * 7 + 1.3) * Math.exp(-Math.pow((y - (BODY.ribTop + 0.08)) / 0.06, 2));
  const len = Math.hypot(x / a, z / b) || 1;
  const nx = x / (a * a);
  const nz = z / (b * b);
  const nl = Math.hypot(nx, nz) || 1;
  const off = ribBump + folds + inflate;
  x += (nx / nl) * off;
  z += (nz / nl) * off;
  void len;
  return new THREE.Vector3(x, y, z);
}

/**
 * Planar projection of a rectangle onto the body (like a print/embroidery
 * placement). facing = horizontal direction the artwork faces (0 = front).
 * Returns a mesh grid with UVs 0–1 that sits just above the fabric.
 */
export function makeArtPatch(facing: number, centerX: number, centerY: number, width: number, height: number) {
  const n = new THREE.Vector2(Math.sin(facing), Math.cos(facing)); // (x, z)
  const right = new THREE.Vector2(Math.cos(facing), -Math.sin(facing));
  const inside = (x: number, z: number, y: number) => {
    const { a, b, n: e } = bodyProfile(y);
    return Math.pow(Math.abs(x) / a, e) + Math.pow(Math.abs(z) / b, e) <= 1;
  };
  return surface(
    48,
    Math.round(48 * (height / width)),
    (u, v) => {
      const y = centerY + (v - 0.5) * height;
      const ox = right.x * (centerX + (u - 0.5) * width) + n.x * 1.5;
      const oz = right.y * (centerX + (u - 0.5) * width) + n.y * 1.5;
      // march in, then bisect onto the base surface
      let lo = 0;
      let hi = 0;
      for (let t = 0; t < 3; t += 0.02) {
        if (inside(ox - n.x * t, oz - n.y * t, y)) {
          hi = t;
          lo = t - 0.02;
          break;
        }
      }
      for (let k = 0; k < 24; k++) {
        const mid = (lo + hi) / 2;
        if (inside(ox - n.x * mid, oz - n.y * mid, y)) hi = mid;
        else lo = mid;
      }
      const x = ox - n.x * hi;
      const z = oz - n.y * hi;
      const { a, b, n: e } = bodyProfile(y);
      const theta = Math.atan2(spow(x / a, e / 2), spow(z / b, e / 2));
      return bodyPoint(theta, y, 0.0035);
    },
    [1, 1],
    false,
  );
}

/** Builds a closed tube-like surface from a point function, seam at u = 0/1 with welded normals. */
function surface(
  segU: number,
  segV: number,
  fn: (u: number, v: number) => THREE.Vector3,
  uvScale: [number, number],
  closedU = true,
) {
  const pos: number[] = [];
  const uv: number[] = [];
  const idx: number[] = [];
  for (let j = 0; j <= segV; j++) {
    const v = j / segV;
    for (let i = 0; i <= segU; i++) {
      const u = i / segU;
      const p = fn(u, v);
      pos.push(p.x, p.y, p.z);
      uv.push(u * uvScale[0], v * uvScale[1]);
    }
  }
  const row = segU + 1;
  for (let j = 0; j < segV; j++) {
    for (let i = 0; i < segU; i++) {
      const a = j * row + i;
      const b = a + 1;
      const c = a + row;
      const d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  if (closedU) {
    const n = g.getAttribute("normal") as THREE.BufferAttribute;
    const tmp = new THREE.Vector3();
    for (let j = 0; j <= segV; j++) {
      const a = j * row;
      const b = a + segU;
      tmp.set(n.getX(a) + n.getX(b), n.getY(a) + n.getY(b), n.getZ(a) + n.getZ(b)).normalize();
      n.setXYZ(a, tmp.x, tmp.y, tmp.z);
      n.setXYZ(b, tmp.x, tmp.y, tmp.z);
    }
  }
  return g;
}

export function makeBody() {
  // seam at the back (theta = PI) so it is never seen head-on from the front
  return surface(
    160,
    120,
    (u, v) => bodyPoint(Math.PI + u * TAU, lerp(BODY.hem, BODY.neck, v)),
    [18, 14],
  );
}

/** Inside of the body, slightly darker, visible through the neck and hem. */
export function makeBodyLining() {
  return surface(
    80,
    40,
    (u, v) => bodyPoint(Math.PI + u * TAU, lerp(BODY.hem, BODY.neck, v), -0.012),
    [1, 1],
  );
}

/* ── Sleeves ─────────────────────────────────────────────────────────── */

export const SLEEVE_POINTS = [
  [0.44, 0.33, -0.01],
  [0.7, 0.28, 0.0],
  [0.88, 0.08, 0.02],
  [0.96, -0.3, 0.05],
  [0.985, -0.68, 0.08],
  [0.98, -0.93, 0.09],
  [0.975, -1.1, 0.09],
] as const;

function sleeveRadius(t: number) {
  const r = lerp(0.24, 0.195, smooth(0, 0.3, t)) - 0.035 * smooth(0.3, 0.8, t);
  const blouse = 0.012 * Math.exp(-Math.pow((t - 0.84) / 0.03, 2));
  const cuff = smooth(0.85, 0.87, t);
  return lerp(r + blouse, 0.11, cuff);
}

export function makeSleeve(side: 1 | -1) {
  const curve = new THREE.CatmullRomCurve3(
    SLEEVE_POINTS.map(([x, y, z]) => new THREE.Vector3(x * side, y, z)),
    false,
    "centripetal",
  );
  const seg = 120;
  const frames = curve.computeFrenetFrames(seg, false);
  const geo = surface(
    48,
    seg,
    (u, v) => {
      const k = Math.round(v * seg);
      const p = curve.getPointAt(v);
      const N = frames.normals[k];
      const B = frames.binormals[k];
      const ang = u * TAU;
      const cuff = smooth(0.85, 0.87, v);
      let r = sleeveRadius(v);
      r += cuff * 0.003 * Math.cos(ang * 60);
      r += 0.008 * Math.sin(v * 70 + Math.sin(ang * 2) * 2) * smooth(0.55, 0.8, v) * (1 - cuff);
      const armhole = 1 + 0.18 * (1 - smooth(0, 0.22, v));
      const c = Math.cos(ang) * r * armhole;
      const s = Math.sin(ang) * r * 0.9;
      return new THREE.Vector3(
        p.x + N.x * c + B.x * s,
        p.y + N.y * c + B.y * s,
        p.z + N.z * c + B.z * s,
      );
    },
    [6, 10],
  );
  const end = curve.getPointAt(1);
  const tangent = curve.getTangentAt(1);
  return { geo, end, tangent };
}

/* ── Hood ────────────────────────────────────────────────────────────── */

export function makeHood() {
  // a shell open to the front, resting back over the shoulders
  const phiA = Math.PI * 0.88;
  const phiB = Math.PI * 2.12;
  const thetaB = Math.PI * 0.6;
  const g = surface(
    90,
    60,
    (u, v) => {
      const phi = lerp(phiA, phiB, u);
      const theta = v * thetaB;
      const sx = 0.34;
      const sy = 0.46;
      const sz = 0.36;
      // pinch the crown into a soft ridge along the centre back
      const ridge = 1 + 0.06 * Math.exp(-Math.pow((phi - Math.PI * 1.5) / 0.25, 2)) * Math.sin(theta * 1.4);
      return hoodPoint(phi, theta, sx, sy, sz, ridge);
    },
    [6, 6],
    false,
  );
  return g;
}

function hoodPoint(phi: number, theta: number, sx: number, sy: number, sz: number, ridge = 1) {
  const front = Math.max(0, Math.sin(phi));
  // draw the front edges together toward the neckline
  const gather = 1 - 0.55 * smooth(Math.PI * 0.2, Math.PI * 0.6, theta) * Math.sqrt(front);
  const x = -Math.cos(phi) * Math.sin(theta) * sx * gather;
  const y = Math.cos(theta) * sy;
  const z = Math.sin(phi) * Math.sin(theta) * sz * ridge;
  return new THREE.Vector3(x, y, z);
}

/** Front edge of the hood as a curve (in hood local space) for the rolled lip. */
export function hoodEdgeCurve() {
  const pts: THREE.Vector3[] = [];
  const thetaB = Math.PI * 0.6;
  const edge = (phi: number, theta: number) => hoodPoint(phi, theta, 0.34, 0.46, 0.36);
  for (let i = 12; i >= 1; i--) pts.push(edge(Math.PI * 0.88, (i / 12) * thetaB));
  for (let i = 0; i <= 12; i++) pts.push(edge(Math.PI * 2.12, (i / 12) * thetaB));
  return new THREE.CatmullRomCurve3(pts);
}

/* ── Kangaroo pocket ────────────────────────────────────────────────── */

const POCKET = { y0: -0.8, y1: -0.28, bottomHalf: 0.7, topHalf: 0.45 };

function pocketTheta(s: number, y: number) {
  const t = (y - POCKET.y0) / (POCKET.y1 - POCKET.y0);
  const half = lerp(POCKET.bottomHalf, POCKET.topHalf, t);
  return lerp(-half, half, s);
}

export function makePocket() {
  return surface(
    60,
    30,
    (s, v) => {
      const y = lerp(POCKET.y0, POCKET.y1, v);
      return bodyPoint(pocketTheta(s, y), y, 0.009 + 0.006 * Math.sin(s * Math.PI));
    },
    [5, 3],
    false,
  );
}

export function pocketEdgeCurves() {
  const pts = (fn: (k: number) => THREE.Vector3, n = 24) =>
    new THREE.CatmullRomCurve3(Array.from({ length: n + 1 }, (_, k) => fn(k / n)));
  const at = (s: number, y: number) =>
    bodyPoint(pocketTheta(s, y), y, 0.012 + 0.006 * Math.sin(s * Math.PI));
  return [
    pts((k) => at(k, POCKET.y1)), // top
    pts((k) => at(0, lerp(POCKET.y0, POCKET.y1, k))), // left opening
    pts((k) => at(1, lerp(POCKET.y0, POCKET.y1, k))), // right opening
  ];
}

/* ── Drawcords ───────────────────────────────────────────────────────── */

export function cordCurve(side: 1 | -1) {
  const pts = [0.7, 0.6, 0.48, 0.36, 0.24].map((y, i) => {
    const p = bodyPoint(lerp(0.2, 0.13, i / 4) * side, y, 0.016 + i * 0.002);
    p.x += 0.006 * side * i;
    return p;
  });
  return new THREE.CatmullRomCurve3(pts);
}

export function eyeletPosition(side: 1 | -1) {
  return bodyPoint(0.2 * side, 0.7, 0.004);
}

"use client";

import { useMemo } from "react";
import * as THREE from "three";
import { useTexture } from "@react-three/drei";
import {
  cordCurve,
  eyeletPosition,
  hoodEdgeCurve,
  makeBody,
  makeArtPatch,
  makeBodyLining,
  makeHood,
  makePocket,
  makeSleeve,
  pocketEdgeCurves,
} from "./geometry";

export const FABRIC = "#ebe5da";
const LINING = "#cfc7b9";
const THREAD = "#121110";

// Artwork extracted from the client's mockup (not redrawn). Aspect = width / height.
const FRONT_ASPECT = 1392 / 1328;
const BACK_ASPECT = 1376 / 2456;

export function Hoodie() {
  const [frontArt, frontNormal, backArt, backNormal, knit] = useTexture([
    "/art/front-mark.png",
    "/art/front-mark-normal.png",
    "/art/back-art.png",
    "/art/back-art-normal.png",
    "/art/knit-normal.png",
  ]);

  const parts = useMemo(() => {
    knit.wrapS = knit.wrapT = THREE.RepeatWrapping;
    const fabric = new THREE.MeshPhysicalMaterial({
      color: FABRIC,
      roughness: 0.93,
      sheen: 0.55,
      sheenRoughness: 0.7,
      sheenColor: new THREE.Color("#fffaf0"),
      normalMap: knit,
      normalScale: new THREE.Vector2(0.45, 0.45),
      side: THREE.FrontSide,
    });
    const lining = new THREE.MeshStandardMaterial({
      color: LINING,
      roughness: 1,
      side: THREE.BackSide,
    });
    const hoodMat = fabric.clone();
    hoodMat.side = THREE.DoubleSide;
    const black = new THREE.MeshStandardMaterial({ color: "#0e0e0e", roughness: 0.35, metalness: 0.6 });
    const aglet = new THREE.MeshStandardMaterial({ color: "#0b0b0b", roughness: 0.45 });
    const cord = new THREE.MeshPhysicalMaterial({
      color: "#f1ece4",
      roughness: 0.8,
      sheen: 1,
      sheenColor: new THREE.Color("#ffffff"),
    });

    const body = makeBody();
    const bodyLining = makeBodyLining();
    const sleeves = ([1, -1] as const).map((s) => makeSleeve(s));
    const hood = makeHood();
    const hoodLip = new THREE.TubeGeometry(hoodEdgeCurve(), 80, 0.022, 10, false);
    const pocket = makePocket();
    const pocketSeams = pocketEdgeCurves().map((c) => new THREE.TubeGeometry(c, 48, 0.006, 6, false));
    const cords = ([1, -1] as const).map((s) => {
      const curve = cordCurve(s);
      const end = curve.getPointAt(1);
      const tan = curve.getTangentAt(1);
      return { geo: new THREE.TubeGeometry(curve, 40, 0.011, 8, false), end, tan };
    });
    const neckRing = new THREE.TorusGeometry(1, 0.11, 10, 64);
    // Artwork placement approximated from the mockup.
    const frontPatch = makeArtPatch(0.08, 0.34, 0.17, 0.4, 0.4 / FRONT_ASPECT);
    const backPatch = makeArtPatch(Math.PI, 0, -0.28, 1.22 * BACK_ASPECT, 1.22);

    return { fabric, lining, hoodMat, black, aglet, cord, body, bodyLining, sleeves, hood, hoodLip, pocket, pocketSeams, cords, neckRing, frontPatch, backPatch };
  }, [knit]);

  for (const t of [frontArt, backArt]) t.colorSpace = THREE.SRGBColorSpace;
  for (const t of [frontArt, backArt, frontNormal, backNormal]) t.anisotropy = 8;

  const embroidery = (map: THREE.Texture, normal: THREE.Texture) => (
    <meshPhysicalMaterial
      map={map}
      normalMap={normal}
      normalScale={new THREE.Vector2(1.4, 1.4)}
      color={THREAD}
      roughness={0.42}
      sheen={0.6}
      sheenColor="#5a5550"
      transparent
      side={THREE.DoubleSide}
      alphaTest={0.08}
      depthWrite={false}
      polygonOffset
      polygonOffsetFactor={-2}
    />
  );

  const sleeveCap = (end: THREE.Vector3, tan: THREE.Vector3, key: string) => {
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), tan.clone().normalize());
    return (
      <mesh key={key} position={end} quaternion={q} material={parts.lining}>
        <cylinderGeometry args={[0.105, 0.105, 0.01, 32, 1, true]} />
      </mesh>
    );
  };

  return (
    <group>
      {/* body */}
      <mesh geometry={parts.body} material={parts.fabric} castShadow receiveShadow />
      {/* embroidery: wearer's left chest, and full back */}
      <mesh geometry={parts.frontPatch}>{embroidery(frontArt, frontNormal)}</mesh>
      <mesh geometry={parts.backPatch}>{embroidery(backArt, backNormal)}</mesh>
      <mesh geometry={parts.bodyLining} material={parts.lining} />

      {/* sleeves */}
      {parts.sleeves.map((s, i) => (
        <group key={i}>
          <mesh geometry={s.geo} material={parts.fabric} castShadow receiveShadow />
          {sleeveCap(s.end, s.tangent, `cap${i}`)}
        </group>
      ))}

      {/* neck rib */}
      <mesh geometry={parts.neckRing} material={parts.fabric} position={[0, 0.8, 0]} rotation={[Math.PI / 2, 0, 0]} scale={[0.215, 0.175, 0.2]} />

      {/* hood, resting back */}
      <group position={[0, 0.78, -0.08]} rotation={[-1.18, 0, 0]} scale={[1, 1, 0.7]}>
        <mesh geometry={parts.hood} material={parts.hoodMat} castShadow receiveShadow />
        <mesh geometry={parts.hoodLip} material={parts.fabric} castShadow />
      </group>

      {/* kangaroo pocket */}
      <mesh geometry={parts.pocket} material={parts.fabric} castShadow receiveShadow />
      {parts.pocketSeams.map((g, i) => (
        <mesh key={i} geometry={g} material={parts.fabric} />
      ))}

      {/* eyelets, drawcords, aglets */}
      {([1, -1] as const).map((s, i) => {
        const p = eyeletPosition(s);
        const c = parts.cords[i];
        const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), c.tan.clone().normalize());
        return (
          <group key={s}>
            <mesh position={p} rotation={[0.25, 0.22 * s, 0]} material={parts.black}>
              <torusGeometry args={[0.018, 0.0065, 12, 32]} />
            </mesh>
            <mesh geometry={c.geo} material={parts.cord} castShadow />
            <mesh position={c.end.clone().addScaledVector(c.tan, 0.03)} quaternion={q} material={parts.aglet} castShadow>
              <cylinderGeometry args={[0.0135, 0.0125, 0.075, 16]} />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

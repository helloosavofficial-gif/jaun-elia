import { PENDING } from "@/content/products";
import styles from "./InfoPage.module.css";

/**
 * Layout for the supporting pages (about, help, legal): an editorial title,
 * an optional draft notice, and a readable column of sections.
 */
export function InfoPage({
  kicker,
  title,
  intro,
  draftNote,
  children,
}: {
  kicker: string;
  title: string;
  intro?: React.ReactNode;
  /** Shown as a notice while the page awaits client details or review. */
  draftNote?: string;
  children: React.ReactNode;
}) {
  return (
    <main id="main" tabIndex={-1} className={styles.page}>
      <header className={styles.head}>
        <p className={styles.kicker}>{kicker}</p>
        <h1 className={styles.title}>{title}</h1>
        {intro && <div className={styles.intro}>{intro}</div>}
      </header>
      {draftNote && (
        <p className={styles.draft} role="note">
          <strong>Draft.</strong> {draftNote}
        </p>
      )}
      <div className={styles.body}>{children}</div>
    </main>
  );
}

/** One titled section of an info page. */
export function InfoSection({ title, id, children }: { title: string; id?: string; children: React.ReactNode }) {
  return (
    <section className={styles.section} id={id} aria-labelledby={id ? `${id}-title` : undefined}>
      <h2 id={id ? `${id}-title` : undefined}>{title}</h2>
      <div className={styles.sectionBody}>{children}</div>
    </section>
  );
}

/** Label/value rows; a null value shows PENDING, styled as pending. */
export function InfoRows({ rows }: { rows: [label: string, value: string | null][] }) {
  return (
    <dl className={styles.rows}>
      {rows.map(([label, value]) => (
        <div key={label}>
          <dt>{label}</dt>
          <dd data-pending={value === null}>{value ?? PENDING}</dd>
        </div>
      ))}
    </dl>
  );
}

"use client";

import { useEffect, useRef } from "react";
import { prefersReduced } from "@/lib/motion";

type Props = {
  src: string;
  poster: string;
  label: string;
  className?: string;
  /** Wait for the campaign intro's curtain (the "intro:done" event) before playing. */
  afterIntro?: boolean;
};

/**
 * A short muted film that plays once and rests on its last frame — it never
 * loops. With ?motion=off it stays on the poster; if the browser refuses
 * autoplay, the poster simply stays.
 */
export function FilmOnce({ src, poster, label, className, afterIntro = false }: Props) {
  const ref = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    if (prefersReduced()) {
      video.pause();
      return;
    }
    video.muted = true;
    const play = () => {
      video.play()?.catch(() => {});
    };
    if (!afterIntro || document.documentElement.hasAttribute("data-intro-done")) {
      play();
      return;
    }
    window.addEventListener("intro:done", play, { once: true });
    return () => window.removeEventListener("intro:done", play);
  }, [afterIntro]);

  return (
    <video
      ref={ref}
      className={className}
      src={src}
      poster={poster}
      autoPlay={!afterIntro}
      muted
      playsInline
      preload="auto"
      disablePictureInPicture
      aria-label={label}
    />
  );
}

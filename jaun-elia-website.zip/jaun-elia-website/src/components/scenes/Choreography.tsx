"use client";

import { useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { site } from "@/content/site";
import { prefersCalmerMotion, prefersReduced, range } from "@/lib/motion";

gsap.registerPlugin(ScrollTrigger);

const ROTATION_FROM = 0.06;
const ROTATION_TO = 0.94;

/**
 * Every scroll-driven movement on the page, in one place.
 * Native scrolling throughout — nothing is hijacked; GSAP only scrubs
 * transforms, opacity and clip-paths against each scene's scroll range.
 * Under reduced motion none of this runs and the CSS shows each scene resolved.
 */
export function Choreography() {
  useEffect(() => {
    const reduced = prefersReduced();
    document.documentElement.toggleAttribute("data-reduced-motion", reduced);
    if (process.env.NODE_ENV !== "production") {
      // dev-only handles for debugging motion from the console
      Object.assign(window, { __gsap: gsap, __ST: ScrollTrigger });
    }
    if (reduced) return;

    const mm = gsap.matchMedia();

    mm.add({ desktop: "(min-width: 1024px)", mobile: "(max-width: 1023px)" }, (ctx) => {
      const mobile = Boolean(ctx.conditions?.mobile);
      const scrub = (trigger: string, extra: ScrollTrigger.Vars = {}) => ({
        trigger,
        start: "top top",
        end: "bottom bottom",
        scrub: 0.5,
        ...extra,
      });

      /* ── HERO ───────────────────────────────────────────────────────
         Waits for the intro's curtain: the hoodie steps forward out of the
         studio, then the title rises and the line beneath settles. */
      gsap.set("[data-scene='hero'] [data-rise]", { yPercent: 110 });
      gsap.set("[data-hfade]", { opacity: 0, y: 14 });
      gsap.set("[data-hero-media]", { opacity: 0, scale: 0.94 });
      const enter = () =>
        gsap
          .timeline({ defaults: { ease: "expo.out" } })
          .to("[data-hero-media]", { opacity: 1, scale: 1, duration: 2 }, 0)
          .to("[data-scene='hero'] [data-rise]", { yPercent: 0, duration: 1.4 }, 0.3)
          .to("[data-hfade]", { opacity: 1, y: 0, duration: 1.1, stagger: 0.12 }, 0.6);
      if (document.documentElement.hasAttribute("data-intro-done")) enter();
      else window.addEventListener("intro:done", enter, { once: true });

      /* ── Headlines rise as their section arrives ── */
      gsap.utils.toArray<HTMLElement>("[data-scene]:not([data-scene='hero']) h2").forEach((h2) => {
        const lines = h2.querySelectorAll("[data-rise]");
        if (!lines.length) return;
        gsap.fromTo(
          lines,
          { yPercent: 110 },
          { yPercent: 0, duration: 1.3, stagger: 0.1, ease: "expo.out", scrollTrigger: { trigger: h2, start: "top 88%" } },
        );
      });
      gsap.utils.toArray<HTMLElement>("[data-sfade]").forEach((el) => {
        gsap.fromTo(
          el,
          { opacity: 0, y: 22 },
          { opacity: 1, y: 0, duration: 1.1, ease: "expo.out", scrollTrigger: { trigger: el, start: "top 90%" } },
        );
      });

      /* ── Product cards arrive one after another ── */
      gsap.fromTo(
        "[data-card]",
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 1.1,
          stagger: 0.08,
          ease: "expo.out",
          scrollTrigger: { trigger: "[data-scene='row']", start: "top 78%" },
        },
      );

      /* ── Campaign banners drift behind their type ── */
      gsap.utils.toArray<HTMLElement>("[data-banner-image]").forEach((el) => {
        gsap.fromTo(
          el,
          { yPercent: -5 },
          {
            yPercent: 5,
            ease: "none",
            scrollTrigger: { trigger: el.parentElement, start: "top bottom", end: "bottom top", scrub: true },
          },
        );
      });

      /* ── The calligraphy is drawn down like ink ── */
      gsap
        .timeline({ scrollTrigger: { trigger: "[data-callig-image]", start: "top 85%", end: "center 55%", scrub: 0.6 } })
        .fromTo("[data-callig-image]", { clipPath: "inset(0% 0% 100% 0%)" }, { clipPath: "inset(0% 0% 0% 0%)", ease: "power2.inOut" }, 0)
        .fromTo("[data-callig-image] img", { scale: 1.14 }, { scale: 1, ease: "power2.out" }, 0);

      /* ── 03 IN MOTION ───────────────────────────────────────────────
         The garment steps out of the dark; scroll drives the rotation
         (FrameSequence). The readout, the view list, the rail and the ghost
         word behind the garment all follow the same scroll position. */
      gsap
        .timeline({ scrollTrigger: scrub("[data-scene='motion']") })
        .fromTo("[data-stage]", { opacity: 0, scale: 0.86 }, { opacity: 1, scale: 1, ease: "power2.out", duration: 0.07 }, 0)
        .fromTo("[data-view-ghost]", { opacity: 0 }, { opacity: 1, duration: 0.08 }, 0.02)
        .fromTo("[data-motion-copy]", { opacity: 0, y: 32 }, { opacity: 1, y: 0, duration: 0.06 }, 0.02)
        .to("[data-motion-copy]", { opacity: mobile ? 0.0 : 0.25, y: -24, duration: 0.08 }, mobile ? 0.2 : 0.42)
        .to("[data-stage]", { opacity: 0, scale: 0.94, duration: 0.05 }, 0.95);

      const deg = document.querySelector<HTMLElement>("[data-degrees]");
      const ghost = document.querySelector<HTMLElement>("[data-view-ghost]");
      const rail = document.querySelector<HTMLElement>("[data-rail]");
      const items = gsap.utils.toArray<HTMLElement>("[data-view]");
      let lastView = "";
      ScrollTrigger.create({
        ...scrub("[data-scene='motion']"),
        scrub: false,
        onUpdate: (self) => {
          const p = range(self.progress, ROTATION_FROM, ROTATION_TO);
          if (deg) deg.textContent = `${String(Math.round(p * 360)).padStart(3, "0")}°`;
          if (rail) rail.style.transform = `scaleX(${p})`;
          const t = p * 8;
          const view = site.motion.views.find((v) => t >= v.from && t < v.to)?.label ?? "Front";
          if (view !== lastView) {
            lastView = view;
            if (ghost) ghost.textContent = view;
            items.forEach((li) => (li.dataset.active = String(li.dataset.view === view)));
          }
        },
      });

      /* ── WORN — photographs open from a sliver and drift ── */
      gsap.utils.toArray<HTMLElement>("[data-clip]").forEach((el) => {
        gsap.fromTo(
          el,
          { clipPath: "inset(22% 0% 22% 0%)" },
          {
            clipPath: "inset(0% 0% 0% 0%)",
            ease: "power3.out",
            scrollTrigger: { trigger: el, start: "top 95%", end: "top 45%", scrub: 0.5 },
          },
        );
      });
      // parallax drift is decorative: skipped when the OS asks for reduced motion
      if (!prefersCalmerMotion())
        gsap.utils.toArray<HTMLElement>("[data-par]").forEach((el) => {
          const a = parseFloat(el.dataset.par ?? "0.08") * 100;
          gsap.fromTo(
            el,
            { yPercent: -a / 2 },
            {
              yPercent: a / 2,
              ease: "none",
              scrollTrigger: { trigger: el.parentElement, start: "top bottom", end: "bottom top", scrub: true },
            },
          );
        });
    });

    // layout settles once fonts and images arrive
    const refresh = () => ScrollTrigger.refresh();
    window.addEventListener("load", refresh);
    document.fonts?.ready.then(refresh);

    return () => {
      window.removeEventListener("load", refresh);
      mm.revert();
    };
  }, []);

  return null;
}

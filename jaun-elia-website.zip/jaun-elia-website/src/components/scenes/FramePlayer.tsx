"use client";

import { useEffect, useRef } from "react";
import { sequences } from "@/content/site";

type Props = {
  name: keyof typeof sequences;
  /** Frames per second. */
  fps?: number;
  /** Plays forward then back, so short footage loops without a jump. */
  pingPong?: boolean;
  /** Start playing as soon as frames are ready (otherwise call via `playing`). */
  playing?: boolean;
  className?: string;
  /** Called once the first frame is on screen. */
  onReady?: () => void;
};

/**
 * Plays an image sequence (frames extracted from supplied footage) on a
 * canvas like a muted, looping film, filling its box (object-fit: cover).
 * Pauses when off screen or when `playing` is false.
 */
export function FramePlayer({ name, fps = 18, pingPong = true, playing = true, className, onReady }: Props) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const playingRef = useRef(playing);
  playingRef.current = playing;
  const readyRef = useRef(onReady);
  readyRef.current = onReady;

  useEffect(() => {
    const c = canvas.current;
    const ctx = c?.getContext("2d");
    if (!c || !ctx) return;
    const seq = sequences[name];
    const src = window.innerWidth < 768 ? seq.sm : seq.lg;
    const frames: (HTMLImageElement | null)[] = new Array(seq.count).fill(null);
    let disposed = false;
    let visible = true;
    let raf = 0;
    let last = 0;
    let pos = 0;
    let dir = 1;
    let shown = -1;
    let announced = false;

    const draw = (i: number) => {
      const img = frames[i];
      if (!img || !c.width) return;
      const s = Math.max(c.width / img.naturalWidth, c.height / img.naturalHeight);
      const w = img.naturalWidth * s;
      const h = img.naturalHeight * s;
      ctx.drawImage(img, (c.width - w) / 2, (c.height - h) / 2, w, h);
      shown = i;
      if (!announced) {
        announced = true;
        readyRef.current?.();
      }
    };

    const resize = () => {
      const r = c.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      c.width = Math.round(r.width * dpr);
      c.height = Math.round(r.height * dpr);
      if (shown >= 0) draw(shown);
    };
    const ro = new ResizeObserver(resize);
    ro.observe(c);
    const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting));
    io.observe(c);

    // load in order; playback waits for the frame it needs
    (async () => {
      for (let i = 0; i < seq.count && !disposed; i++) {
        await new Promise<void>((resolve) => {
          const img = new Image();
          img.decoding = "async";
          img.onload = () => {
            frames[i] = img;
            if (i === 0) draw(0);
            resolve();
          };
          img.onerror = () => resolve();
          img.src = src(i);
        });
      }
    })();

    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      if (!visible || !playingRef.current || now - last < 1000 / fps) return;
      last = now;
      let next = pos + dir;
      if (next >= seq.count || next < 0) {
        if (pingPong) {
          dir = -dir;
          next = pos + dir;
        } else next = 0;
      }
      if (!frames[next]) return; // not loaded yet
      pos = next;
      draw(pos);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
    };
  }, [name, fps, pingPong]);

  return <canvas ref={canvas} className={className} aria-hidden />;
}

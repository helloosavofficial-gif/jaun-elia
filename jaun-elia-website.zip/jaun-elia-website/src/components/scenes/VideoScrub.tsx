"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { prefersReduced, range } from "@/lib/motion";
import { FrameSequence } from "./FrameSequence";
import styles from "./VideoScrub.module.css";

gsap.registerPlugin(ScrollTrigger);

type Props = {
  src: string;
  poster: string;
  /** CSS selector of the section whose scroll range drives the video. */
  trigger: string;
  /** Portion of the section's scroll progress mapped onto 0 → duration. */
  from?: number;
  to?: number;
  alt: string;
  className?: string;
};

/** Median seek time above which this browser falls back to image frames. */
const SLOW_SEEK_MS = 140;
const SEEK_SAMPLES = 12;
/** A seek that never completes also triggers the fallback. */
const SEEK_TIMEOUT_MS = 2000;

/**
 * Scroll-scrubbed video: the section's scroll progress sets video.currentTime.
 *
 * - Never plays on its own (no autoplay, paused on any stray play).
 * - Waits for loadedmetadata, then time = progress × duration.
 * - One seek in flight at a time: a new target is applied on `seeked`, so seeks
 *   never pile up and fast scrolling simply lands on the latest position.
 * - Works in both directions; the file is encoded with a keyframe every 4
 *   frames and no B-frames, so any seek decodes at most 4 frames.
 * - Measures real seek times; if this browser seeks slowly (median over
 *   SLOW_SEEK_MS, a stalled seek, or an error) it swaps to the image-frame
 *   sequence extracted from the same footage.
 */
export function VideoScrub({ src, poster, trigger, from = 0, to = 1, alt, className }: Props) {
  const ref = useRef<HTMLVideoElement>(null);
  const [mode, setMode] = useState<"video" | "frames">("video");

  useEffect(() => {
    if (mode !== "video") return;
    const v = ref.current;
    if (!v) return;

    let disposed = false;
    let duration = 0;
    let progress = 0;
    let seeking = false;
    let seekStart = 0;
    let watchdog = 0;
    let priming = false;
    const samples: number[] = [];

    const fallback = () => {
      if (!disposed) setMode("frames");
    };

    const apply = () => {
      if (disposed || !duration || seeking) return;
      const t = Math.min(progress * duration, duration - 0.001);
      if (Math.abs(v.currentTime - t) < 1 / 48) return; // already within half a frame
      seeking = true;
      seekStart = performance.now();
      window.clearTimeout(watchdog);
      watchdog = window.setTimeout(fallback, SEEK_TIMEOUT_MS);
      v.currentTime = t;
    };

    const onSeeked = () => {
      window.clearTimeout(watchdog);
      seeking = false;
      v.dataset.scrubTime = v.currentTime.toFixed(3);
      if (samples.length < SEEK_SAMPLES) {
        samples.push(performance.now() - seekStart);
        if (samples.length === SEEK_SAMPLES) {
          const median = [...samples].sort((a, b) => a - b)[SEEK_SAMPLES >> 1];
          v.dataset.seekMedianMs = median.toFixed(1);
          if (median > SLOW_SEEK_MS) return fallback();
        }
      }
      apply(); // catch up with wherever the scroll is now
    };

    const onMeta = () => {
      duration = v.duration;
      v.dataset.duration = duration.toFixed(3);
      // iOS will not decode frames for seeking until the video has played once
      if (v.readyState < 2) {
        priming = true;
        v.play()
          .then(() => v.pause())
          .catch(() => undefined)
          .finally(() => {
            priming = false;
            apply();
          });
      } else {
        apply();
      }
    };

    // scroll owns the timeline: no playback competing with it
    const onPlay = () => {
      if (!priming) v.pause();
    };

    v.muted = true;
    v.pause();
    v.addEventListener("loadedmetadata", onMeta);
    v.addEventListener("seeked", onSeeked);
    v.addEventListener("play", onPlay);
    v.addEventListener("error", fallback);
    if (v.readyState >= 1) onMeta();

    // buffer the whole file only once the section is about a screen away
    const near = ScrollTrigger.create({
      trigger,
      start: "top bottom+=100%",
      once: true,
      onEnter: () => {
        v.preload = "auto";
      },
    });

    let st: ScrollTrigger | null = null;
    if (!prefersReduced()) {
      st = ScrollTrigger.create({
        trigger,
        start: "top top",
        end: "bottom bottom",
        onUpdate: (self) => {
          progress = range(self.progress, from, to);
          apply();
        },
        onRefresh: (self) => {
          progress = range(self.progress, from, to);
          apply();
        },
      });
    }

    return () => {
      disposed = true;
      window.clearTimeout(watchdog);
      v.removeEventListener("loadedmetadata", onMeta);
      v.removeEventListener("seeked", onSeeked);
      v.removeEventListener("play", onPlay);
      v.removeEventListener("error", fallback);
      near.kill();
      st?.kill();
    };
  }, [mode, trigger, from, to]);

  if (mode === "frames") {
    return (
      <FrameSequence name="rotation" trigger={trigger} from={from} to={to} alt={alt} className={className} />
    );
  }

  return (
    <div className={`${styles.wrap} ${className ?? ""}`}>
      <video
        ref={ref}
        className={styles.video}
        src={src}
        poster={poster}
        muted
        playsInline
        preload="metadata"
        disablePictureInPicture
        disableRemotePlayback
        tabIndex={-1}
        aria-label={alt}
        data-scrub-video
      />
    </div>
  );
}

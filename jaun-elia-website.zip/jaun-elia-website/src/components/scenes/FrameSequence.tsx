"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { prefersReduced, range } from "@/lib/motion";
import { sequences } from "@/content/site";
import styles from "./FrameSequence.module.css";

gsap.registerPlugin(ScrollTrigger);

type Props = {
  /** Which extracted sequence to play (see `sequences` in content/site.ts). */
  name: keyof typeof sequences;
  /** CSS selector of the element whose scroll range drives the sequence. */
  trigger: string;
  start?: string;
  end?: string;
  /** Portion of the trigger's progress that maps onto the whole sequence. */
  from?: number;
  to?: number;
  fit?: "contain" | "cover";
  /** Frame shown when motion is reduced. */
  stillIndex?: number;
  alt: string;
  className?: string;
};

const CONCURRENCY = 6;

/**
 * Scroll-scrubbed image sequence drawn to a canvas.
 *
 * Frames extracted from the supplied videos, because compressed video cannot
 * seek smoothly in reverse (keyframe spacing) and seeks poorly on iOS. Here
 * scrolling forward or backward simply picks a frame; nothing autoplays.
 *
 * - Loads only when near the viewport, coarse-to-fine (every 16th frame first),
 *   and always draws the nearest frame already loaded — never a blank frame.
 * - Smaller frames on narrow screens.
 * - One rAF loop that eases toward the scroll target and stops when it arrives;
 *   no React state changes while scrolling.
 * - The poster image stays visible until the first frame is drawn, and remains
 *   as the fallback if frames fail to load.
 */
export function FrameSequence({
  name,
  trigger,
  start = "top top",
  end = "bottom bottom",
  from = 0,
  to = 1,
  fit = "contain",
  stillIndex = 0,
  alt,
  className,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [ready, setReady] = useState(false);
  const seq = sequences[name];

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    const reduced = prefersReduced();
    const src = window.innerWidth < 768 ? seq.sm : seq.lg;
    const last = seq.count - 1;
    const images: (HTMLImageElement | null)[] = new Array(seq.count).fill(null);
    const loaded = new Uint8Array(seq.count);
    let disposed = false;
    let drawn = -1;
    let current = reduced ? stillIndex / last : 0;
    let target = current;
    let raf = 0;
    let isReady = false;

    const nearestLoaded = (want: number) => {
      for (let d = 0; d <= last; d++) {
        if (want - d >= 0 && loaded[want - d]) return want - d;
        if (want + d <= last && loaded[want + d]) return want + d;
      }
      return -1;
    };

    const draw = () => {
      const i = nearestLoaded(Math.round(current * last));
      if (i < 0 || i === drawn) return;
      const img = images[i]!;
      const cw = canvas.width;
      const ch = canvas.height;
      if (!cw || !ch) return;
      const scale =
        fit === "contain"
          ? Math.min(cw / img.naturalWidth, ch / img.naturalHeight)
          : Math.max(cw / img.naturalWidth, ch / img.naturalHeight);
      const w = img.naturalWidth * scale;
      const h = img.naturalHeight * scale;
      ctx.clearRect(0, 0, cw, ch);
      ctx.drawImage(img, (cw - w) / 2, (ch - h) / 2, w, h);
      drawn = i;
      if (!isReady) {
        isReady = true;
        setReady(true);
      }
    };

    const tick = () => {
      raf = 0;
      const diff = target - current;
      if (Math.abs(diff) > 0.0008) {
        current += diff * 0.22;
        raf = requestAnimationFrame(tick);
      } else {
        current = target;
      }
      draw();
    };
    const kick = () => {
      if (!raf) raf = requestAnimationFrame(tick);
    };

    const resize = () => {
      const r = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(r.width * dpr);
      canvas.height = Math.round(r.height * dpr);
      drawn = -1;
      draw();
    };
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const load = (i: number) =>
      new Promise<void>((resolve) => {
        if (images[i]) return resolve();
        const img = new Image();
        img.decoding = "async";
        images[i] = img;
        img.onload = () => {
          loaded[i] = 1;
          if (!disposed) draw();
          resolve();
        };
        img.onerror = () => resolve();
        img.src = src(i);
      });

    // coarse-to-fine order so the whole range is scrubbable early
    const order: number[] = [];
    const seen = new Set<number>();
    const push = (i: number) => {
      if (!seen.has(i)) {
        seen.add(i);
        order.push(i);
      }
    };
    push(reduced ? stillIndex : 0);
    if (!reduced) for (const stride of [16, 8, 4, 2, 1]) for (let i = 0; i <= last; i += stride) push(i);

    let started = false;
    const startLoading = () => {
      if (started) return;
      started = true;
      let k = 0;
      const worker = async () => {
        while (k < order.length && !disposed) await load(order[k++]);
      };
      for (let n = 0; n < CONCURRENCY; n++) worker();
    };
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          startLoading();
          io.disconnect();
        }
      },
      { rootMargin: "150% 0px" },
    );
    io.observe(canvas);

    let st: ScrollTrigger | null = null;
    if (!reduced) {
      st = ScrollTrigger.create({
        trigger,
        start,
        end,
        onUpdate: (self) => {
          target = range(self.progress, from, to);
          kick();
        },
        onRefresh: (self) => {
          target = range(self.progress, from, to);
          current = target;
          drawn = -1;
          draw();
        },
      });
    }

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      st?.kill();
    };
  }, [seq, trigger, start, end, from, to, fit, stillIndex]);

  return (
    <div className={`${styles.wrap} ${className ?? ""}`} data-ready={ready} data-fit={fit} role="img" aria-label={alt}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img className={styles.poster} src={seq.poster} alt="" aria-hidden decoding="async" />
      <canvas ref={canvasRef} className={styles.canvas} aria-hidden />
    </div>
  );
}

"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { site } from "@/content/site";
import { prefersReduced } from "@/lib/motion";
import { lockScroll, unlockScroll } from "@/lib/scroll";
import { FramePlayer } from "./FramePlayer";
import styles from "./Intro.module.css";

/** Played already in this page's lifetime (in-site navigation back home skips it). */
let playedThisLoad = false;
/** Where the curtain starts; Skip jumps here. */
const CURTAIN_AT = 3.1;

/** Tells the hero (and anything else waiting) that the page is uncovered. */
function announceDone() {
  document.documentElement.setAttribute("data-intro-done", "");
  window.dispatchEvent(new Event("intro:done"));
}

/**
 * The opening film (about 3.75 s, always under 4), once per visit.
 *   I   Thread — close-up footage of drawcords, eyelets and cuffs
 *   II  Letter — the real chest calligraphy, a stitch line drawing round it
 *   III Wear   — the hoodie turning
 * then the curtain opens onto the page (the hero carries the title).
 * Words sit beside the picture, never on it. Plays on every fresh
 * load of the home page (not when returning by in-site navigation).
 * Skippable (button or Escape); skipped with ?motion=off.
 * When real making-of footage exists, set site.intro.film to play it instead
 * of chapters I–III. A CSS fail-safe removes the intro if scripts stall.
 */
export function Intro() {
  const root = useRef<HTMLDivElement>(null);
  const turn = useRef<HTMLVideoElement>(null);
  const film = useRef<HTMLVideoElement>(null);
  const chapter = useRef<HTMLSpanElement>(null);
  const tl = useRef<gsap.core.Timeline | null>(null);
  // returning home in-site: render nothing at all (no flash of the curtain)
  const [gone, setGone] = useState(() => playedThisLoad);
  const [threadPlaying, setThreadPlaying] = useState(false);
  const intro = site.intro;

  useEffect(() => {
    const el = root.current;
    if (!el || playedThisLoad || prefersReduced()) {
      setGone(true);
      announceDone();
      return;
    }

    playedThisLoad = true;
    lockScroll();
    const q = gsap.utils.selector(el);
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      unlockScroll();
      setGone(true);
    };

    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const mobile = vw < 768;
    // frame sizes per chapter
    const wide = { width: Math.min(vw * (mobile ? 0.88 : 0.62), 1080), height: 0 };
    wide.height = wide.width * (9 / 16);
    const portrait = { height: vh * (mobile ? 0.5 : 0.56), width: 0 };
    portrait.width = portrait.height * 0.8;
    const tall = { height: vh * (mobile ? 0.56 : 0.66), width: 0 };
    tall.width = tall.height * 0.5625;

    const setChapter = (n: string) => () => {
      if (chapter.current) chapter.current.textContent = n;
    };
    const t = gsap.timeline({ defaults: { ease: "expo.out" }, onComplete: finish });
    t.set(q("[data-i='frame']"), { width: wide.width, height: 2 })
      .set(q("[data-i='word'] span"), { yPercent: 110 })
      .set(q("[data-i='count']"), { opacity: 0 })
      // the label, then the frame opens from a hairline
      .fromTo(q("[data-i='label']"), { opacity: 0, letterSpacing: "0.9em" }, { opacity: 1, letterSpacing: "0.5em", duration: 0.9 }, 0.05)
      .to(q("[data-i='frame']"), { height: wide.height, duration: 0.6, ease: "power4.inOut" }, 0.15);

    if (intro.film) {
      // real making-of footage replaces chapters I–III
      t.to(q("[data-i='film']"), { opacity: 1, duration: 0.4 }, 0.55)
        .add(() => {
          film.current?.play().catch(() => undefined);
        }, 0.55)
        .to(q("[data-i='word'][data-n='1'] span"), { yPercent: 0, duration: 0.7 }, 0.7);
    } else {
      t
        // I — Thread
        .add(() => setThreadPlaying(true), 0.4)
        .to(q("[data-m='thread']"), { opacity: 1, duration: 0.4 }, 0.5)
        .to(q("[data-i='count']"), { opacity: 1, duration: 0.4 }, 0.55)
        .to(q("[data-i='word'][data-n='1'] span"), { yPercent: 0, duration: 0.7 }, 0.6)
        .to(q("[data-i='word'][data-n='1'] span"), { yPercent: -110, duration: 0.4, ease: "power3.in" }, 1.25)
        // II — Letter: the frame turns portrait onto the calligraphy
        .to(q("[data-m='thread']"), { opacity: 0, duration: 0.35 }, 1.3)
        .to(q("[data-i='frame']"), { width: portrait.width, height: portrait.height, duration: 0.6, ease: "power4.inOut" }, 1.3)
        .fromTo(q("[data-m='letter']"), { opacity: 0, scale: 1.2 }, { opacity: 1, scale: 1.05, duration: 1.2, ease: "power2.out" }, 1.45)
        .add(setChapter("II"), 1.4)
        .set(q("[data-i='stitchBox']"), { opacity: 1 }, 1.5)
        .fromTo(q("[data-i='stitch']"), { strokeDashoffset: 1 }, { strokeDashoffset: 0, duration: 0.8, ease: "power2.inOut" }, 1.55)
        .to(q("[data-i='word'][data-n='2'] span"), { yPercent: 0, duration: 0.7 }, 1.6)
        .to(q("[data-i='word'][data-n='2'] span"), { yPercent: -110, duration: 0.4, ease: "power3.in" }, 2.15)
        // III — Wear: the hoodie turns
        .to(q("[data-m='letter'], [data-i='stitchBox']"), { opacity: 0, duration: 0.35 }, 2.2)
        .to(q("[data-i='frame']"), { width: tall.width, height: tall.height, duration: 0.6, ease: "power4.inOut" }, 2.2)
        .add(() => {
          const v = turn.current;
          if (v) {
            v.currentTime = 0;
            v.play().catch(() => undefined);
          }
        }, 2.25)
        .add(setChapter("III"), 2.3)
        .to(q("[data-m='turn']"), { opacity: 1, duration: 0.4 }, 2.35)
        .to(q("[data-i='word'][data-n='3'] span"), { yPercent: 0, duration: 0.7 }, 2.45);
    }

    t
      // the curtain opens straight onto the hero, which carries the title
      .to(q("[data-i='words'], [data-i='count'], [data-i='label']"), { opacity: 0, duration: 0.3 }, CURTAIN_AT - 0.2)
      .to(q("[data-i='frame']"), { opacity: 0, scale: 0.96, duration: 0.35, ease: "power3.in" }, CURTAIN_AT - 0.2)
      .to(q("[data-i='chrome']"), { opacity: 0, duration: 0.2 }, CURTAIN_AT - 0.15)
      .add(announceDone, CURTAIN_AT + 0.1)
      .to(q("[data-i='top']"), { yPercent: -101, duration: 0.65, ease: "power4.inOut" }, CURTAIN_AT)
      .to(q("[data-i='bottom']"), { yPercent: 101, duration: 0.65, ease: "power4.inOut" }, CURTAIN_AT);
    tl.current = t;
    if (process.env.NODE_ENV !== "production") {
      // dev-only handle for checking the intro's length from the console
      Object.assign(window, { __intro: t });
    }

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && t.time() < CURTAIN_AT) t.seek(CURTAIN_AT);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      t.kill();
      if (!finished) unlockScroll();
    };
  }, [intro.film]);

  const skip = () => {
    const t = tl.current;
    if (t && t.time() < CURTAIN_AT) t.seek(CURTAIN_AT);
  };

  if (gone) return null;

  const words = intro.film ? [intro.chapters[0]] : intro.chapters;

  return (
    <div ref={root} className={styles.intro} role="presentation">
      <div className={styles.panel} data-i="top" />
      <div className={styles.panel} data-i="bottom" />

      <div className={styles.stage} aria-hidden>
        <p className={styles.label} data-i="label">
          {site.label}
        </p>

        <div className={styles.frame} data-i="frame">
          {intro.film ? (
            <video ref={film} className={styles.media} data-i="film" src={intro.film} muted playsInline preload="auto" />
          ) : (
            <>
              <div className={styles.media} data-i="media" data-m="thread">
                <FramePlayer name="details" fps={22} playing={threadPlaying} className={styles.fill} />
              </div>
              <div className={styles.media} data-i="media" data-m="letter">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={site.media.frontChest.src} alt="" className={styles.fill} />
              </div>
              <svg className={styles.stitchBox} data-i="stitchBox" viewBox="0 0 100 100" preserveAspectRatio="none">
                <rect
                  data-i="stitch"
                  x="3"
                  y="3"
                  width="94"
                  height="94"
                  pathLength={1}
                  vectorEffect="non-scaling-stroke"
                  className={styles.stitch}
                />
              </svg>
              <div className={styles.media} data-i="media" data-m="turn">
                <video ref={turn} className={styles.fill} src={site.media.rotation.src} muted playsInline preload="auto" />
              </div>
            </>
          )}
        </div>

        <div className={styles.words} data-i="words">
          <span className={styles.count} data-i="count">
            {!intro.film && (
              <>
                <span ref={chapter}>I</span> / III
              </>
            )}
          </span>
          <div className={styles.wordStack}>
            {words.map((w, i) => (
              <span key={w} className={styles.word} data-i="word" data-n={i + 1}>
                <span>{w}</span>
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className={styles.chrome} data-i="chrome">
        <p className={styles.disclosure}>{intro.film ? intro.filmNote : intro.note}</p>
        <button type="button" className={styles.skip} onClick={skip}>
          Skip intro
        </button>
      </div>
    </div>
  );
}

/** True when the browser can create a WebGL context. */
export function hasWebGL(): boolean {
  try {
    const canvas = document.createElement("canvas");
    return Boolean(canvas.getContext("webgl2") ?? canvas.getContext("webgl"));
  } catch {
    return false;
  }
}

/** True when a model file is actually being served at `url`. */
export async function modelExists(url: string): Promise<boolean> {
  try {
    const res = await fetch(url, { method: "HEAD", cache: "no-store" });
    const type = res.headers.get("content-type") ?? "";
    // dev servers answer unknown paths with an HTML 404 page
    return res.ok && !type.includes("text/html");
  } catch {
    return false;
  }
}

/** Rough low-power signal: few cores or Save-Data on. Used to cap render quality. */
export function isLowPower(): boolean {
  const nav = navigator as Navigator & { connection?: { saveData?: boolean }; deviceMemory?: number };
  return (
    (nav.hardwareConcurrency ?? 8) <= 4 ||
    (nav.deviceMemory ?? 8) <= 4 ||
    nav.connection?.saveData === true
  );
}

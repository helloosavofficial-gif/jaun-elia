"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { site } from "@/content/site";
import type { ViewerProps } from "./types";
import styles from "./viewer.module.css";

const SWIPE = 48;

/**
 * Honest image-based viewer built from the supplied product images.
 * Front/back crossfade, swipe to switch sides, zoom with drag-to-pan.
 */
export function ImageViewer({ side, zoom, resetToken, onSideChange }: ViewerProps) {
  const frame = useRef<HTMLDivElement>(null);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const drag = useRef<{ x: number; y: number; px: number; py: number; moved: boolean } | null>(null);
  const { front, back } = site.garment;

  useEffect(() => setPan({ x: 0, y: 0 }), [resetToken, zoom, side]);

  const clampPan = (x: number, y: number) => {
    const el = frame.current;
    if (!el || zoom === 1) return { x: 0, y: 0 };
    const mx = (el.clientWidth * (zoom - 1)) / 2;
    const my = (el.clientHeight * (zoom - 1)) / 2;
    return { x: Math.max(-mx, Math.min(mx, x)), y: Math.max(-my, Math.min(my, y)) };
  };

  const onDown = (e: React.PointerEvent) => {
    drag.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y, moved: false };
    (e.target as Element).setPointerCapture?.(e.pointerId);
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const dx = e.clientX - d.x;
    const dy = e.clientY - d.y;
    if (zoom > 1) {
      setPan(clampPan(d.px + dx, d.py + dy));
    } else if (!d.moved && Math.abs(dx) > SWIPE && Math.abs(dx) > Math.abs(dy)) {
      d.moved = true;
      onSideChange(side === "front" ? "back" : "front");
    }
  };
  const onUp = () => {
    drag.current = null;
  };

  return (
    <div
      ref={frame}
      className={styles.imageFrame}
      data-zoomed={zoom > 1}
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={onUp}
    >
      <div
        className={styles.imageZoom}
        style={{ transform: `translate3d(${pan.x}px, ${pan.y}px, 0) scale(${zoom})` }}
      >
        {(["front", "back"] as const).map((s) => {
          const img = s === "front" ? front : back;
          return (
            <Image
              key={s}
              src={img.src}
              width={img.width}
              height={img.height}
              alt={
                s === "front"
                  ? "Front of the off-white hoodie with Urdu calligraphy on the left chest"
                  : "Back of the off-white hoodie with large Urdu calligraphy, English name and verse"
              }
              className={styles.face}
              data-on={side === s}
              aria-hidden={side !== s}
              draggable={false}
              sizes="(max-width: 768px) 90vw, 46vh"
              priority={s === "front"}
            />
          );
        })}
      </div>
    </div>
  );
}

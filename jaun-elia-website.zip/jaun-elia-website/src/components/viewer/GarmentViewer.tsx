"use client";

import dynamic from "next/dynamic";
import { useCallback, useEffect, useState } from "react";
import { site } from "@/content/site";
import { ErrorBoundary } from "./ErrorBoundary";
import { ImageViewer } from "./ImageViewer";
import { hasWebGL, modelExists } from "./support";
import { ZOOM_LEVELS, type Side, type ViewerState, type Zoom } from "./types";
import styles from "./viewer.module.css";

// three.js only loads when a real model is present
const ModelViewer = dynamic(() => import("./ModelViewer").then((m) => m.ModelViewer), {
  ssr: false,
});

type Mode = "checking" | "image" | "model";

/**
 * The garment viewer. Uses the real 3D model when one is served at
 * site.garment.modelUrl and WebGL works; otherwise (or if the model fails to
 * load) it falls back to the image viewer. Controls are identical in both modes.
 */
export function GarmentViewer({ className }: { className?: string }) {
  const [mode, setMode] = useState<Mode>("checking");
  const [modelUrl, setModelUrl] = useState(site.garment.modelUrl);
  const [state, setState] = useState<ViewerState>({ side: "front", zoom: 1, resetToken: 0 });
  const [modelReady, setModelReady] = useState(false);
  const onModelLoaded = useCallback(() => setModelReady(true), []);

  useEffect(() => {
    let alive = true;
    // dev-only: ?model=/path.glb to test another file
    const override =
      process.env.NODE_ENV !== "production"
        ? new URLSearchParams(window.location.search).get("model")
        : null;
    const url = override ?? site.garment.modelUrl;
    setModelUrl(url);
    (async () => {
      const ok = hasWebGL() && (await modelExists(url));
      if (alive) setMode(ok ? "model" : "image");
    })();
    return () => {
      alive = false;
    };
  }, []);

  const setSide = useCallback((side: Side) => setState((s) => ({ ...s, side })), []);
  const stepZoom = (dir: 1 | -1) =>
    setState((s) => {
      const i = ZOOM_LEVELS.indexOf(s.zoom) + dir;
      const zoom = ZOOM_LEVELS[Math.max(0, Math.min(ZOOM_LEVELS.length - 1, i))] as Zoom;
      return { ...s, zoom };
    });
  const reset = () => setState((s) => ({ side: "front", zoom: 1, resetToken: s.resetToken + 1 }));

  const onKeyDown = (e: React.KeyboardEvent) => {
    const keys: Record<string, () => void> = {
      ArrowLeft: () => setSide(state.side === "front" ? "back" : "front"),
      ArrowRight: () => setSide(state.side === "front" ? "back" : "front"),
      "+": () => stepZoom(1),
      "=": () => stepZoom(1),
      "-": () => stepZoom(-1),
      "0": reset,
      f: () => setSide("front"),
      b: () => setSide("back"),
    };
    const fn = keys[e.key];
    if (fn) {
      e.preventDefault();
      fn();
    }
  };

  const image = <ImageViewer {...state} onSideChange={setSide} />;
  const label = mode === "model" ? site.viewer.modelMode.value : site.viewer.imageMode.value;

  return (
    <div className={`${styles.viewer} ${className ?? ""}`} data-mode={mode}>
      <div
        className={styles.stage}
        tabIndex={0}
        role="region"
        aria-roledescription="product viewer"
        aria-label={`Hoodie viewer, showing the ${state.side}. ${site.viewer.hint.value}; plus and minus to zoom; 0 to reset.`}
        onKeyDown={onKeyDown}
      >
        {mode === "model" ? (
          <ErrorBoundary fallback={image} onError={() => setMode("image")}>
            <ModelViewer url={modelUrl} {...state} onSideChange={setSide} onLoaded={onModelLoaded} />
            {!modelReady && (
              <p className={styles.loading} role="status">
                Loading 3D model…
              </p>
            )}
          </ErrorBoundary>
        ) : (
          image
        )}
      </div>

      <div className={styles.bar}>
        <div className={styles.group} role="group" aria-label="Side">
          {(["front", "back"] as const).map((s) => (
            <button
              key={s}
              type="button"
              className={styles.btn}
              aria-pressed={state.side === s}
              onClick={() => setSide(s)}
            >
              {s === "front" ? "Front" : "Back"}
            </button>
          ))}
        </div>
        <div className={styles.group} role="group" aria-label="Zoom">
          <button type="button" className={styles.icon} onClick={() => stepZoom(-1)} disabled={state.zoom === 1} aria-label="Zoom out">
            −
          </button>
          <span className={styles.zoomValue} aria-live="polite">
            {state.zoom}×
          </span>
          <button type="button" className={styles.icon} onClick={() => stepZoom(1)} disabled={state.zoom === 2} aria-label="Zoom in">
            +
          </button>
        </div>
        <button type="button" className={styles.btn} onClick={reset}>
          Reset view
        </button>
      </div>
      <p className={styles.caption}>
        <span>{label}</span>
        <span className={styles.hint}>{site.viewer.hint.value}</span>
      </p>
    </div>
  );
}

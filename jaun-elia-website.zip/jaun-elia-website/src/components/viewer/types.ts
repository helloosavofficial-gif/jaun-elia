export type Side = "front" | "back";

export const ZOOM_LEVELS = [1, 1.5, 2] as const;
export type Zoom = (typeof ZOOM_LEVELS)[number];

/** State shared by every viewer implementation; GarmentViewer owns it. */
export type ViewerState = {
  side: Side;
  zoom: Zoom;
  /** Incremented to ask the viewer to drop any drag/pan offsets. */
  resetToken: number;
};

export type ViewerProps = ViewerState & {
  /** Viewer reports side changes caused by its own gestures (e.g. a swipe). */
  onSideChange: (side: Side) => void;
};

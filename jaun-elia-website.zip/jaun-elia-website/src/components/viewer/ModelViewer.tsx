"use client";

import { Suspense, useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer, useGLTF } from "@react-three/drei";
import type { Side, ViewerProps } from "./types";
import { isLowPower } from "./support";
import styles from "./viewer.module.css";

const TARGET_HEIGHT = 2.2;
const BASE_DISTANCE = 6.4;
const damp = THREE.MathUtils.damp;

type Props = ViewerProps & { url: string; onLoaded?: () => void };

/**
 * Real-3D viewer for a supplied garment model (GLB/glTF).
 * Expects a hoodie modelled facing +Z; it is centred and scaled to fit.
 * Geometry may be Meshopt-compressed (decoded locally). Draco/KTX2 would need
 * self-hosted decoders — not wired up, to avoid third-party requests.
 */
export function ModelViewer({ url, side, zoom, resetToken, onSideChange, onLoaded }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const dragOffset = useRef(0);
  const ownChange = useRef(false);
  const lowPower = useMemo(() => (typeof navigator === "undefined" ? false : isLowPower()), []);

  useEffect(() => {
    // a side change caused by our own drag keeps the current angle
    if (ownChange.current) {
      ownChange.current = false;
      return;
    }
    dragOffset.current = 0;
  }, [resetToken, side]);

  // horizontal drag rotates; vertical gestures stay with the page
  useEffect(() => {
    const el = host.current;
    if (!el) return;
    let last: number | null = null;
    const down = (e: PointerEvent) => {
      last = e.clientX;
      el.setPointerCapture(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (last === null) return;
      dragOffset.current += (e.clientX - last) * 0.01;
      last = e.clientX;
    };
    const up = () => {
      if (last === null) return;
      last = null;
      const angle = (side === "back" ? Math.PI : 0) + dragOffset.current;
      const facing: Side = Math.cos(angle) < 0 ? "back" : "front";
      if (facing !== side) {
        dragOffset.current = angle - (facing === "back" ? Math.PI : 0);
        ownChange.current = true;
        onSideChange(facing);
      }
    };
    el.addEventListener("pointerdown", down);
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
    return () => {
      el.removeEventListener("pointerdown", down);
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
    };
  }, [side, onSideChange]);

  return (
    <div ref={host} className={styles.modelFrame}>
      <Canvas
        dpr={lowPower ? 1 : [1, 1.75]}
        camera={{ position: [0, 0.2, BASE_DISTANCE], fov: 28 }}
        gl={{ antialias: !lowPower, alpha: true }}
        onCreated={({ gl }) => {
          gl.toneMapping = THREE.ACESFilmicToneMapping;
        }}
      >
        <StudioLights />
        <Suspense fallback={null}>
          <Garment url={url} side={side} zoom={zoom} dragOffset={dragOffset} onLoaded={onLoaded} />
        </Suspense>
      </Canvas>
    </div>
  );
}

function StudioLights() {
  return (
    <>
      <ambientLight intensity={0.08} />
      <directionalLight position={[-4.5, 4, 2.6]} intensity={2.4} color="#fff4e6" />
      <spotLight position={[3.5, 3, -4]} angle={0.6} penumbra={1} intensity={50} color="#ffd9a8" />
      <Environment resolution={128}>
        <Lightformer form="rect" intensity={1.3} position={[0, 4, 2]} rotation={[Math.PI / 2, 0, 0]} scale={[6, 3, 1]} />
        <Lightformer form="rect" intensity={0.9} position={[-4, 1, 1]} rotation={[0, Math.PI / 2, 0]} scale={[3, 4, 1]} />
        <Lightformer form="rect" intensity={0.7} color="#ffd9b0" position={[4, 1, -2]} rotation={[0, -Math.PI / 2, 0]} scale={[3, 4, 1]} />
      </Environment>
    </>
  );
}

function Garment({
  url,
  side,
  zoom,
  dragOffset,
  onLoaded,
}: {
  url: string;
  side: Side;
  zoom: number;
  dragOffset: React.RefObject<number>;
  onLoaded?: () => void;
}) {
  const { scene } = useGLTF(url, false, true);
  const group = useRef<THREE.Group>(null);
  const { camera } = useThree();

  // centre on the origin and scale to a consistent height
  const fitted = useMemo(() => {
    const root = scene.clone(true);
    const box = new THREE.Box3().setFromObject(root);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const s = TARGET_HEIGHT / Math.max(size.y, 1e-6);
    root.position.sub(center).multiplyScalar(s);
    root.scale.setScalar(s);
    return root;
  }, [scene]);

  useEffect(() => onLoaded?.(), [fitted, onLoaded]);

  useFrame((_, dt) => {
    const g = group.current;
    if (!g) return;
    const d = Math.min(dt, 1 / 20);
    const target = (side === "back" ? Math.PI : 0) + (dragOffset.current ?? 0);
    g.rotation.y = damp(g.rotation.y, target, 5, d);
    camera.position.z = damp(camera.position.z, BASE_DISTANCE / zoom, 4, d);
    camera.lookAt(0, 0, 0);
  });

  return (
    <group ref={group}>
      <primitive object={fitted} />
    </group>
  );
}

"use client";

import { Component, type ReactNode } from "react";

type Props = { fallback: ReactNode; onError?: (error: unknown) => void; children: ReactNode };

/** Keeps a failing 3D viewer from taking the page down; renders the fallback instead. */
export class ErrorBoundary extends Component<Props, { failed: boolean }> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: unknown) {
    this.props.onError?.(error);
  }

  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

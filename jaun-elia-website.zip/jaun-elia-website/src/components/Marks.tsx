/**
 * ن (noon) symbol and reading column from OSAV's brand-identity PROPOSAL.
 * Not client-approved — gated by flags.showProposedMark.
 */
export function NoonMark({ className, title = "Proposed mark" }: { className?: string; title?: string }) {
  return (
    <svg className={className} viewBox="135.46 148.46 718.08 718.08" role="img" aria-label={title}>
      <path
        fill="currentColor"
        d="M725 255C770 380 775 520 715 610C655 700 520 760 400 725C320 702 262 640 238 545L214 462C258 565 312 612 385 632C500 665 590 632 638 565C672 515 676 420 725 255ZM460.81 319.64L529.42 376.65L479.19 450.36L410.58 393.35Z"
      />
    </svg>
  );
}

/** Three diamonds and a hairline, taken from the hoodie's back artwork. */
export function ReadingColumn({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 40 400" aria-hidden>
      <path d="M20 3L29 12L20 21L11 12Z M20 27L29 36L20 45L11 36Z M20 51L29 60L20 69L11 60Z" fill="currentColor" />
      <rect x="19.5" y="80" width="1" height="320" fill="currentColor" />
    </svg>
  );
}

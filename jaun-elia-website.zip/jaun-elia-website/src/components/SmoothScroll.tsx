"use client";

import { useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Lenis from "lenis";
import { prefersReduced } from "@/lib/motion";
import { registerLenis } from "@/lib/scroll";

gsap.registerPlugin(ScrollTrigger);
// Phones resize the viewport every time the address bar slides in or out while
// scrolling. Re-measuring every scene then causes a visible hitch mid-scroll;
// those height-only resizes don't move anything that matters, so skip them.
ScrollTrigger.config({ ignoreMobileResize: true });

/**
 * Site-wide inertial scrolling (mouse wheel / trackpad), driven from GSAP's
 * ticker so every ScrollTrigger scrub, the video scrubber and the frame
 * sequences update on the same frame as the scroll position.
 * Touch keeps native scrolling (better on phones). Off only with ?motion=off:
 * kept on for every visitor, including when the OS asks for reduced motion.
 * In-page #anchor links glide instead of jumping.
 */
export function SmoothScroll() {
  useEffect(() => {
    if (prefersReduced()) return;

    const lenis = new Lenis({
      lerp: 0.085,
      wheelMultiplier: 0.9,
      anchors: { offset: 0 },
      autoRaf: false,
    });
    lenis.on("scroll", ScrollTrigger.update);
    const tick = (time: number) => lenis.raf(time * 1000);
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);
    document.documentElement.classList.add("lenis");
    registerLenis(lenis);
    if (process.env.NODE_ENV !== "production") {
      // dev-only handle for debugging from the console
      Object.assign(window, { __lenis: lenis });
    }

    return () => {
      registerLenis(null);
      gsap.ticker.remove(tick);
      lenis.destroy();
      document.documentElement.classList.remove("lenis");
    };
  }, []);

  return null;
}
